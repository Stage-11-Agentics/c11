# g60-w2-v1

Synthetic workspace performance fixture.

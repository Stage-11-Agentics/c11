C11-294 handoff validation: e2af4cb60cfb89b4369da0be979100ac1d0931bc

Engine:37348b05c783829f6865255fc46c6ebcc387f640, published on Stage11 Ghostty main before parent pointer. Draft PR:https://github.com/Stage-11-Agentics/c11/pull/507.

Artifact identity

Both Debug app builds compiled on [build host] with Xcode26.3. Baseline parent86d45e218f / engine26c3e499ed8c4d65e3748248de7fd04c1e9a8103, invocation5b5f5c5e08ae49d9bfa97a947909ff64. Candidate parentb6cba19133948b2a9f26ae5bfee760790238ea8b / engine37348b05c, invocatione6a5e7f30f764ea0acad0504b8e62c96. The later parent commit changes only test fixtures/docs; product sources and engine are identical to the tested candidate. Builds were retrieved, re-signed and launched QA-fresh on [client] per explicit [build host] BUILDS LIVE launch/UI authorization. Exact binary/debug-dylib/CLI hashes:/tmp/c11-294-[build host]-artifact-manifest.json; raw build results under each worktree build-remote/<invocation>/result.json.

Candidate GhosttyKit was compiled under [client] build lock before [build host]-live:276/276 universal ReleaseFast steps. Same macOS lib SHA256 verified locally and on [build host]:9febd6acef5b582bf3d10361b3f1b4ff901569f27659e29540cc4322202683a9. CI checksum is pending and has not been edited manually.

Targeted/native evidence

- Final focused Ghostty:131/132 passed,1platform skip,59/59steps; /tmp/c11-294-focused-repair-final.log.
- Final native try-read:62/62steps; /tmp/c11-294-native-37348.log. Held renderer mutex returns BUSY, absent/invalid/allocation failure zero outputs; golden text/selection parity and successful allocation cleanup. Formatting remains synchronous and unbounded after lock acquisition.
- Real saturated-app-mailbox teardown:64queued messages,1blocked producer; ghostty_surface_free74.273ms and survivor-child ACK. /tmp/c11-294-teardown-37348/teardown.log.
- B072 ordinary and synthetic competing-writer PTY probes:patched dependency8192completions/524288bytes exact. Old pinned dependency lost one64byte request only in forced readiness/backpressure race; no observed production loss is claimed. /tmp/c11-294-libxev-{baseline-race,candidate-ordinary,candidate-race}.log.

Matched runtime comparison

Thirty real streaming PTYs at20Hz, one visible probe workspace,100PID-scoped Quartz/AppKit tokens, workspace churn every10samples. Same [client] hardware, same source fixture and v2input driver, shared CLOCK_MONOTONIC_RAW. Read-only focus readiness is excluded from key timing; no refocus or input retry. Each token received by actual child and observed via real tagged read-screen. These are synthetic Return-event timings, not physical keyboard or GPU frame latency. Both runs completed100/100 with0misses and0cleanup errors.

| Metric ms | Baseline p50/p95/p99/max | Candidate p50/p95/p99/max |
|---|---|---|
| key_to_pty_ms | 29.862/36.019/36.364/36.460 | 28.635/34.770/35.645/35.696 |
| key_to_read_screen_ms | 40.046/45.432/48.125/48.871 | 39.744/44.580/46.052/47.378 |
| pty_ms | 320.895/335.537/384.724/387.010 | 318.289/329.561/338.259/338.862 |
| read_screen_ms | 329.537/344.337/396.218/398.659 | 328.288/340.485/347.703/349.502 |
Baseline sampling:41.301s; load1/5/15 start:[4.966796875, 5.6689453125, 7.51953125]; end:[5.669921875, 5.7236328125, 7.4306640625].
Candidate sampling:41.432s; load1/5/15 start:[5.041015625, 5.578125, 7.33837890625]; end:[6.17138671875, 5.876953125, 7.29541015625].

Raw results:/tmp/c11-294-[build host]-{baseline,candidate}-runtime-v2/result.json; comparison:/tmp/c11-294-[build host]-comparison-v2.json. This one matched sample shows no regression in these distributions; Orchestrator owns the performance verdict. App tick-duration/message-count instrumentation and full fleet soak are not claimed.

Candidate product scenarios

- Exact paste:138022UTF8 bytes, one bracket pair, 87concurrent terminal replies outside payload; input SHA256:67ef608eed7e76c1573f009647522fd78f577a342ed7f11f02b0a7f9a5ec682c. Raw capture in candidate result directory.
- Disposable interactive Codex showed one [Pasted Content4062chars] item from101synthetic lines; nothing submitted. Screenshot:/tmp/c11-294-codex-single-paste.png. Synthesized Ctrl-C dismissed it; workspace disappeared.
- Real Cmd-H hid candidate, exact CGWindow33358 confirmed offscreen. Re-activation produced fresh live counter and typed FOCUS-PROBE ACK. /tmp/c11-294-visual-after-show.png + read-after-show.json.
- Real Ctrl-Cmd-[ then Ctrl-Cmd-] moved away from and back to a streaming workspace; distinct/current workspace IDs verified, real typed WORKSPACE-FOCUS-ACK received. /tmp/c11-294-focus-{background,foreground}.json and foreground.png.
- Twelve ordinary keyboard Escape/Select All/Copy cycles while terminal output updated returned expected synthetic text, process survived. /tmp/c11-294-selection-repeated.json and selection-all.png. Mouse drag was not accepted as proof; clipboard did not change in that attempted path. Original clipboard restored without retaining its content in report.
- Each foreground workspace is one readable full terminal area on verified DELL U2518D display3, not30tiny panes. /tmp/c11-294-visual-final-tree.txt and candidate-v2-streaming.png.

- Real child close graceful:35.060ms; HUP observed:True.
- Real child close ignore-hup:12106.913ms; HUP observed:False.
- Real child close ignore-both:12153.649ms; HUP observed:False.
- Real child close detached:103.657ms; HUP observed:True; detached sentinel alive:True.

Final synthesized Cmd-H dismissal verified; both exact tagged PIDs then terminated. All fixture workers/workspaces cleaned, UI slot released, production CLI pointer restored. No production app input, installed-skill edits or sync.

Failed attempts and proof limits

Earlier whole-load zero-spacing driver runs lost synthetic input on both baseline and candidate; retained under /tmp/c11-294-[build host]-{baseline,candidate}-runtime-1. Drop layer remains unproven. Revised driver spaces down/up20ms and fixture verifies exact first responder before input; v2bothpass. Earlier fixture assumptions used selected instead of selected_in_area and tried tab.close on a sole tab; corrected to real API semantics and reran. No earlier failure is counted as a pass.

Native fixture proves saturated APP mailbox real-surface teardown, not a complete real-surface cross-product of renderer/IO/search/health saturation. Focus/bounded turn and cancellation combinations also have focused executable tests; not all listed plan combinations were independently driven through tagged GUI. Reaped-leader/stale-PGID/pre-setsid shutdown cases are not claimed as tagged runtime proof. No native formatting wall-time bound, physical keyboard claim, GPU latency distribution, app tick counters or full fleet soak. Review should preserve these limits.

Validator scenario

1. Build merged main via scripts/remote-build.sh --tag c11-294-validator; launch its QA-fresh tagged artifact in authorized UI slot. Confirm exact artifact/source and CLI socket peer.
2. Replay tests/ghostty_patchset native teardown and try-read hosts plus focused Zig filters; expect64full app messages, blocked producer cancellation, survivor ACK, correct BUSY/selection/status/allocation ownership.
3. Run matching baseline/candidate runtime fixture on identical hardware with30streams100samples and same ui-driver hash. Expect0misses, exact paste with single brackets, all child deadlines below18s, detached sentinel alive,0cleanup errors. Save load/distributions; no invented release threshold.
4. On verified tagged window, hide/show under streaming, switch workspace through UI, type synthetic text and observe ACK/current frame. Repeat ordinary Select All/Copy; expect synthetic clipboard text and liveness. Paste101synthetic lines into disposable Codex without submitting; expect one paste item.
5. Restore clipboard, close fixture workspaces, prove synthesized dismissal, release slot. Keep CI/checksum and review/merge status separate from runtime results.

Formal cross-family review and exact-head CI remain Orchestrator/Merge Captain gates; not merged or released.

import json,subprocess,sys,time,hashlib,argparse,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('role',choices=['control','candidate']);a=p.parse_args();tools=Path('/tmp/c11-259-perf');root=tools/'paired-fresh'/a.role;cpath=root/'calibration/config.json';c=json.loads(cpath.read_text());proof={}
# Exact bytes match previously visually verified synthetic templates.
for label,path in c['templates'].items():
 new=json.loads(Path(path).read_text());old=json.loads((tools/'control-calibration/templates'/f'{label}.json').read_text());assert new['sha256']==old['sha256'] and new['roi']==old['roi'];proof[label]={'sha256':new['sha256'],'matches_reviewed_control_template':True}
c['templates_visually_verified']=True;cpath.write_text(json.dumps(c,indent=2)+'\n');(root/'calibration/template-review.json').write_text(json.dumps(proof,indent=2)+'\n')
# Both roles get the same idle settling interval after provision/calibration.
started=time.monotonic();time.sleep(60);(root/'settling.json').write_text(json.dumps({'requested_idle_s':60,'observed_idle_s':time.monotonic()-started,'unix_end':time.time()},indent=2)+'\n')
(root/'host-processes-before.txt').write_text(subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True));(root/'probe-script-hashes.json').write_text(json.dumps({n:hashlib.sha256((tools/n).read_bytes()).hexdigest() for n in ['g60.py','probe_terminal.py','visual_probe.py','run_phases.py','calibrate.py','setup_fresh.py','run_fresh.py']},indent=2)+'\n')
r=subprocess.run([sys.executable,str(tools/'run_phases.py'),'--config',str(cpath),'--manifest',str(root/'fixture/manifest.json'),'--expected',str(root/'fixture/expected.json'),'--out',str(root/'run')]);raise SystemExit(r.returncode)

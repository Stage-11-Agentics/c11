"""Configure only a known tagged build-host app/window and capture setup evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def main():
    import AppKit
    import Quartz
    from visual_probe import Target
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--display", type=int, required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--started", type=float, required=True)
    args = parser.parse_args()
    if args.tag not in ("c11-259", "c11-259-control"):
        raise SystemExit("Only the two assigned tags are permitted")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    hostname = subprocess.check_output(["scutil", "--get", "ComputerName"], text=True).strip()
    # Capture stdout of scutil over the explicitly authorized build-host SSH endpoint.
    bundle = "com.stage11.c11.debug." + args.tag.replace("-", ".")
    apps = list(AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bundle))
    if len(apps) != 1:
        raise RuntimeError("Exactly one tagged app must be running")
    app = apps[0]
    app_path = str(app.bundleURL().path())
    if Path(app_path).name != f"c11 DEV {args.tag}.app":
        raise RuntimeError("Tagged application path mismatch")
    pid = app.processIdentifier()
    display = Quartz.CGDisplayBounds(args.display)
    if display.size.width < 1480 or display.size.height < 1000:
        raise RuntimeError("Verified display is too small for the paired geometry")
    app.activateWithOptions_(AppKit.NSApplicationActivateIgnoringOtherApps)
    x, y = int(display.origin.x + 80), int(display.origin.y + 80)
    script = (f'tell application "System Events" to tell (first process whose unix id is {pid})\n'
              f'set position of window 1 to {{{x}, {y}}}\n'
              'set size of window 1 to {1320, 880}\nend tell')
    subprocess.run(["osascript", "-e", script], check=True, timeout=10)
    time.sleep(0.4)
    windows = [w for w in Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListOptionOnScreenOnly, 0)
               if w.get("kCGWindowOwnerPID") == pid and w.get("kCGWindowLayer") == 0
               and w.get("kCGWindowBounds", {}).get("Width", 0) > 800]
    if len(windows) != 1:
        raise RuntimeError("Expected one visible tagged fixture window")
    window = windows[0]
    hashes = {}
    for relative in ("Contents/MacOS/c11", "Contents/MacOS/c11.debug.dylib", "Contents/Resources/bin/c11"):
        hashes[relative] = hashlib.sha256((Path(app_path) / relative).read_bytes()).hexdigest()
    config = {"host": hostname, "transport_host": "build-host", "bundle_id": bundle,
              "pid": pid, "app_path": app_path, "window_id": window["kCGWindowNumber"],
              "window_bounds": dict(window["kCGWindowBounds"]), "display_id": args.display,
              "display_bounds": {"x": display.origin.x, "y": display.origin.y,
                                 "width": display.size.width, "height": display.size.height},
              "run_started_unix": args.started, "artifact_sha256": hashes,
              "templates_visually_verified": False}
    (out / "config.json").write_text(json.dumps(config, indent=2) + "\n")
    target = Target(config, out)
    width, height = (int(config["window_bounds"][k]) for k in ("Width", "Height"))
    image, _, timing = target.capture([0, 0, width, height])
    target.save_png(image, out / "setup.png")
    (out / "setup-capture.json").write_text(json.dumps(timing, indent=2) + "\n")
    print(json.dumps(config, indent=2))


if __name__ == "__main__":
    main()

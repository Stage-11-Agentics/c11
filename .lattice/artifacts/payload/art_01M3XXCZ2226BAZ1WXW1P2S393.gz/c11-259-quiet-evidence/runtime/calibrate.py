import json,time,argparse
from pathlib import Path
from visual_probe import Target
p=argparse.ArgumentParser();p.add_argument('config');a=p.parse_args()
f=Path(a.config);c=json.loads(f.read_text());d=f.parent
c.update(terminal_point=[400,200],sidebar_point=[100,400],scroll_pixels=146,setup_settle_s=.12)
t=Target(c,d/'templates'); templates={}
def snap(n,roi,s):
 time.sleep(.5);t.template(n,roi,s);templates[n]=str(d/'templates'/f'{n}.json')
t.post({'kind':'key','keycode':18,'command':True});time.sleep(.3)
t.post({'kind':'click','point':c['terminal_point']});t.post({'kind':'key','text':'a'})
snap('glyph-a',[225,98,10,18],'Lowercase a at terminal row 3 column 4')
snap('workspace-1',[200,64,112,19],'G60-PROBE-ONE marker on workspace g60-w01')
t.post({'kind':'key','text':'b'});snap('glyph-b',[225,98,10,18],'Lowercase b at terminal row 3 column 4')
t.post({'kind':'key','keycode':19,'command':True});snap('workspace-2',[200,64,112,19],'G60-PROBE-TWO marker on workspace g60-w02')
t.post({'kind':'key','keycode':18,'command':True});time.sleep(.3)
t.post({'kind':'scroll','point':c['sidebar_point'],'pixels':10000});snap('scroll-top',[15,64,100,18],'g60-w01 title at known sidebar top')
t.post({'kind':'scroll','point':c['sidebar_point'],'pixels':-c['scroll_pixels']});snap('scroll-down',[15,64,100,18],'g60-w02 title after one 146-pixel sidebar scroll')
img,_,_=t.capture([0,0,1320,880]);t.save_png(img,d/'scrolled.png')
t.post({'kind':'scroll','point':c['sidebar_point'],'pixels':10000})
c['templates']=templates;f.write_text(json.dumps(c,indent=2)+'\n')
print('Templates captured; visual review required')

"""Run calibrated paired g60 probes on a pre-launched, verified build-host tag."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

from g60 import RPC, ChurnWorker, assert_model, capture, write_json
from visual_probe import Target, summarize


def read(path):
    return json.loads(Path(path).read_text())


def resource_sample(pid, path):
    # Descriptive snapshots are taken outside timed phases.
    result = {"monotonic": time.monotonic(), "load": os.getloadavg()}
    result["ps"] = subprocess.check_output(
        ["ps", "-p", str(pid), "-o", "pid=,%cpu=,rss=,vsz=,etime="], text=True).strip()
    footprint = subprocess.run(["footprint", "--pid", str(pid)], capture_output=True, text=True, timeout=20)
    result.update(footprint_returncode=footprint.returncode, footprint=footprint.stdout,
                  footprint_stderr=footprint.stderr)
    write_json(path, result)


def run(args):
    config, manifest = read(args.config), read(args.manifest)
    expected = read(args.expected)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    target = Target(config, out / "crops")
    templates = {name: read(path) for name, path in config["templates"].items()}
    for key in ("glyph-a", "glyph-b", "workspace-1", "workspace-2", "scroll-top", "scroll-down"):
        if key not in templates:
            raise RuntimeError(f"Missing reviewed template: {key}")
    if not config.get("templates_visually_verified"):
        raise RuntimeError("Expected-state template review is required")
    selected = manifest["labels"]["w01"]
    key1 = {"kind": "key", "keycode": 18, "command": True}
    key2 = {"kind": "key", "keycode": 19, "command": True}
    top = {"kind": "scroll", "point": config["sidebar_point"], "pixels": 10000}
    down = {"kind": "scroll", "point": config["sidebar_point"], "pixels": -config["scroll_pixels"]}
    setup_delay = config.get("setup_settle_s", 0.08)
    phase_results = []
    result = {"config": config, "manifest": str(args.manifest), "phases": phase_results, "complete": False}

    def choose(one, two):
        _, pixels, _ = target.capture(templates[one]["roi"])
        for name in (one, two):
            if pixels == Path(templates[name]["pixels"]).read_bytes():
                return name
        raise RuntimeError(f"Neither reviewed template is visible: {one}/{two}")

    def select_one():
        nonlocal selected
        target.post(key1)
        time.sleep(setup_delay)
        if choose("workspace-1", "workspace-2") != "workspace-1":
            raise RuntimeError("Workspace-one setup did not present its expected marker")
        selected = manifest["labels"]["w01"]

    def sample(metric, ident):
        nonlocal selected
        setup_started = time.perf_counter_ns()
        if metric == "typing":
            select_one()
            target.post({"kind": "click", "point": config["terminal_point"]})
            before = choose("glyph-a", "glyph-b")
            after = "glyph-b" if before == "glyph-a" else "glyph-a"
            action = {"kind": "key", "text": after[-1]}
        elif metric == "switch":
            before = choose("workspace-1", "workspace-2")
            after = "workspace-2" if before == "workspace-1" else "workspace-1"
            action = key2 if after == "workspace-2" else key1
        else:
            select_one()
            target.post(top)
            time.sleep(setup_delay)
            before, after, action = "scroll-top", "scroll-down", down
        setup_ended = time.perf_counter_ns()
        row = target.measure(ident, metric, action, templates[before], templates[after])
        row["setup_ms"] = (setup_ended - setup_started) / 1e6
        if metric == "switch" and row["ok"]:
            selected = manifest["labels"]["w02" if after == "workspace-2" else "w01"]
        row["selected_workspace_id"] = selected
        return row

    select_one()
    try:
        for phase in ("no-churn", "churn", "quiescence"):
            directory = out / phase
            directory.mkdir()
            with RPC(manifest["tag"], manifest["socket"]) as rpc:
                state = capture(rpc, manifest, directory / "before.json")
                assert_model(state, manifest, expected, selected)
            resource_sample(config["pid"], directory / "resources-before.json")
            started = time.monotonic() + 1
            deadline = started + 60
            worker = ChurnWorker(manifest, expected, started, directory / "operations.jsonl") if phase == "churn" else None
            records = []
            info = {"name": phase, "start": started, "deadline": deadline, "complete": False}
            phase_results.append(info)
            if worker:
                worker.start()
            try:
                # 105 typing, 42 scroll and 42 switch trials at fixed common slots.
                schedule = (["typing"] * 5 + ["switch"] * 2 + ["scroll"] * 2) * 21
                with (directory / "samples.jsonl").open("w") as log:
                    for index, metric in enumerate(schedule):
                        due = started + index * 58 / len(schedule)
                        time.sleep(max(0, due - time.monotonic()))
                        if time.monotonic() >= deadline:
                            raise RuntimeError("Probe schedule overran fixed 60-second phase")
                        row = sample(metric, f"{phase}-{index:03d}-{metric}")
                        row.update(scheduled=due, completed=time.monotonic())
                        records.append(row)
                        log.write(json.dumps(row) + "\n")
                        log.flush()
                        if len(records) >= 3 and all(not r["ok"] for r in records[-3:]):
                            raise RuntimeError("Three consecutive failed visual probes; stop and recalibrate")
                    time.sleep(max(0, deadline - time.monotonic()))
            finally:
                if worker:
                    worker.stop_and_join()
                    expected = worker.expected
                    ops = worker.records
                    info["churn"] = {"completed_count": len(ops), "achieved_hz": len(ops) / 60,
                                     "error": worker.error, "pending": worker.pending,
                                     "alive": worker.is_alive(),
                                     "late": sum(r["started"] >= r["scheduled"] + 0.1 for r in ops),
                                     "overrun": any(r["completed"] > deadline for r in ops),
                                     "method_counts": {m: sum(r["method"] == m for r in ops)
                                                       for m in {r["method"] for r in ops}}}
                info["metrics"] = summarize(records)
                info["last_probe_overrun"] = any(r["completed"] > deadline for r in records)
                info["ended"] = time.monotonic()
                write_json(directory / "summary.json", info)
                write_json(directory / "expected.json", expected)
                write_json(out / "run.json", result)
            with RPC(manifest["tag"], manifest["socket"]) as rpc:
                state = capture(rpc, manifest, directory / "after.json")
                assert_model(state, manifest, expected, selected)
            info["model_verified"] = True
            resource_sample(config["pid"], directory / "resources-after.json")
            info["complete"] = not info["last_probe_overrun"] and all(
                info["metrics"][m]["valid"] >= minimum and info["metrics"][m]["errors"] == 0
                for m, minimum in (("typing", 100), ("scroll", 40), ("switch", 40)))
            if worker:
                churn = info["churn"]
                info["complete"] &= (churn["completed_count"] == 600 and not churn["error"]
                                     and not churn["late"] and not churn["overrun"])
            write_json(directory / "summary.json", info)
            write_json(out / "run.json", result)
            print(json.dumps({"phase": phase, "complete": info["complete"], "metrics": info["metrics"]}), flush=True)
            if not info["complete"]:
                raise RuntimeError(f"Incomplete phase: {phase}")
        result["complete"] = True
    except Exception as error:
        result["error"] = str(error)
        raise
    finally:
        write_json(out / "run.json", result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("config", "manifest", "expected", "out"):
        parser.add_argument("--" + key, required=True)
    run(parser.parse_args())

"""Read real tagged prime/mount logs until lossless queue settlement; no model-count proxy."""
import argparse
from pathlib import Path
import re
import time
from lease import atomic, read, require_runtime


def evaluate(log, manifest, max_mounts=3):
    ids = manifest['initial']['order']
    prefixes = {ws[:5].upper() for ws in ids}
    if len(prefixes) != 60: raise RuntimeError('Debug short-ID collision: insufficient mount evidence')
    started = set(re.findall(r'workspace\.backgroundPrime\.start workspace=(\w+)', log))
    finishes = [{'workspace': ws, 'reason': reason, 'duration_ms': float(ms)}
                for ws, reason, ms in re.findall(r'workspace\.backgroundPrime\.finish workspace=(\w+) reason=(\S+) ms=([0-9.]+)', log)]
    finished = {entry['workspace'] for entry in finishes}
    samples = re.findall(r'ws\.mount\.reconcile[^\n]*selected=(\w+)[^\n]*mounted=\[([^\]]*)\]', log)
    for selected, mounted in samples:
        mounted = mounted.split(',') if mounted else []
        if len(mounted) > max_mounts or (mounted and selected != 'nil' and selected not in mounted):
            raise RuntimeError('Mount cap/selected-body invariant failed')
    desired = manifest['labels']['w01'][:5].upper()
    expected_queued = {ws[:5].upper() for label, ws in manifest['labels'].items() if label != 'w01'}
    return {'complete': bool(samples and samples[-1] == (desired, desired)
                              and expected_queued <= started <= finished),
            'window_id': manifest['initial']['window_id'], 'historical_empty_mount_transitions':sum(not mounted for _,mounted in samples), 'queue_starts': sorted(started),
            'queue_finishes': finishes, 'bounded_fallback_timeouts': [entry for entry in finishes if 'timeout' in entry['reason'].lower()], 'last_mount': samples[-1] if samples else None}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('manifest', 'log', 'out'): p.add_argument('--'+key, required=True)
    p.add_argument('--offset', type=int, required=True, help='Saved byte offset immediately before fixture provisioning')
    p.add_argument('--debug-retention-disabled', action='store_true', required=True)
    a=p.parse_args(); manifest=read(a.manifest); end=time.monotonic()+135
    while True:
        require_runtime(manifest['tag'])
        raw=Path(a.log).read_bytes()[a.offset:]; result=evaluate(raw.decode(errors='replace'),manifest)
        if result['complete']:
            path=Path(a.out); path.with_suffix('.log').write_bytes(raw)
            atomic(path,dict(result,debug_retention_disabled=True,monotonic=time.monotonic(),log_path=str(path.with_suffix('.log')))); return
        if time.monotonic()>=end: raise RuntimeError('Observed background queue failed to settle in 135 seconds')
        time.sleep(.1)


if __name__=='__main__': main()

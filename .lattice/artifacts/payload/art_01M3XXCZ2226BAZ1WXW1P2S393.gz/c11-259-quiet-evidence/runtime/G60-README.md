# g60 fixture / churn / oracle support

Prepared only. No socket, app, build, SSH or UI run has occurred. Runtime is gated
on the Orchestrator's **build-host BUILDS LIVE** announcement and the parent's separate
authorization of the exact tagged QA app on build-host. This helper does not launch or
quit an app. The visual run's 20-minute timer and synthesized dismissal remain the
parent driver's responsibility.

`g60.py` is standalone Python standard library. Copy it and the parent-owned
`probe_terminal.py` to the same build-host runtime directory. Do not install packages
or modify tenant configuration.

## Provision (fresh dedicated tagged app only)

```
python3 /tmp/c11-259-perf/g60.py --execute \
  --tag c11-259-candidate --socket /tmp/c11-debug-c11-259-candidate.sock \
  --mode candidate provision --source-sha <exact-40-character-SHA> \
  --out /tmp/c11-259-perf/candidate-fixture
```

Repeat using `--mode control`, a different explicit tag/socket/output directory,
and the pinned control SHA. There is no socket discovery, default socket, CLI
discovery or app launch. Socket paths must exactly match `/tmp/c11-debug-<tag>.sock`
and must not be symlinks. The fixture refuses anything other than one window with
one initial workspace and no groups. It reuses that workspace as w01 and creates
59 others. Provision does select fixture workspaces to attach their terminals;
all such selection happens before measurement.

Both fixtures have 60 workspaces and exactly 60 tabs: browser-only w04/w33 at
about:blank, markdown-only w05/w34 reading a synthetic local note, 56 idle shells
elsewhere. Browser/markdown creation replaces their initial terminal tab before
the measured identity manifest is taken. Pins: w01/w02/w29/w30/w31/w32. Canonical
initial order: these six pinned workspaces followed by the other labels in order.
The candidate creates the six prescribed groups, including both empty groups;
the control makes no group or batch API call.

Each shell reports its own `$$` into its synthetic output-directory PID file.
The manifest records tab UUID -> shell PID and `ps` process start identity; every
boundary check verifies the shell still exists with that same start identity.
No inference from an arbitrary foreground process is used. Setup captures all
workspace/tab UUIDs, types, group records, pin bits, canonical order and selection.
Provision failures retain `provision-progress.json` for diagnosis, do not delete
anything and are not silently repaired into passing fixtures.

## Install probe commands before calibration

Import `g60.probe_commands(manifest, '/tmp/c11-259-perf/probe_terminal.py')`.
It returns the file hash and two records containing workspace_id, tab_id, marker
and command. For each record send the command through `tab.send_text`, then
`tab.send_key` with `key='enter'`. Use the explicitly tagged `RPC` connection.
This helper only generates commands; it does not execute them. The commands
leave the original shells alive. The parent driver verifies the actual markers
with its visual oracle, records the script hash for both builds, and selects w01
before initial measurement. Do not put the raw-input command in a nonprobe tab.

## Churn and sampler integration

```
python3 /tmp/c11-259-perf/g60.py --execute \
  --tag c11-259-candidate --socket /tmp/c11-debug-c11-259-candidate.sock \
  --mode candidate churn \
  --manifest /tmp/c11-259-perf/candidate-fixture/manifest.json \
  --expected /tmp/c11-259-perf/candidate-fixture/expected.json \
  --selection-file /tmp/c11-259-perf/candidate-fixture/selection.json \
  --start-at <future-time.monotonic-value> \
  --out /tmp/c11-259-perf/candidate-churn
```

The sampler and worker run on the same machine and share the future monotonic
phase boundary. Allow time for the worker's preflight snapshot/PID check before
that boundary. The worker owns a separate socket, has at most one in-flight RPC,
and has no pending-operation queue. The phase has exactly 600 scheduled slots at
`start + n/10` for n=0..599 and ends at `start + 60`. No catch-up beyond that fixed
boundary is allowed. Any error, missing request, request starting at least 100 ms
late or completing after phase end makes the run incomplete. RPC timeout is 3 s;
stop/join is bounded to 4 s, and no live worker may enter quiescence.

Shared source sequence: w25, w27, w26, w28, repeated 150 times. The control performs
600 legacy `workspace.reorder` calls, flipping each source across w60 using an
absolute final `index`. This avoids the control's pre-removal relative-index bug
and gives both builds the same intended ordering operation. Candidate
even slots perform the same singular reorder; odd slots detach/rejoin w27/w28
from/to Move Lane, giving exactly 300 reorder + 300 membership transfers. The
first 28 canonical rows (six pinned plus unpinned w03..w24 excluding pins) remain
unchanged, preserving both probes and top rows. No probe workspaces or tab content
are mutated by churn. Every request logs scheduled/started/completed monotonic
times, full parameters, response/error, and predicted canonical order/membership.
Actual full state is checked before churn and after the stopped, joined worker.

**Selection handshake:** the UI sampler must atomically replace `selection.json`
after each completed explicit switch probe with:
`{"workspace_id":"<actual expected UUID>","monotonic":<switch completion>}`.
Finish switch probes and their sidecar writes before the phase boundary, then
join the churn worker and verify selection. Do not begin a new phase's probes
while its predecessor's boundary snapshot is being captured. Otherwise the
snapshot and selection sidecar can legitimately race and the run will fail.
Omitting `--selection-file` asserts w01 stayed selected throughout.

For an integrated Python driver use `ChurnWorker(manifest, expected, start_at,
log_path).start()`, and at the boundary call `stop_and_join()`. It sets the stop
event and joins the thread; inspect `error`, `records`, `pending`, `is_alive()` and
`expected`. Never call the worker's `run()` inline in the UI sampling thread.
The CLI's `churn()` shows all required schedule/complete-state assertions. A
stopped-early worker is incomplete, even if its surviving model is consistent.

## Boundary oracle (no mutation)

```
python3 /tmp/c11-259-perf/g60.py --execute \
  --tag c11-259-candidate --socket /tmp/c11-debug-c11-259-candidate.sock \
  --mode candidate verify \
  --manifest /tmp/c11-259-perf/candidate-fixture/manifest.json \
  --expected /tmp/c11-259-perf/candidate-churn/expected.json \
  --selection-file /tmp/c11-259-perf/candidate-fixture/selection.json \
  --snapshot /tmp/c11-259-perf/candidate-quiescent-end.json
```

Use fixture `expected.json` before churn and churn `expected.json` afterwards.
Every snapshot includes the full raw tree, normalized state, shell identities,
monotonic/wall times and host load. Checks enforce all 60 unique complete UUIDs,
unchanged tab IDs/types and shell identities, pins, exact predicted canonical
order and membership, group properties/order/derived members, preserved top rows
and expected selection. This detects hidden anchor tabs/workspaces. It does not
prove no transient creation occurred between snapshots; retain event telemetry
if that stronger claim is needed.

`summary.json` distinguishes `schedule_complete`, `model_verified` and their
conjunction `complete`. Raw failed/late records stay in operations.jsonl. Existing
output directories are refused to avoid mixing runs.

This helper does not measure visual latency, CPU/footprint, hang telemetry,
capture overhead or phase sample counts. It does not replace the parent's
visual oracle/calibration, negative controls, full matched comparison, invalid
batch scenario, process/app identity capture or cleanup proof.

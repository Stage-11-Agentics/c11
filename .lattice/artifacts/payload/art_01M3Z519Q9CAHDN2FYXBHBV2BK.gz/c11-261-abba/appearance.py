"""Pure validation of external observed-settings evidence, never spec-as-observation."""
import hashlib
import json

APPEARANCE=('theme','font','scale','sidebar_width')
IDENTITY=('pid','bundle_id','app_path','window_id','window_bounds','display_id','artifact_sha256','run_started_unix')


def validate(config, spec, review, setup_config_bytes, setup_png_bytes):
    if not review.get('reviewer') or not review.get('evidence'):
        raise RuntimeError('External settings reviewer and observation evidence required')
    if review.get('observed_directly') is not True:
        raise RuntimeError('Spec values alone are not observed appearance evidence')
    if hashlib.sha256(setup_config_bytes).hexdigest()!=review.get('setup_config_sha256'):
        raise RuntimeError('Appearance review belongs to different setup config')
    if hashlib.sha256(setup_png_bytes).hexdigest()!=review.get('setup_png_sha256'):
        raise RuntimeError('Appearance review belongs to different setup image')
    setup=json.loads(setup_config_bytes)
    if any(setup.get(k)!=config.get(k) or setup.get(k)!=review.get('identity',{}).get(k) for k in IDENTITY):
        raise RuntimeError('Observed appearance PID/window/artifact identity differs')
    observed=review.get('observed',{})
    for key in APPEARANCE:
        if key not in observed or observed[key] is None or observed[key]!=spec.get(key):
            raise RuntimeError('Observed setting differs from frozen specification: '+key)
    return {key:observed[key] for key in APPEARANCE}

"""Observe the explicitly granted Orchestrator reservation; never acquire its locks."""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import uuid
from lease import atomic

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--pair', required=True)
p.add_argument('--holder-pid', required=True, type=int)
p.add_argument('--external-lease', required=True)
p.add_argument('--successor-pid', type=int)
p.add_argument('--successor-minutes', type=int, default=10)
a = p.parse_args()
root, external = Path(a.pair), Path(a.external_lease)
root.mkdir(exist_ok=False)
start, mono = time.time(), time.monotonic()
stamp = external.stat()
end = stamp.st_mtime + 1800
if a.successor_pid: end += a.successor_minutes*60
if start >= end:
    raise RuntimeError('Granted 30-minute reservation already expired')
paths = [str(Path(f'/tmp/c11-atlas-build-slots/slot-{i}.lock').resolve()) for i in (1,2)]
def holder_fds():
    process = subprocess.run(['/usr/sbin/lsof', '-p', str(a.holder_pid), '-Fn'],
                             capture_output=True, text=True, timeout=3)
    return {'returncode': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr,
            'pid': a.holder_pid, 'unix': time.time()}
proof = holder_fds()
if not all('n'+path+'\n' in proof['stdout'] for path in paths):
    raise RuntimeError('Granted holder does not have both slot files open')
atomic(root/'external-holder-initial.json', proof)
lease_bytes = external.read_bytes()
(root/'external-lease.txt').write_bytes(lease_bytes)
state = {'owner': 'C11-261 measurement observer', 'pid': os.getpid(), 'host': platform.node(),
         'token': uuid.uuid4().hex, 'ready': False, 'released': False,
         'reservation_mode': 'orchestrator-held', 'external_holder_pid': a.holder_pid,
         'external_lease_path': str(external), 'external_lease_inode': [stamp.st_dev,stamp.st_ino],
         'started_unix': start, 'cap_s': end-start,
         'deadline_monotonic': mono+end-start, 'heartbeat_monotonic': mono,
         'acquired': [{'slot': i, 'path': path, 'unix': stamp.st_mtime, 'monotonic': mono-(start-stamp.st_mtime),
                       'observed_holder_pid': a.holder_pid, 'acquired_by_observer': False}
                      for i,path in enumerate(paths,1)], 'external_release_verified': False}
atomic(root/'lease.json', state)
next_process = 0
reason = 'observer-error'
try:
    with (root/'load.jsonl').open('x') as load_log:
        while time.monotonic() < state['deadline_monotonic']+.1:
            now = time.monotonic()
            load = os.getloadavg()
            active = external.exists()
            if active:
                actual = external.stat()
                if [actual.st_dev,actual.st_ino] != state['external_lease_inode']:
                    if not a.successor_pid or a.holder_pid==a.successor_pid:raise RuntimeError('External reservation marker was replaced unexpectedly')
                    a.holder_pid=a.successor_pid
                    handover=holder_fds()
                    if not all('n'+path+'\n' in handover['stdout'] for path in paths):raise RuntimeError('Successor does not own both slots')
                    atomic(root/'external-holder-handover.json',handover)
                    state.update(external_holder_pid=a.holder_pid,external_lease_inode=[actual.st_dev,actual.st_ino],
                                 deadline_monotonic=now+(actual.st_mtime+a.successor_minutes*60-time.time()))
                    (root/'external-lease-successor.txt').write_bytes(external.read_bytes())
                try:os.kill(a.holder_pid,0)
                except ProcessLookupError:
                    if not a.successor_pid:raise
                    active=False
            row = {'monotonic': now, 'unix': time.time(), 'load': load,
                   'held_slots': 2 if active else 0, 'ready': state['ready']}
            load_log.write(json.dumps(row)+'\n'); load_log.flush()
            if not active:
                if a.successor_pid and a.holder_pid!=a.successor_pid and time.monotonic()<state['deadline_monotonic']:
                    state['heartbeat_monotonic']=now;atomic(root/'lease.json',state)
                    time.sleep(.1);continue
                final = holder_fds()
                atomic(root/'external-holder-release.json', final)
                state['external_release_verified'] = not any('n'+path+'\n' in final['stdout'] for path in paths)
                reason = state.get('measurement_finished_reason', 'external-reservation-ended')
                break
            if not state['ready'] and load[0] < 15:
                state.update(ready=True, ready_monotonic=now, ready_unix=time.time(), ready_load=load)
            elif state['ready'] and load[0] >= 15:
                atomic(root/'high-load-observed.json',dict(row,classification='recorded background load',rule='15 is admission only; interleave and disclose'))
            state['heartbeat_monotonic'] = now
            atomic(root/'lease.json', state)
            if now >= next_process:
                process = subprocess.run(['/bin/ps','-axo','pid,ppid,pcpu,rss,comm'],capture_output=True,text=True,timeout=2)
                atomic(root/f'processes-{time.monotonic_ns()}.json', {'monotonic':now,'unix':time.time(),
                       'returncode':process.returncode,'stdout':process.stdout,'stderr':process.stderr})
                vm = subprocess.run(['/opt/homebrew/bin/tart','list'],capture_output=True,text=True,timeout=3)
                atomic(root/f'vms-{time.monotonic_ns()}.json', {'monotonic':now,'unix':time.time(),
                       'returncode':vm.returncode,'stdout':vm.stdout,'stderr':vm.stderr})
                next_process = now+10
            request = root/'release-request.json'
            if request.exists():
                message = json.loads(request.read_text())
                if message['token'] != state['token']:
                    raise RuntimeError('Release request token mismatch')
                # The observer cannot close the Orchestrator's FDs. Keep recording
                # until its release marker disappears; early release is coordinated
                # through its mailbox, never by signalling an unowned holder.
                state['measurement_finished_reason'] = message['reason']
            time.sleep(max(0,.9-(time.monotonic()-now)))
        else:
            reason = 'granted-window-cap'
except BaseException as error:
    reason = 'observer-error: '+str(error)
finally:
    state.update(released=True, release_reason=reason, released_monotonic=time.monotonic(),
                 released_unix=time.time(),release_before_cap=time.monotonic() <= state['deadline_monotonic']+1)
    atomic(root/'lease.json',state)
    print(json.dumps(state),flush=True)

# C11-294 disclosure-safe historical evidence

This is a publication-only sanitization of previously recorded evidence. It does not rerun validation or change the recorded outcomes, limitations, Git commits, ticket IDs, artifact IDs, build invocation IDs, fixture run tokens, process IDs, or hashes. Older validation.md status statements describe their original observation time.

Supersedes: art_01M3XJZDS8YEQ2ZT6XQJ15FX0T, art_01M3XM29FXCMEK9WTTVFYV22R1.

Home-directory prefixes, including JSON-escaped paths and older home placeholders, use `$HOME`. Machine names use `[build host]` or `[client]`; personal account names and email addresses are removed where found. Product names are retained. No actual provider session or conversation IDs were found in these archive contents. Fixture/workspace/window IDs and build invocation IDs are not provider session IDs and remain for technical traceability.

Every screenshot was visually inspected and its textual PNG metadata inspected. No screenshots were omitted: retained images show synthetic fixture output, terminal layout, or the disposable product paste scenario without identifying account names, home paths, shell prompts, emails, or provider session IDs. Screenshot bytes were not altered or regenerated.

Text paths containing replaced machine names are documentary aliases, not directly runnable commands. Results and metrics are unchanged. The private original archives were preserved outside the repository. The public old payloads are withdrawn separately while immutable board metadata/events remain intact.

Scope: only the named C11-294 artifacts. This does not claim removal from Git history, remote caches, prior downloads, unrelated artifacts, or board comments/metadata. The caller owns those publication boundaries.

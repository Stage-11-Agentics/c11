import json,sys,time
from pathlib import Path
from visual_probe import Target
c=json.loads(Path(sys.argv[1]).read_text());d=Path(sys.argv[1]).parent;t=Target(c,d)
t.post({'kind':'key','keycode':12,'command':True});time.sleep(1)
apps=list(t.A.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']))
if apps:
 img,_,_=t.capture([0,0,int(c['window_bounds']['Width']),int(c['window_bounds']['Height'])]);t.save_png(img,d/'dismiss-pending.png')
else:
 (d/'dismissal.json').write_text(json.dumps({'synthesized':'Command-Q','pid':c['pid'],'bundle':c['bundle_id'],'gone':True,'unix':time.time()},indent=2)+'\n')
print('PENDING' if apps else 'DISMISSED')

#!/usr/bin/env python3
"""Read-only g60 comparison. Recompute nearest-rank percentiles from raw evidence.

Usage: python3 compare.py --control DIR --candidate DIR [--identity JSON] [--out JSON]
       [--evidence-root UNPACKED_RUNTIME_DIR]
Exit 0 = PASS, 1 = FAIL (budget exceeded), 2 = INCOMPLETE (missing/invalid evidence).
No application access, imports of UI drivers, socket calls or subprocesses.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import zlib

PHASES = ("no-churn", "churn", "quiescence")
MINIMUMS = {"typing": 100, "scroll": 40, "switch": 40}
PAIRS = {"typing": ("glyph-a", "glyph-b"), "switch": ("workspace-1", "workspace-2"),
         "scroll": ("scroll-top", "scroll-down")}
LABELS = tuple(label for pair in PAIRS.values() for label in pair)
HASH = re.compile(r"[0-9a-f]{64}")
ORIGINAL_EVIDENCE_ROOT = Path("/tmp/c11-260-perf")


def numeric(value):
    return type(value) in (float, int) and math.isfinite(value)


def near(a, b, tolerance=1e-6):
    return numeric(a) and numeric(b) and abs(a - b) <= tolerance


def stats(values):
    values = sorted(values)
    if not values:
        return {"count": 0, "p50_ms": None, "p95_ms": None, "p99_ms": None, "max_ms": None}
    return {"count": len(values), "mean_ms": sum(values) / len(values),
            **{f"p{p}_ms": values[math.ceil(len(values) * p / 100) - 1] for p in (50, 95, 99)},
            "max_ms": values[-1]}


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON field: " + key)
        result[key] = value
    return result


def decode(text):
    def nonfinite(value):
        raise ValueError("nonfinite JSON number: " + value)
    return json.loads(text, object_pairs_hook=strict_object, parse_constant=nonfinite)


class Audit:
    def __init__(self):
        self.issues = []

    def need(self, ok, where, message):
        if not ok:
            self.issues.append({"location": str(where), "reason": message})
        return bool(ok)

    def read(self, path):
        try:
            value = decode(Path(path).read_text())
            if not isinstance(value, dict):
                raise ValueError("expected a JSON object")
            return value
        except (OSError, ValueError) as error:
            self.need(False, path, str(error))
            return None

    def lines(self, path):
        try:
            lines = Path(path).read_text().splitlines(keepends=True)
        except OSError as error:
            self.need(False, path, str(error))
            return [], 0
        records = []
        for number, line in enumerate(lines, 1):
            where = f"{path}:{number}"
            self.need(line.endswith("\n"), where, "unterminated raw record")
            try:
                row = decode(line)
                if not isinstance(row, dict):
                    raise ValueError("raw record must be an object")
                records.append((row, where))
            except ValueError as error:
                self.need(False, where, str(error))
        return records, len(lines)


def evidence_path(value, root, evidence_root=None):
    path = Path(value)
    if evidence_root is not None and path.is_absolute():
        try:
            relative = path.relative_to(ORIGINAL_EVIDENCE_ROOT)
        except ValueError:
            pass  # Other absolute prefixes are intentionally not rewritten.
        else:
            if ".." in relative.parts:
                raise ValueError("evidence relocation rejects parent traversal: " + str(path))
            destination_root = Path(evidence_root).resolve()
            destination = (destination_root / relative).resolve()
            if not destination.is_relative_to(destination_root):
                raise ValueError("evidence relocation escapes its root through a symlink: " + str(path))
            # Always return the mapped path, including when absent. Never fall
            # back to an old live /tmp artifact that happens to still exist.
            return destination
    return path if path.is_absolute() else root / path


def relocation_info(evidence_root):
    return {"enabled": evidence_root is not None, "original_prefix": str(ORIGINAL_EVIDENCE_ROOT),
            "evidence_root": str(Path(evidence_root).resolve()) if evidence_root is not None else None,
            "policy": "only original-prefix absolute descendants are remapped; no original-path fallback"}


def png(audit, path, roi):
    try:
        data = path.read_bytes()
        if data[:8] != b"\x89PNG\r\n\x1a\n":
            raise ValueError("missing PNG signature")
        offset, header, ended, compressed = 8, None, False, []
        while offset < len(data):
            if offset + 12 > len(data):
                raise ValueError("truncated PNG chunk header")
            size = struct.unpack(">I", data[offset:offset + 4])[0]
            kind = data[offset + 4:offset + 8]
            stop = offset + 12 + size
            if stop > len(data):
                raise ValueError("truncated PNG chunk data")
            payload = data[offset + 8:stop - 4]
            crc = struct.unpack(">I", data[stop - 4:stop])[0]
            if zlib.crc32(kind + payload) & 0xffffffff != crc:
                raise ValueError("PNG chunk CRC mismatch")
            if offset == 8 and kind != b"IHDR":
                raise ValueError("PNG does not start with IHDR")
            if kind == b"IHDR":
                if header is not None or size != 13:
                    raise ValueError("invalid/duplicate PNG IHDR")
                header = struct.unpack(">IIBBBBB", payload)
            elif kind == b"IDAT":
                compressed.append(payload)
            elif kind == b"IEND":
                if size or stop != len(data):
                    raise ValueError("invalid PNG IEND/trailing data")
                ended = True
            offset = stop
        if not ended or header is None or not compressed:
            raise ValueError("PNG missing complete image data or IEND")
        width, height, depth, color, compression, filtering, interlace = header
        if (width, height) != tuple(roi[2:]):
            raise ValueError("PNG crop dimensions differ")
        channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(color)
        allowed_depths = {0: (1, 2, 4, 8, 16), 2: (8, 16), 3: (1, 2, 4, 8), 4: (8, 16), 6: (8, 16)}
        if channels is None or depth not in allowed_depths[color] or compression or filtering or interlace not in (0, 1):
            raise ValueError("invalid PNG pixel format")
        passes = [(0, 0, 1, 1)] if interlace == 0 else [
            (0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4),
            (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2)]
        row_sizes = []
        for x, y, dx, dy in passes:
            w, h = max(0, (width - x + dx - 1) // dx), max(0, (height - y + dy - 1) // dy)
            if w and h:
                row_sizes.extend([1 + (w * channels * depth + 7) // 8] * h)
        expected = sum(row_sizes)
        stream = zlib.decompressobj()
        pixels = stream.decompress(b"".join(compressed), expected + 1)
        if len(pixels) != expected or not stream.eof or stream.unused_data or stream.unconsumed_tail:
            raise ValueError("PNG image data incomplete or wrong decoded length")
        offset = 0
        for size in row_sizes:
            if pixels[offset] > 4:
                raise ValueError("invalid PNG scanline filter")
            offset += size
    except (OSError, ValueError, struct.error, zlib.error) as error:
        audit.need(False, path, str(error))


def templates(audit, config, root, evidence_root=None):
    result = {}
    mapping = config.get("templates")
    if not audit.need(isinstance(mapping, dict), root, "missing template map"):
        return result
    audit.need(config.get("templates_visually_verified") is True, root, "template visual review missing")
    for label in LABELS:
        path = mapping.get(label)
        if not audit.need(isinstance(path, str) and bool(path), root, f"missing {label} template file"):
            continue
        file = evidence_path(path, root, evidence_root)
        template = audit.read(file)
        if template is None:
            continue
        roi = template.get("roi")
        shape = (isinstance(roi, list) and len(roi) == 4 and all(type(x) is int for x in roi)
                 and min(roi[:2]) >= 0 and min(roi[2:]) > 0)
        audit.need(shape, file, "invalid template ROI")
        audit.need(template.get("label") == label, file, "template semantic label mismatch")
        semantic = template.get("semantic_expectation")
        audit.need(isinstance(semantic, str) and bool(semantic.strip()), file, "missing semantic expectation")
        sha = template.get("sha256")
        audit.need(isinstance(sha, str) and bool(HASH.fullmatch(sha)), file, "invalid template SHA256")
        try:
            pixels = evidence_path(template["pixels"], root, evidence_root).read_bytes()
            audit.need(hashlib.sha256(pixels).hexdigest() == sha, file, "template pixel hash mismatch")
            if shape:
                audit.need(len(pixels) == roi[2] * roi[3] * 4, file, "template byte count != 32-bit ROI")
                png(audit, evidence_path(template["screenshot"], root, evidence_root), roi)
        except (OSError, KeyError, TypeError, ValueError) as error:
            audit.need(False, file, "template evidence unavailable: " + str(error))
        result[label] = template
    for one, two in PAIRS.values():
        if one in result and two in result:
            audit.need(result[one].get("roi") == result[two].get("roi"), root, "paired template geometry differs")
            audit.need(result[one].get("sha256") != result[two].get("sha256"), root,
                       "negative control is identical to expected template")
    return result


def timing(audit, frame, where):
    if not audit.need(isinstance(frame, dict), where, "capture timing must be an object"):
        return None
    begin, end = frame.get("capture_begin_ns"), frame.get("capture_end_ns")
    good = type(begin) is int and type(end) is int and 0 < begin <= end
    audit.need(good, where, "invalid monotonic capture timestamps")
    sha = frame.get("sha256")
    audit.need(isinstance(sha, str) and bool(HASH.fullmatch(sha)), where, "invalid frame SHA256")
    if not good:
        return None
    overhead = (end - begin) / 1e6
    audit.need(near(frame.get("capture_ms"), overhead), where, "capture_ms disagrees with raw timestamps")
    return overhead


def samples(audit, root, phase, info, known, config):
    records, line_count = audit.lines(root / phase / "samples.jsonl")
    result = {metric: {"raw_count": 0, "reported_ok": 0, "errors": Counter(), "timeouts": 0,
                       "latencies": [], "captures": [], "pre_captures": [], "setup": [], "invalid_rows": 0,
                       "failed_trials": []}
              for metric in MINIMUMS}
    seen = set()
    schedule = []
    for number, (row, where) in enumerate(records):
        prior_issues = len(audit.issues)
        metric = row.get("metric")
        if not audit.need(metric in MINIMUMS, where, "unknown/missing probe metric"):
            continue
        bucket = result[metric]
        bucket["raw_count"] += 1
        ident = row.get("id")
        valid_id = isinstance(ident, str) and re.fullmatch(re.escape(phase) + r"-\d{3}-" + metric, ident)
        audit.need(bool(valid_id) and ident not in seen, where, "invalid or duplicate sample ID")
        if valid_id:
            audit.need(int(ident.split("-")[-2]) == number, where, "raw sample sequence has a gap or reorder")
            seen.add(ident)
        scheduled, completed = row.get("scheduled"), row.get("completed")
        start, deadline = info.get("start"), info.get("deadline")
        times = all(numeric(v) for v in (scheduled, completed, start, deadline))
        audit.need(times and start <= scheduled <= completed <= deadline, where, "sample missing times or outside fixed phase")
        if times:
            schedule.append((metric, round(scheduled - start, 6)))
        setup = row.get("setup_ms")
        if audit.need(numeric(setup) and setup >= 0, where, "missing/invalid setup overhead"):
            bucket["setup"].append(setup)
        pre = row.get("pre_capture")
        overhead = timing(audit, pre, where + ":pre_capture")
        if overhead is not None:
            bucket["pre_captures"].append(overhead)
        frames = row.get("frames")
        if not audit.need(isinstance(frames, list), where, "missing raw frame list"):
            frames = []
        previous_end = pre.get("capture_end_ns", 0) if isinstance(pre, dict) else 0
        for i, frame in enumerate(frames):
            overhead = timing(audit, frame, f"{where}:frame{i}")
            if overhead is not None:
                bucket["captures"].append(overhead)
                audit.need(frame["capture_begin_ns"] >= previous_end, where, "capture frames out of order")
                previous_end = frame["capture_end_ns"]
        ok = row.get("ok")
        audit.need(type(ok) is bool, where, "ok must be a boolean")
        if ok is not True:
            error = row.get("error", "unreported_error")
            bucket["errors"][str(error)] += 1
            bucket["timeouts"] += int("timeout" in str(error))
            bucket["failed_trials"].append({"id": ident, "error": error, "location": where,
                                           "scheduled": scheduled, "completed": completed,
                                           "input_post_ns": row.get("input_post_ns"),
                                           "timeout_s": row.get("timeout_s"), "frame_count": len(frames)})
            # The reviewed contract sets minimum valid counts, not zero failures.
            # Preserve failed observations and their evidence without inventing a
            # latency for an input that was never posted or never visibly matched.
            before_label, after_label = row.get("before"), row.get("expected")
            audit.need({before_label, after_label} == set(PAIRS[metric]), where, "wrong failed-trial template semantics")
            before, after = known.get(before_label), known.get(after_label)
            available = before is not None and after is not None
            audit.need(available, where, "failed trial references unavailable templates")
            if available:
                audit.need(row.get("roi") == before.get("roi") == after.get("roi"), where, "failed-trial ROI mismatch")
            audit.need("latency_ms" not in row, where, "failed trial falsely reports matched latency")
            if error == "precondition_template_mismatch":
                audit.need(not frames and "input_post_ns" not in row, where, "precondition failure contains posted-input evidence")
                if available and isinstance(pre, dict):
                    audit.need(pre.get("sha256") != before.get("sha256"), where, "precondition failure actually matches prior template")
                    if valid_id:
                        png(audit, root / "crops" / f"{ident}-bad-precondition.png", before["roi"])
            elif error == "expected_state_timeout":
                posted = row.get("input_post_ns")
                audit.need(numeric(row.get("timeout_s")) and row["timeout_s"] == 1, where, "missing timeout duration")
                ns_ok = type(posted) is int and posted > 0 and isinstance(pre, dict)
                ns_ok = ns_ok and type(pre.get("capture_end_ns")) is int and pre["capture_end_ns"] <= posted
                ns_ok = ns_ok and bool(frames) and all(isinstance(f, dict) and type(f.get("capture_begin_ns")) is int
                                                      and type(f.get("capture_end_ns")) is int for f in frames)
                if audit.need(ns_ok, where, "timeout lacks raw posted-input/capture evidence"):
                    audit.need(frames[0]["capture_begin_ns"] >= posted, where, "timeout frame preceded input")
                    if times:
                        audit.need(scheduled <= posted / 1e9 <= frames[-1]["capture_end_ns"] / 1e9 <= completed + .001,
                                   where, "timeout timestamps outside sample interval")
                if available:
                    audit.need(isinstance(pre, dict) and pre.get("sha256") == before.get("sha256"), where,
                               "timeout does not start from prior template")
                    audit.need(all(isinstance(f, dict) and (f.get("sha256") != after.get("sha256")
                                   or (type(f.get("capture_end_ns")) is int and type(posted) is int
                                       and f["capture_end_ns"] > posted + 1_000_000_000)) for f in frames),
                               where, "timeout actually contains expected state within the one-second limit")
                    if valid_id:
                        for suffix in ("before", "after"):
                            png(audit, root / "crops" / f"{ident}-{suffix}.png", after["roi"])
            else:
                audit.need(False, where, "unrecognized/missing failed-observation outcome: " + str(error))
        else:
            bucket["reported_ok"] += 1
            audit.need(not row.get("error") and "timeout_s" not in row, where, "successful row contains error/timeout")
            before_label, after_label = row.get("before"), row.get("expected")
            audit.need({before_label, after_label} == set(PAIRS[metric]), where, "wrong expected/before semantics for metric")
            action = row.get("action")
            if audit.need(isinstance(action, dict), where, "missing raw synthesized-input action"):
                if metric == "typing":
                    audit.need(action.get("kind") == "key" and after_label in PAIRS[metric]
                               and action.get("text") == after_label[-1], where, "typing input does not target expected glyph")
                elif metric == "switch":
                    audit.need(action.get("kind") == "key" and action.get("command") is True
                               and action.get("keycode") == (18 if after_label == "workspace-1" else 19),
                               where, "switch input does not target expected workspace")
                else:
                    pixels = config.get("scroll_pixels")
                    audit.need(action.get("kind") == "scroll" and action.get("point") == config.get("sidebar_point")
                               and numeric(pixels) and action.get("pixels") == -pixels
                               and before_label == "scroll-top" and after_label == "scroll-down",
                               where, "scroll input does not match calibrated endpoint")
            before, after = known.get(before_label), known.get(after_label)
            if audit.need(before is not None and after is not None, where, "sample references unavailable template"):
                audit.need(row.get("roi") == before.get("roi") == after.get("roi"), where, "sample/template ROI mismatch")
                audit.need(isinstance(pre, dict) and pre.get("sha256") == before.get("sha256"), where, "prior state negative control missing")
                audit.need(bool(frames) and isinstance(frames[-1], dict)
                           and frames[-1].get("sha256") == after.get("sha256"), where, "accepted frame is not expected state")
                audit.need(all(isinstance(f, dict) and f.get("sha256") != after.get("sha256") for f in frames[:-1]),
                           where, "latency did not stop on first expected frame")
            posted = row.get("input_post_ns")
            ns_ok = type(posted) is int and posted > 0 and isinstance(pre, dict)
            ns_ok = ns_ok and type(pre.get("capture_end_ns")) is int and pre["capture_end_ns"] <= posted
            ns_ok = ns_ok and bool(frames) and all(isinstance(f, dict) and type(f.get("capture_begin_ns")) is int
                                                  and type(f.get("capture_end_ns")) is int for f in frames)
            if audit.need(ns_ok, where, "missing/invalid raw input-to-frame timestamps"):
                audit.need(frames[0]["capture_begin_ns"] >= posted, where, "frame preceded posted input")
                latency = (frames[-1]["capture_end_ns"] - posted) / 1e6
                audit.need(0 <= latency <= 1000 and near(row.get("latency_ms"), latency), where,
                           "reported latency disagrees with raw input/expected-frame timestamps")
                if times:
                    audit.need(scheduled <= posted / 1e9 <= frames[-1]["capture_end_ns"] / 1e9 <= completed + 0.001,
                               where, "raw timestamps outside sample's monotonic interval")
            if valid_id and after is not None and isinstance(after.get("roi"), list):
                for suffix in ("before", "after"):
                    png(audit, root / "crops" / f"{ident}-{suffix}.png", after["roi"])
            if len(audit.issues) == prior_issues:
                bucket["latencies"].append(latency)
        if len(audit.issues) != prior_issues:
            bucket["invalid_rows"] += 1
    output = {}
    for metric, bucket in result.items():
        valid = len(bucket["latencies"])
        audit.need(valid >= MINIMUMS[metric], root / phase, f"{metric}: {valid} valid < {MINIMUMS[metric]} required")
        claimed = info.get("metrics", {}).get(metric, {})
        audit.need(claimed.get("valid") == bucket["reported_ok"] and claimed.get("errors") == sum(bucket["errors"].values()),
                   root / phase, f"{metric}: summary counts disagree with raw records")
        output[metric] = {"raw_count": bucket["raw_count"], "valid": valid, "reported_ok": bucket["reported_ok"],
                          "invalid_rows": bucket["invalid_rows"], "error_count": sum(bucket["errors"].values()),
                          "errors": dict(bucket["errors"]), "timeout_count": bucket["timeouts"],
                          "failed_trials": bucket["failed_trials"],
                          "latency": stats(bucket["latencies"]), "capture_overhead": stats(bucket["captures"]),
                          "pre_capture_overhead": stats(bucket["pre_captures"]), "setup_overhead": stats(bucket["setup"])}
    return {"raw_line_count": line_count, "decoded_count": len(records), "metrics": output, "schedule": schedule}


def churn(audit, root, info, mode):
    records, lines = audit.lines(root / "churn" / "operations.jsonl")
    counts = Counter()
    errors = []
    lateness = []
    late_starts = []
    for index, (row, where) in enumerate(records):
        method = row.get("method")
        counts[str(method)] += 1
        audit.need(row.get("n") == index, where, "operation sequence missing/reordered")
        for key in ("scheduled", "started", "completed"):
            audit.need(numeric(row.get(key)), where, "missing/invalid " + key)
        times = [row.get(k) for k in ("scheduled", "started", "completed")]
        if all(numeric(t) for t in times) and numeric(info.get("start")) and numeric(info.get("deadline")):
            scheduled, started, completed = times
            audit.need(near(scheduled, info["start"] + index / 10), where, "operation was not scheduled at 10 Hz")
            audit.need(scheduled <= started <= completed <= info["deadline"],
                       where, "operation out of order or outside phase")
            lateness.append((started - scheduled) * 1000)
            if started >= scheduled + .1:
                late_starts.append({"n": row.get("n"), "scheduled": scheduled, "started": started,
                                    "completed": completed, "lateness_ms": lateness[-1]})
        if row.get("outcome") != "ok" or row.get("error"):
            errors.append({"n": row.get("n"), "error": row.get("error", row.get("outcome"))})
            audit.need(False, where, "failed churn operation")
        expected = row.get("expected_after", {})
        order = expected.get("order")
        members = expected.get("membership")
        audit.need(isinstance(order, list) and len(order) == 60 and len(set(order)) == 60
                   and isinstance(members, dict) and set(members) == set(order), where,
                   "missing/incomplete per-operation order/membership oracle")
        required_category = ("reorder", "transfer", "flag", "waiting_suppression")[index % 4]
        allowed = {"reorder": {"workspace.reorder"}, "transfer": {"workspace.group.move"},
                   "flag": {"flag.raise", "flag.lower"}, "waiting_suppression": {"flag.suppress", "flag.unsuppress"}}
        audit.need(row.get("category") == required_category and method in allowed[required_category],
                   where, "operation mix/alternation mismatch")
        audit.need(isinstance(row.get("selected_before"), str) and row.get("selected_before") == row.get("selected_after"),
                   where, "non-focus mutation selection proof missing/mismatched")
        params = row.get("params")
        if audit.need(isinstance(params, dict), where, "missing operation parameters"):
            audit.need(isinstance(params.get("window_id"), str) and isinstance(params.get("workspace_id"), str),
                       where, "missing explicit operation identities")
            if method == "workspace.reorder":
                audit.need(type(params.get("index")) is int and 0 <= params["index"] < 60,
                           where, "paired reorder must use absolute index")
            elif method == "workspace.group.move":
                audit.need("to_group_id" in params and (params["to_group_id"] is None or isinstance(params["to_group_id"], str)),
                           where, "missing transfer destination")
    expected_counts = {"workspace.reorder": 150, "workspace.group.move": 150,
                       "flag.raise": 75, "flag.lower": 75, "flag.suppress": 76, "flag.unsuppress": 74}
    audit.need(lines == len(records) == 600 and dict(counts) == expected_counts, root / "churn", "wrong raw churn count/mix")
    declared = info.get("churn", {})
    audit.need(declared.get("completed_count") == len(records) and declared.get("method_counts") == dict(counts),
               root / "churn", "declared churn counts differ from raw operations")
    audit.need(declared.get("pending") is False and declared.get("alive") is False
               and not declared.get("error") and declared.get("overrun") is False,
               root / "churn", "worker not joined/clean or declared overrun")
    audit.need(declared.get("late") == len(late_starts), root / "churn", "declared late-start count differs from raw operations")
    return {"raw_line_count": lines, "decoded_count": len(records), "method_counts": dict(counts),
            "errors": errors, "achieved_hz": (len(records) - len(errors)) / 60,
            "late_start_count": len(late_starts), "late_starts": late_starts,
            "start_lateness": stats(lateness)}


def load_run(audit, root, mode, evidence_root=None):
    root = Path(root).resolve()
    run = audit.read(root / "run.json")
    output = {"directory": str(root), "mode": mode, "phases": {}}
    if run is None:
        return output, {}, {}
    audit.need(run.get("complete") is True, root, "run not complete")
    output["runner_reported_complete"] = run.get("complete")
    output["runner_error"] = run.get("error")
    config = run.get("config", {})
    check_config = isinstance(config, dict)
    audit.need(check_config, root, "config is not an object")
    config = config if check_config else {}
    known = templates(audit, config, root, evidence_root)
    phases = run.get("phases")
    if not audit.need(isinstance(phases, list) and all(isinstance(p, dict) for p in phases), root, "invalid phase records"):
        return output, config, known
    audit.need([p.get("name") for p in phases] == list(PHASES), root, "expected exactly ordered no-churn/churn/quiescence")
    previous_end = None
    for phase in phases:
        name = phase.get("name")
        if name not in PHASES:
            continue
        # Old runner flags included unsupported zero-error/zero-lateness gates.
        # Recompute the reviewed phase criteria from raw evidence and preserve
        # the old flag rather than using it to override valid measured evidence.
        audit.need(phase.get("model_verified") is True, root / name, "complete model verification missing")
        start, deadline, ended = phase.get("start"), phase.get("deadline"), phase.get("ended")
        times = all(numeric(t) for t in (start, deadline, ended))
        audit.need(times and near(deadline - start, 60) and ended >= deadline, root / name, "phase is not a fixed completed 60 seconds")
        if times and previous_end is not None:
            audit.need(start >= previous_end, root / name, "phases overlap")
        previous_end = ended if times else None
        audit.need(phase.get("last_probe_overrun") is False, root / name, "declared probe overrun/missing status")
        output["phases"][name] = samples(audit, root, name, phase, known, config)
        output["phases"][name]["runner_reported_complete"] = phase.get("complete")
        if name == "churn":
            output["churn"] = churn(audit, root, phase, mode)
        else:
            ops = root / name / "operations.jsonl"
            audit.need(not ops.exists() or ops.stat().st_size == 0, ops, "mutations logged in a non-churn phase")
    return output, config, known


def compare(control, candidate, identity=None, evidence_root=None):
    audit = Audit()
    if evidence_root is not None and not Path(evidence_root).is_dir():
        raise ValueError("--evidence-root must name an existing unpacked runtime directory")
    left, lc, lt = load_run(audit, control, "control", evidence_root)
    right, rc, rt = load_run(audit, candidate, "candidate", evidence_root)
    matched = {}
    for key in ("host", "transport_host", "display_id", "terminal_point", "sidebar_point", "scroll_pixels", "refresh_hz", "physical_pixels",
                "theme", "font", "scale", "sidebar_width", "calibration_spec_sha256"):
        same = key in lc and key in rc and lc[key] == rc[key]
        audit.need(same, "paired config", "missing or mismatched " + key)
        matched[key] = {"control": lc.get(key), "candidate": rc.get(key), "equal": same}
    audit.need(lc.get("transport_host") == rc.get("transport_host") == "validation-host", "paired config", "runs not identified as validation-host")
    for key in ("Width", "Height"):
        l = lc.get("window_bounds", {}).get(key)
        r = rc.get("window_bounds", {}).get(key)
        audit.need(numeric(l) and l > 0 and l == r, "paired config", "missing or mismatched window " + key)
        matched["window_" + key] = {"control": l, "candidate": r, "equal": l == r}
    audit.need(lc.get("setup_settle_s", .08) == rc.get("setup_settle_s", .08), "paired config", "setup settle time differs")
    for label in LABELS:
        for key in ("roi", "label", "semantic_expectation"):
            audit.need(label in lt and label in rt and lt[label].get(key) == rt[label].get(key),
                       "paired templates", f"{label}: missing or mismatched {key}")
    comparisons = []
    failures = []
    for phase in PHASES:
        lp, rp = left["phases"].get(phase), right["phases"].get(phase)
        if lp is None or rp is None:
            continue
        audit.need(lp["schedule"] == rp["schedule"], phase, "paired raw probe schedule differs")
        for metric in MINIMUMS:
            item = {"phase": phase, "metric": metric, "percentiles": {}}
            for percentile, factor, additive in ((95, 1.20, 5), (99, 1.25, 15)):
                key = f"p{percentile}_ms"
                c, v = lp["metrics"][metric]["latency"][key], rp["metrics"][metric]["latency"][key]
                limit = max(c * factor, c + additive) if c is not None else None
                passed = v <= limit if v is not None and limit is not None else None
                item["percentiles"][key] = {"control_ms": c, "candidate_ms": v, "limit_ms": limit, "pass": passed}
                if passed is False:
                    failures.append({"phase": phase, "metric": metric, "percentile": percentile, "candidate_ms": v, "limit_ms": limit})
            comparisons.append(item)
    audit.need(len(comparisons) == 9, "comparison", "missing one or more of nine metric/phase pairs")
    provenance = audit.read(identity) if identity else None
    audit.need(provenance is not None, "identity", "W2 requires explicit source/build provenance")
    verification = w2_evidence(audit, control, candidate, lc, rc, provenance, evidence_root)
    return {"status": "INCOMPLETE" if audit.issues else "FAIL" if failures else "PASS",
            "scope": "C11-260 g60-w2-v1 raw visual latency and required structural evidence; human UI/drag acceptance remains separate",
            "w2_evidence": verification,
            "percentile_method": "nearest rank: sorted_values[ceil(n*p/100)-1]",
            "latency_source": "first expected-frame capture_end_ns minus input_post_ns; no overhead subtracted",
            "error_policy": "minimum valid samples are required; all failed probes and late starts are retained as diagnostics; no zero-error or per-operation lateness budget was specified",
            "control": left, "candidate": right, "paired_configuration": matched,
            "comparisons": comparisons, "budget_failures": failures, "incomplete_reasons": audit.issues,
            "identity_file": str(identity) if identity else None, "identity_evidence": provenance,
            "evidence_relocation": relocation_info(evidence_root),
            "identity_verification": "attached, not independently authenticated" if identity else "not supplied"}


def w2_evidence(audit, control, candidate, lc, rc, identity, evidence_root):
    from g60 import next_operation, assert_model
    roots = {"control": Path(control).resolve(), "candidate": Path(candidate).resolve()}
    semantic_initial, semantic_operations = {}, {}
    for role, root in roots.items():
        run = audit.read(root / "run.json") or {}
        manifest_path = run.get("manifest")
        if not audit.need(isinstance(manifest_path, str), root, "manifest path missing"): continue
        manifest = audit.read(evidence_path(manifest_path, root, evidence_root))
        if manifest is None: continue
        initial = manifest.get("initial", {})
        labels = manifest.get("labels", {})
        inverse = {v: k for k, v in labels.items()}
        group_names = {v: k for k, v in manifest.get("groups", {}).items()}
        def normalize(value):
            if isinstance(value, str): return inverse.get(value, group_names.get(value, value))
            if isinstance(value, list): return [normalize(v) for v in value]
            if isinstance(value, dict): return {normalize(k): normalize(v) for k, v in value.items()}
            return value
        semantic_initial[role] = {"order": normalize(initial.get("order")), "pins": normalize(initial.get("pins")),
                                  "membership": normalize(initial.get("membership")), "attention": initial.get("attention"),
                                  "tabs": {inverse.get(ws, ws): [t["type"] for t in tabs]
                                           for ws, tabs in initial.get("tabs", {}).items()},
                                  "groups": [{k: normalize(g.get(k)) for k in ("name", "is_pinned", "is_collapsed", "member_workspace_ids")}
                                             for g in initial.get("groups", [])]}
        audit.need(manifest.get("version") == "g60-w2-v1" and manifest.get("mode") == role,
                   root, "wrong fixture version/role")
        expected = manifest.get("expected")
        records, _ = audit.lines(root / "churn" / "operations.jsonl")
        semantic_operations[role] = []
        try:
            for index, (record, where) in enumerate(records):
                method, params, predicted = next_operation(manifest, expected, index)
                audit.need(record.get("method") == method and record.get("params") == params
                           and record.get("expected_after") == predicted, where, "raw operation differs from frozen semantic oracle")
                if record.get("outcome") == "ok": expected = predicted
                semantic_operations[role].append(normalize(expected))
            for phase in PHASES:
                expected_phase = manifest["expected"] if phase == "no-churn" else expected
                snapshot = audit.read(root / phase / "after.json")
                if snapshot:
                    samples_raw, _ = audit.lines(root / phase / "samples.jsonl")
                    selected = samples_raw[-1][0].get("selected_workspace_id") if samples_raw else None
                    assert_model(snapshot["state"], manifest, expected_phase, selected)
                    for row, where in samples_raw:
                        if row.get("metric") == "switch" and row.get("ok"):
                            audit.need(row.get("observed_selected_workspace_id") == row.get("intended_selected_workspace_id")
                                       == row.get("selected_workspace_id"), where, "switch selection oracle missing/mismatched")
        except (KeyError, ValueError, RuntimeError, TypeError) as error:
            audit.need(False, root, "model replay failed: " + str(error))
        try:
            from prime_gate import evaluate
            fixture_dir = evidence_path(manifest_path, root, evidence_root).parent
            creation_log = (fixture_dir / "creation-prime.log").read_text()
            audit.need(evaluate(creation_log, manifest, max_mounts=2)["complete"], root, "creation prime/mount cap proof failed")
        except Exception as error: audit.need(False, root, "creation mount proof: " + str(error))
        readiness = audit.read(root / "readiness.json") or {}
        warmup = audit.read(root / "warmup.json") or {}
        audit.need(readiness.get("complete") is True and readiness.get("debug_retention_disabled") is True,
                   root, "observed priming/debug-retention proof missing")
        if readiness.get("log_path"):
            try:
                from prime_gate import evaluate
                log = evidence_path(readiness["log_path"], root, evidence_root).read_text()
                audit.need(evaluate(log, manifest)["complete"], root, "raw priming log does not settle")
            except Exception as error: audit.need(False, root, "priming raw evidence: " + str(error))
        else: audit.need(False, root, "priming log path missing")
        audit.need(warmup.get("requested_s") == 60 and numeric(warmup.get("start"))
                   and numeric(warmup.get("end")) and 60 <= warmup["end"] - warmup["start"] < 61,
                   root, "fixed matched 60-second warmup missing/overrun")
        role_identity = (identity or {}).get(role, {})
        for key in ("source_sha", "base_sha", "merge_base_sha", "remote_build_invocation", "build_options"):
            audit.need(bool(role_identity.get(key)), role, "missing provenance " + key)
        audit.need(role_identity.get("source_tree_dirty") is False, role, "source tree cleanliness not recorded")
        audit.need(role_identity.get("source_sha") == manifest.get("source_sha"), role, "fixture source SHA differs from provenance")
        config = lc if role == "control" else rc
        try:
            from appearance import validate
            spec_path=evidence_path(config["calibration_spec_path"], root, evidence_root)
            spec_bytes=spec_path.read_bytes()
            audit.need(hashlib.sha256(spec_bytes).hexdigest()==config["calibration_spec_sha256"], role, "Frozen calibration spec bytes differ")
            observed=validate(config,decode(spec_bytes),config.get("appearance_review",{}),
                              (root.parent/"calibration/setup-config.json").read_bytes(),
                              (root.parent/"calibration/setup.png").read_bytes())
            audit.need(all(config.get(k)==v for k,v in observed.items()),role,"Configuration appearance is not observed evidence")
        except Exception as error: audit.need(False,role,"Observed settings evidence: "+str(error))
        audit.need(role_identity.get("artifact_sha256") == config.get("artifact_sha256")
                   and bool(config.get("artifact_sha256")), role, "exact GUI/dylib/CLI hashes missing or mismatched")
        audit.need(bool(role_identity.get("script_sha256")), role, "frozen harness hashes missing")
        audit.need(role_identity.get("calibration_spec_sha256") == config.get("calibration_spec_sha256"),
                   role, "calibration specification differs from frozen provenance")
        archive = Path(evidence_root).resolve() if evidence_root else ORIGINAL_EVIDENCE_ROOT
        for name, sha in role_identity.get("script_sha256", {}).items():
            try:
                audit.need(Path(name).name == name and hashlib.sha256((archive/name).read_bytes()).hexdigest() == sha,
                           role, "frozen helper hash mismatch: " + name)
            except OSError as error: audit.need(False, role, str(error))
        try:
            audit.need(hashlib.sha256((archive/"PROTOCOL.md").read_bytes()).hexdigest() == role_identity.get("protocol_sha256"),
                       role, "frozen protocol hash missing/mismatched")
        except OSError as error: audit.need(False, role, str(error))
        if role == "candidate":
            audit.need(role_identity.get("script_sha256") == (identity or {}).get("control", {}).get("script_sha256"),
                       "paired provenance", "harness hashes differ")
    audit.need(len(semantic_initial) == 2 and semantic_initial.get("control") == semantic_initial.get("candidate"),
               "fixture", "paired semantic initial state/composition differs")
    audit.need(len(semantic_operations) == 2 and semantic_operations.get("control") == semantic_operations.get("candidate"),
               "mutations", "paired semantic mutation sequence differs")
    pair_root = roots["control"].parent.parent
    audit.need(pair_root == roots["candidate"].parent.parent, "pair", "roles are not in same attempt directory")
    lease = audit.read(pair_root / "lease.json") or {}
    rows, _ = audit.lines(pair_root / "load.jsonl")
    active = [r for r, _ in rows if r.get("ready")]
    audit.need(lease.get("released") is True and lease.get("release_reason") == "pair-complete"
               and lease.get("release_before_cap") is True, pair_root, "pair release/cap not proven")
    audit.need(bool(active), pair_root, "continuous ready-window load record missing")
    for previous, current in zip(active, active[1:]):
        audit.need(0 < current["monotonic"] - previous["monotonic"] < 2,
                   pair_root, "load stream gap exceeds 1 Hz tolerance")
    high = [r for r in active if r.get("load", [999])[0] >= 8]
    audit.need(not high and not (pair_root / "contamination.json").exists(), pair_root,
               "quiet window interrupted; explicit attribution/ruling required (never automatic PASS)")
    audit.need(bool(list(pair_root.glob("processes-*.json"))), pair_root, "process CPU attribution snapshots missing")
    if active:
        audit.need(active[-1]["monotonic"] >= lease.get("released_monotonic", float("inf")) - 2,
                   pair_root, "load record does not reach release")
    for role, root in roots.items():
        ui = audit.read(root.parent / "ui-lease.json") or {}
        audit.need(ui.get("released") is True and ui.get("synthesized_dismissal") is True
                   and ui.get("process_gone") is True and not ui.get("expired"), role,
                   "normal bounded UI lease and synthesized dismissal not proven")
        if active and numeric(ui.get("started_monotonic")) and numeric(ui.get("released_monotonic")):
            audit.need(active[0]["monotonic"] <= ui["started_monotonic"] and active[-1]["monotonic"] >= ui["released_monotonic"] - 1,
                       role, "continuous load does not span UI role")
        if numeric(ui.get("released_monotonic")) and numeric(ui.get("deadline_monotonic")):
            audit.need(ui["released_monotonic"] <= ui["deadline_monotonic"], role, "UI cap exceeded")
    return {"fixture": semantic_initial, "load_samples": len(active), "high_load_samples": high,
            "source_provenance": "recorded artifact hashes matched; Git/build claims remain independently reviewable attestations"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--identity", help="required for W2 PASS: separately captured source/build identity JSON")
    parser.add_argument("--out", help="write machine-readable report; otherwise stdout")
    parser.add_argument("--evidence-root", help="map only absolute /tmp/c11-260-perf descendants into this unpacked runtime directory")
    args = parser.parse_args()
    try:
        report = compare(args.control, args.candidate, args.identity, args.evidence_root)
    except Exception as error:
        report = {"status": "INCOMPLETE", "incomplete_reasons": [{"location": "parser", "reason": str(error)}],
                  "evidence_relocation": relocation_info(args.evidence_root)}
    text = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.out:
        Path(args.out).write_text(text)
    else:
        print(text, end="")
    raise SystemExit({"PASS": 0, "FAIL": 1, "INCOMPLETE": 2}[report["status"]])


if __name__ == "__main__":
    main()

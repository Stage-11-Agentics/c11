"""Install the same synthetic raw-terminal command into both owned probe tabs."""
import argparse
import sys
import time
from pathlib import Path
from g60 import RPC, probe_commands
from lease import atomic, read
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',required=True);a=p.parse_args()
path=Path(a.manifest);m=read(path)
commands=probe_commands(m,str(Path(__file__).with_name('probe_terminal.py')),sys.executable)
with RPC(m['tag'],m['socket']) as rpc:
    for item in commands['commands']:
        params={'window_id':m['initial']['window_id'],'workspace_id':item['workspace_id']}
        rpc.call('workspace.select',**params)
        rpc.call('tab.send_text',**params,tab_id=item['tab_id'],text=item['command'])
        rpc.call('tab.send_key',**params,tab_id=item['tab_id'],key='enter')
        time.sleep(.4)
        item['read_text']=rpc.call('tab.read_text',**params,tab_id=item['tab_id'])
        if item['marker'] not in item['read_text']['text']:raise RuntimeError('Probe marker missing')
    rpc.call('workspace.select',window_id=m['initial']['window_id'],workspace_id=m['labels']['w01'])
atomic(path.parent/'probe-install.json',commands)

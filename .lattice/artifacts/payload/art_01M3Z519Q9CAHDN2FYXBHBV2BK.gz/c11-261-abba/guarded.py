"""Wrap one authorized setup/run helper; revoke pair on any failure or interruption."""
import argparse
from pathlib import Path
import subprocess
import sys
from lease import request_release, require_runtime, verify_seal, TAGS
ALLOWED={'g60.py','configure.py','install_probes.py','calibrate.py','prime_gate.py','run_phases.py'}
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--role',choices=TAGS,required=True)
p.add_argument('script',choices=sorted(ALLOWED));p.add_argument('args',nargs=argparse.REMAINDER);a=p.parse_args()
try:
    require_runtime(TAGS[a.role])
    verify_seal(a.role)
    proc=subprocess.run([sys.executable,str(Path(__file__).with_name(a.script)),*a.args])
    if proc.returncode:raise RuntimeError(f'{a.script} exited {proc.returncode}')
except BaseException as error:
    request_release('helper-error: '+str(error));raise

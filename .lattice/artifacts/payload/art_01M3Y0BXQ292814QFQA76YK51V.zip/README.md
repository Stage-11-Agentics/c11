# C11-302 remaining pointer proof gap

Code and other validation remain at pushed head `2f63e9b3c88265aa61879ceca70fc345fc610b7b`. The earlier evidence artifact records nine passing focused tests, the passing matched 30-stream/100-input comparison, and font/color/config/final-output observations.

After the shared UI reservation ended, one bounded lease used the same tagged candidate. A guarded physical wheel event, then a click followed by another wheel event, produced no visible scrolling. The scrollbar thumb could not be exposed for a drag. Earlier PID-scoped wheel and text-drag attempts likewise produced no visible response. These are failed validation attempts, not proof of a product regression or success. No further exploratory runs were performed under the capacity instruction.

The attached private measurement-helper source guards each physical pointer event by exact tagged executable/PID, active app, AX-focused window geometry, verified display, and front-to-back topmost window at the point. It uses physical pointer delivery only for mouse/scroll events; keyboard events remain PID-scoped. It was not added to the product PR diff. Posted-event JSON does not establish event handling.

Images contain only synthetic terminal rows and show the unchanged viewport. The owner invoked the target app menu Hide through PID-scoped Accessibility, observed no on-screen owned windows in the following enumeration, terminated the exact owned app through the lease guard, and released the UI slot. No tagged candidate remains running.

Next recoverable action: Validator uses its established pointer path on the tagged candidate to scroll the finite-output terminal, drag the scrollbar thumb in both directions, and capture changed viewport rows plus final thumb/viewport agreement. Record callback counters and final sentinel. This remaining gate must pass before review handoff; no PR or review-ready claim has been made.

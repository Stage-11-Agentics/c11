"""Explicit Atlas-only pair reservation. Guardian is the sole owner of both flock FDs.

The supervisor handles slow process snapshots. The independent guardian has no
subprocess/ps dependency and closes its own descriptors on EOF, error, request,
or the first-acquisition deadline. No app launch or benchmark is performed here.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import platform
import select
import signal
import subprocess
import sys
import time
import uuid
from lease import atomic, read, request_release


def guardian(root, parent_pipe):
    slots = []
    state = {'owner': 'C11-261', 'pid': os.getpid(), 'host': platform.node(),
             'token': uuid.uuid4().hex, 'ready': False, 'released': False,
             'acquired': [], 'cap_s': 2700, 'heartbeat_monotonic': time.monotonic()}
    reason = 'guardian-error'
    def interrupted(signum, frame):
        raise RuntimeError('signal-' + str(signum))
    signal.signal(signal.SIGTERM, interrupted); signal.signal(signal.SIGINT, interrupted)
    atomic(root / 'lease.json', state)
    try:
        acquire_timeout = time.monotonic() + 2700  # Also bound waiting for the first slot.
        next_load = 0
        with (root / 'load.jsonl').open('x') as log:
            while True:
                now = time.monotonic()
                # Close before the cap, allowing scheduler wakeup jitter without extending it.
                if now >= state.get('deadline_monotonic', acquire_timeout) - .25:
                    reason = '45-minute-cap'; break
                if select.select([parent_pipe], [], [], 0)[0] and not os.read(parent_pipe, 1):
                    reason = 'supervisor-exited'; break
                request = root / 'release-request.json'
                if request.exists():
                    message = read(request)
                    if message['token'] != state['token']: raise RuntimeError('release token mismatch')
                    reason = message['reason']; break
                if len(slots) < 2:
                    # Exactly the remote-build launcher's slot order, never unlink lock files.
                    number = len(slots) + 1
                    file = open(f'/tmp/c11-atlas-build-slots/slot-{number}.lock', 'a+')
                    try: fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError: file.close()
                    else:
                        slots.append(file)
                        acquired = time.monotonic()
                        if number == 1: state['deadline_monotonic'] = acquired + 2700
                        state['acquired'].append({'slot': number, 'path': file.name,
                                                  'unix': time.time(), 'monotonic': acquired})
                if now >= next_load:
                    load = os.getloadavg()
                    row = {'monotonic': now, 'unix': time.time(), 'load': load,
                           'held_slots': len(slots), 'ready': state['ready'] or (len(slots) == 2 and load[0] < 8)}
                    log.write(json.dumps(row) + '\n'); log.flush()
                    next_load = now + 1
                    if state['ready'] and load[0] >= 8:
                        atomic(root / 'contamination.json', dict(row, classification='unresolved',
                               rule='Unrelated/uncertain=INCOMPLETE; product-attributable=regression. No automatic rerun.'))
                        reason = 'load-threshold; attribution-required'; break
                    if len(slots) == 2 and load[0] < 8 and not state['ready']:
                        state.update(ready=True, ready_monotonic=now, ready_unix=time.time(), ready_load=load)
                if time.monotonic() - state['heartbeat_monotonic'] >= 1:
                    state['heartbeat_monotonic'] = time.monotonic()
                    atomic(root / 'lease.json', state)
                time.sleep(.1)
    except BaseException as error:
        reason = 'guardian-error: ' + str(error)
    finally:
        # FD release happens before evidence I/O, even if storage has failed.
        for file in slots:
            file.close()
        released = time.monotonic()
        state.update(released=True, release_reason=reason, released_monotonic=released,
                     released_unix=time.time(), release_before_cap=released <= state.get('deadline_monotonic', released))
        atomic(root / 'lease.json', state)
        print(json.dumps(state), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['hold', 'release'])
    p.add_argument('--pair', required=True)
    p.add_argument('--atlas-host', required=True, help='Previously verified platform.node() on Atlas')
    p.add_argument('--execute', action='store_true')
    p.add_argument('--reason', default='pair-complete')
    a = p.parse_args()
    if not a.execute or platform.system() != 'Darwin' or platform.node() != a.atlas_host:
        raise RuntimeError('Explicit verified Atlas host and --execute required')
    root = Path(a.pair).absolute(); os.environ['C11_PERF_PAIR'] = str(root)
    if a.action == 'release': request_release(a.reason); return
    if not Path('/tmp/c11-atlas-build-slots').is_dir(): raise RuntimeError('Real build-slot directory absent')
    root.mkdir(parents=True, exist_ok=False)
    read_fd, write_fd = os.pipe()
    pid = os.fork()
    if pid == 0:
        os.close(write_fd)
        try: guardian(root, read_fd)
        finally: os._exit(0)
    os.close(read_fd)
    def interrupted(signum, frame): raise RuntimeError('supervisor signal-' + str(signum))
    signal.signal(signal.SIGTERM, interrupted); signal.signal(signal.SIGINT, interrupted)
    try:
        while True:
            exited, status = os.waitpid(pid, os.WNOHANG)
            if exited:
                if not (root / 'lease.json').exists() or not read(root / 'lease.json')['released']:
                    raise RuntimeError('Guardian exited without release evidence; its FDs are closed by the kernel')
                break
            if (root / 'lease.json').exists() and read(root / 'lease.json')['released']: break
            stamp = time.monotonic()
            try:
                proc = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pcpu,rss,comm'],
                                      capture_output=True, text=True, timeout=2)
                atomic(root / f'processes-{time.monotonic_ns()}.json', {'monotonic': stamp,
                       'unix': time.time(), 'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr})
            except Exception as error:
                atomic(root / f'process-error-{time.monotonic_ns()}.json', {'error': str(error)})
            # One-second load stream is maintained independently by the guardian.
            for _ in range(100):
                if (root / 'lease.json').exists() and read(root / 'lease.json')['released']: return
                time.sleep(.1)
    finally:
        os.close(write_fd)  # EOF releases locks even if the supervisor raises.
        try: os.waitpid(pid, 0)
        except ChildProcessError: pass


if __name__ == '__main__': main()

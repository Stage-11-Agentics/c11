#!/usr/bin/env bash
set -euo pipefail
export C11_SANDBOX_HOST=local
repo="$HOME/c11-builds/md-359/source"
source "$repo/scripts/sandbox-common.sh"
probe_b64="$(base64 </tmp/md359-final-physical-probe.py | tr -d '\n')"
document_b64="$(base64 </tmp/md359-final-document.md | tr -d '\n')"
host_context="$(/usr/bin/python3 -c 'import json,os,platform; print(json.dumps({"hostname":platform.node(),"load_average":os.getloadavg()}))')"
quoted_context="$(printf '%q' "$host_context")"
sandbox_guest_script md359-final <<GUEST
set -eu
printf %s '$probe_b64' | /usr/bin/base64 -D > /tmp/md359-final-physical-probe.py
printf %s '$document_b64' | /usr/bin/base64 -D > /tmp/c11-359-messaging.md
bundle="\$(/usr/bin/python3 -c 'import plistlib,sys; print(plistlib.load(open(sys.argv[1],"rb"))["CFBundleIdentifier"])' "\$SANDBOX_GUEST_APP/Contents/Info.plist")"
uid="\$(id -u)"
user="\$(id -un)"
/usr/bin/sudo -n /bin/launchctl asuser "\$uid" /usr/bin/sudo -n -u "\$user" \
  /usr/bin/env HOME="\$HOME" USER="\$user" LOGNAME="\$user" \
  PATH='/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' \
  /usr/bin/python3 /tmp/md359-final-physical-probe.py "\$SANDBOX_SOCKET" \
  /tmp/c11-359-messaging.md '/Volumes/My Shared Files/out/final-physical-memory.json' \
  --metric both --host-context $quoted_context --renderer-events "/tmp/cmux-debug-\$bundle.log" --reshow-count 10
GUEST

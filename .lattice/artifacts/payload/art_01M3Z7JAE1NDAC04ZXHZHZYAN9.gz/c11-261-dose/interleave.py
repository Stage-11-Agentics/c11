"""Sealed ABBA blocks; equal roles, fixed phases, retained invalids, no retries."""
import json
import os
from pathlib import Path
import subprocess
import time
import Foundation
from lease import atomic, read, pair_root, require_pair, require_runtime, verify_seal, selection_lock
from visual_probe import Target
from g60 import RPC, ChurnWorker, capture, assert_model
from appearance import validate
from run_phases import resource_sample
from schedule import schedule, assert_complete, PHASE_DURATIONS, COLLECTION_DURATIONS

root = pair_root()
contexts = {}
KEY1 = {'kind': 'key', 'keycode': 18, 'command': True}
KEY2 = {'kind': 'key', 'keycode': 19, 'command': True}


def activate(role):
    os.environ['C11_PERF_ROLE'] = role
    c = contexts[role]['config']
    subprocess.run(['/usr/bin/osascript', '-e',
                    f'tell application "System Events" to tell (first process whose unix id is {c["pid"]}) to set frontmost to true'],
                   check=True, timeout=3)
    Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.03))
    if 'target' in contexts[role]: contexts[role]['target'].verify()


def uptime():
    return {'monotonic': time.monotonic(), 'unix': time.time(), 'load': os.getloadavg(),
            'uptime': subprocess.check_output(['/usr/bin/uptime'], text=True, timeout=2).strip()}


def choose(target, templates, one, two):
    _, pixels, _ = target.capture(templates[one]['roi'])
    for label in (one, two):
        if pixels == Path(templates[label]['pixels']).read_bytes(): return label
    raise RuntimeError('Neither template visible: ' + one + '/' + two)


def sample(role, metric, ident, activation_ms):
    x = contexts[role]
    target, config, templates, manifest = (x[k] for k in ('target', 'config', 'templates', 'manifest'))
    before_host = uptime()
    start = time.perf_counter_ns()
    row = {'id': ident, 'metric': metric, 'ok': False}
    try:
        Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.005))
        target.verify()
        if metric in ('typing', 'scroll'):
            requested = time.monotonic()
            with selection_lock(role):
                acquired = time.monotonic()
                target.post(KEY1)
                time.sleep(.12)
                with RPC(manifest['tag'], manifest['socket']) as rpc:
                    observed = rpc.call('workspace.current')['workspace_id']
                if observed != manifest['labels']['w01']: raise RuntimeError('Reset selected identity mismatch')
                x['selected'] = observed
            reset_lock = {'requested': requested, 'acquired': acquired, 'released': time.monotonic()}
        else:
            reset_lock = None
        if metric == 'typing':
            target.post({'kind': 'click', 'point': config['terminal_point']})
            before = choose(target, templates, 'glyph-a', 'glyph-b')
            after = 'glyph-b' if before == 'glyph-a' else 'glyph-a'
            action = {'kind': 'key', 'text': after[-1]}
        elif metric == 'switch':
            before = choose(target, templates, 'workspace-1', 'workspace-2')
            after = 'workspace-2' if before == 'workspace-1' else 'workspace-1'
            action = KEY2 if after == 'workspace-2' else KEY1
        else:
            target.post({'kind': 'scroll', 'point': config['sidebar_point'], 'pixels': 10000})
            time.sleep(.12)
            before, after = 'scroll-top', 'scroll-down'
            action = {'kind': 'scroll', 'point': config['sidebar_point'], 'pixels': -config['scroll_pixels']}
        setup_ms = (time.perf_counter_ns() - start) / 1e6
        if metric == 'switch':
            requested = time.monotonic()
            with selection_lock(role):
                acquired = time.monotonic()
                row = target.measure(ident, metric, action, templates[before], templates[after])
                with RPC(manifest['tag'], manifest['socket']) as rpc:
                    observed = rpc.call('workspace.current')['workspace_id']
                expected = manifest['labels']['w02' if after == 'workspace-2' else 'w01']
                row.update(selected_expected=expected, selected_observed=observed)
                x['selected'] = observed
                if observed != expected: row.update(ok=False, error='selected_identity_mismatch')
            row['switch_selection_lock'] = {'requested': requested, 'acquired': acquired, 'released': time.monotonic()}
        else:
            row = target.measure(ident, metric, action, templates[before], templates[after])
        row['reset_selection_lock'] = reset_lock
    except Exception as error:
        row.update(ok=False, error='setup_or_probe_exception: ' + str(error))
        setup_ms = (time.perf_counter_ns() - start) / 1e6
    row.update(role=role, setup_ms=setup_ms, activation_ms=activation_ms,
               host_before=before_host, host_after=uptime())
    return row


for role in ('control', 'candidate'):
    identity = verify_seal(role)
    config = read(root / role / 'calibration/config.json')
    manifest = read(root / role / 'fixture/manifest.json')
    if not config.get('templates_visually_verified'): raise RuntimeError('Unreviewed templates')
    if (config['artifact_sha256'] != identity['artifact_sha256']
            or manifest['source_sha'] != identity['source_sha']
            or config['calibration_spec_sha256'] != identity['calibration_spec_sha256']):
        raise RuntimeError('Frozen artifact/source/calibration identity mismatch')
    setup = root / role / 'calibration'
    observed = validate(config, read(config['calibration_spec_path']), config['appearance_review'],
                        (setup / 'setup-config.json').read_bytes(), (setup / 'setup.png').read_bytes())
    if any(config[k] != v for k, v in observed.items()): raise RuntimeError('Appearance evidence changed')
    readiness = read(root / role / 'readiness.json')
    if (readiness.get('complete') is not True or readiness.get('debug_retention_disabled') is not True
            or readiness.get('window_id') != manifest['initial']['window_id']):
        raise RuntimeError('Complete native prime/readiness evidence required')
    contexts[role] = {'config': config, 'manifest': manifest,
                      'expected': read(root / role / 'fixture/expected.json'),
                      'templates': {k: read(v) for k, v in config['templates'].items()},
                      'selected': manifest['labels']['w01']}
    activate(role)
    contexts[role]['target'] = Target(config, root / role / 'run/crops')
    resource_sample(config['pid'], root / role / 'resources-before.json')

if min(require_pair()['deadline_monotonic'],
       *(require_runtime('c11-261', role)['deadline_monotonic'] for role in contexts)) - time.monotonic() < 12 * 60:
    raise RuntimeError('Less than preregistered 12 minutes left; do not start a metric sample')
atomic(root / 'measurement-claim.json', {'unix': time.time(), 'design': 'authorized-topup-ABBA-ten-trial-blocks',
                                       'attempts_per_role': {'churn': {'typing': 120, 'switch': 60, 'scroll': 60},
                                                            'quiescence': {'typing': 120, 'switch': 60, 'scroll': 60}}})
warm = time.monotonic()
while time.monotonic() - warm < 60:
    require_pair()
    time.sleep(.2)
atomic(root / 'warmup.json', {'start': warm, 'end': time.monotonic(), 'seconds': 60})
all_rows = []
with (root / 'paired-samples.jsonl').open('x') as log:
    for phase in ('churn', 'quiescence'):
        phase_seconds = PHASE_DURATIONS[phase]
        workers = []
        for role, x in contexts.items():
            activate(role)
            with RPC('c11-261', x['manifest']['socket']) as rpc:
                state = capture(rpc, x['manifest'], root / role / (phase + '-before.json'))
                assert_model(state, x['manifest'], x['expected'], x['selected'])
        started = time.monotonic() + 1
        deadline = started + phase_seconds
        atomic(root / (phase + '-clock.json'), {'start': started, 'deadline': deadline, 'seconds': phase_seconds})
        if phase == 'churn':
            for role, x in contexts.items():
                worker = ChurnWorker(x['manifest'], x['expected'], started,
                                     root / role / 'operations.jsonl', count=3000, duration=phase_seconds)
                workers.append((role, worker))
                worker.start()
        active_block = None
        try:
            planned = schedule(phase)
            for spec in planned:
                due = started + spec['trial'] * COLLECTION_DURATIONS[phase] / len(planned)
                time.sleep(max(0, due - time.monotonic()))
                require_pair()
                if time.monotonic() >= deadline: raise RuntimeError('Fixed ABBA phase overrun')
                block = (spec['cycle'], spec['block'])
                activation_ms = 0.0
                if block != active_block:
                    before_activation = time.perf_counter_ns()
                    activate(spec['role'])
                    activation_ms = (time.perf_counter_ns() - before_activation) / 1e6
                    active_block = block
                ident = f"{phase}-c{spec['cycle']:02d}-b{spec['block']}-{spec['ordinal']:02d}-{spec['metric']}"
                row = sample(spec['role'], spec['metric'], ident, activation_ms)
                row.update(spec, phase=phase, due=due, completed=time.monotonic())
                log.write(json.dumps(row) + '\n')
                log.flush()
                all_rows.append(row)
                if row['completed'] > deadline: raise RuntimeError('Trial crossed fixed ABBA boundary')
            time.sleep(max(0, deadline - time.monotonic()))
        finally:
            for role, worker in workers:
                worker.stop_and_join()
                contexts[role]['expected'] = worker.expected
                atomic(root / role / 'churn-summary.json', {'count': len(worker.records), 'error': worker.error,
                                                          'pending': worker.pending, 'alive': worker.is_alive()})
        for role, worker in workers:
            if (worker.error or len(worker.records) != 3000
                    or any(r['completed'] > deadline for r in worker.records)):
                raise RuntimeError(f'{role}: incomplete churn {len(worker.records)}/3000: {worker.error}')
        paired = assert_complete(all_rows, phase)
        with (root / 'deltas.jsonl').open('a') as output:
            for delta in paired: output.write(json.dumps(delta) + '\n')
        for role, x in contexts.items():
            activate(role)
            with RPC('c11-261', x['manifest']['socket']) as rpc:
                state = capture(rpc, x['manifest'], root / role / (phase + '-after.json'))
                assert_model(state, x['manifest'], x['expected'], x['selected'])
        print(phase + ' captured', flush=True)
for role, x in contexts.items():
    resource_sample(x['config']['pid'], root / role / 'resources-after.json')
atomic(root / 'samples-complete.json', {'unix': time.time(), 'monotonic': time.monotonic(), 'samples': len(all_rows)})
print('SAMPLES COMPLETE: SEND QUIET DONE NOW', flush=True)

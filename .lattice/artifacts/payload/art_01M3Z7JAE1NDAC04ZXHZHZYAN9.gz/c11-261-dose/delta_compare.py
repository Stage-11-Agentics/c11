"""Offline round-2 delta: carry ONLY complete no-churn, never deficient-dose churn."""
import argparse
import hashlib
import json
from pathlib import Path
from compare import stats
from schedule import pairs
from abba_compare import audit_run

OLD_ROWS_SHA = 'b010b350a313ecf1a750dc78bc8e98cdc812430f91d8d06aabd4f9e890723480'
OLD_SEAL_SHA = '8a7318d2d1d7b639999ee8281b44eefbfa356e13741222205ff8a918720c92a6'


def measurements(rows, phase, metric):
    result = {}
    for role in ('control', 'candidate'):
        own = [r for r in rows if (r['phase'], r['metric'], r['role']) == (phase, metric, role)]
        valid = [r for r in own if r.get('ok')]
        result[role] = {'attempted': len(own), 'valid': len(valid), 'invalid': len(own)-len(valid),
                        'latency': stats([r['latency_ms'] for r in valid])}
    return result


def budgets(roles, phase, metric, cohort):
    result = []
    for q, factor, additive in ((95, 1.20, 5), (99, 1.25, 15)):
        a, b = (roles[role]['latency'][f'p{q}_ms'] for role in ('control', 'candidate'))
        limit = max(a*factor, a+additive) if a is not None else None
        result.append({'phase': phase, 'metric': metric, 'cohort': cohort, 'percentile': q,
                       'control_ms': a, 'candidate_ms': b, 'limit_ms': limit,
                       'pass': b <= limit if b is not None and limit is not None else None})
    return result


def assemble(old, new, topup):
    """Pure data assembly; every churn/quiescence value comes from NEW raw rows."""
    limits, phases, issues = [], {}, []
    for phase in ('no-churn', 'churn', 'quiescence'):
        cohort = 'window2-complete-no-churn' if phase == 'no-churn' else 'full-dose-final-cohort'
        source = old if phase == 'no-churn' else new
        phases[phase] = {}
        for metric in ('typing', 'switch', 'scroll'):
            roles = measurements(source, phase, metric)
            minimum = 100 if metric == 'typing' else 40
            expected_attempts = (120 if metric == 'typing' else 40) if phase == 'no-churn' else (120 if metric == 'typing' else 60)
            for role, counts in roles.items():
                if counts['valid'] < minimum or counts['attempted'] != expected_attempts:
                    issues.append(f'{cohort}/{phase}/{metric}/{role} below minimum or unequal planned attempts')
            phases[phase][metric] = {'cohort': cohort, 'roles': roles}
            limits.extend(budgets(roles, phase, metric, cohort))
    failed = [b for b in limits if b['pass'] is False]
    issues.extend(topup.get('incomplete_reasons', []))
    if any(b['pass'] is None for b in limits): issues.append('unmeasured final budget')
    old_pairs = pairs([r for r in old if r['phase'] == 'no-churn'])
    new_pairs = pairs(new)
    return {'schema': 'c11-261-full-dose-perf-delta-v2',
            'status': 'FAIL' if failed else 'INCOMPLETE' if issues else 'PASS',
            'complete_by_authorized_delta': not issues, 'original_window2_status': 'INCOMPLETE',
            'budgets': limits,
            'observed_budget_failures': failed, 'incomplete_reasons': issues, 'phases': phases,
            'per_pair_deltas': {'window2-no-churn-only': old_pairs, 'full-dose-final-cohort': new_pairs},
            'old_churn_disclosed_excluded': {metric: measurements(old, 'churn', metric) for metric in ('typing', 'switch', 'scroll')},
            'old_churn_invalids_disclosed': [r for r in old if r['phase'] == 'churn' and not r.get('ok')],
            'topup_full_audit': topup, 'pooling': False,
            'limitations': ['Window2 remains INCOMPLETE at2165/2400 mutations; its churn is excluded from final budgets.',
                            'New churn:300s/3000 mutations perrole,10Hz, only if all clocks/counts/models audit complete.',
                            'New quiescence follows that full dose with no pending worker or mutation.',
                            'Variation is not pure isolated noise; no overhead subtraction or confidence claim.',
                            'Not full ticket acceptance, independent review, human signoff or a soak.']}


def audit_delta(pair, identity, baseline):
    baseline = Path(baseline)
    raw = (baseline / 'attempt-001/paired-samples.jsonl').read_bytes()
    seal_bytes = (baseline / 'identity-017.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != OLD_ROWS_SHA or hashlib.sha256(seal_bytes).hexdigest() != OLD_SEAL_SHA:
        raise RuntimeError('Pinned immutable window2 evidence differs')
    old_identity, new_identity = json.loads(seal_bytes), json.loads(Path(identity).read_text())
    for role in ('control', 'candidate'):
        for key in ('source_sha', 'artifact_sha256', 'calibration_spec_sha256'):
            if old_identity[role][key] != new_identity[role][key]:
                raise RuntimeError('Frozen old/new pair differs: ' + role + '/' + key)
    old = [json.loads(line) for line in raw.splitlines()]
    if len(old) != 800: raise RuntimeError('Window2 raw accounting differs')
    new = [json.loads(line) for line in (Path(pair)/'paired-samples.jsonl').read_text().splitlines()]
    report = assemble(old, new, audit_run(pair, identity))
    report['baseline_rows_sha256'] = OLD_ROWS_SHA
    report['baseline_seal_sha256'] = OLD_SEAL_SHA
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('pair', 'identity', 'baseline', 'out'): parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    try: result = audit_delta(args.pair, args.identity, args.baseline)
    except Exception as error:
        result = {'status': 'INCOMPLETE', 'complete_by_authorized_delta': False,
                  'incomplete_reasons': [{'location': 'delta-parser', 'reason': str(error)}]}
    Path(args.out).write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k in ('status', 'complete_by_authorized_delta', 'budgets', 'incomplete_reasons')}, indent=2))
    raise SystemExit({'PASS': 0, 'FAIL': 1, 'INCOMPLETE': 2}[result['status']])

import Foundation
let cases = ["3. a\n4. b", "para\n\n---\n\nafter", "- top\n  - nested\n- next", "> q1\n> q2", "**b** `c` [l](https://x)", "    indented code", "Step\n2. two"]
for input in cases {
  let a = try! AttributedString(markdown: input, options: .init(interpretedSyntax: .full))
  var out: [String] = []
  for run in a.runs {
    let k = run.presentationIntent?.components.map { c -> String in
      switch c.kind {
      case .paragraph: return "p"; case .header(let l): return "h\(l)"; case .listItem(let o): return "li\(o)"
      case .orderedList: return "ol"; case .unorderedList: return "ul"; case .blockQuote: return "bq"
      case .thematicBreak: return "hr"; case .codeBlock: return "code"; default: return "\(c.kind)" }
    }.joined(separator: "<") ?? "-"
    out.append("[\(k)#\(run.presentationIntent?.components.first?.identity ?? -1)]\(String(a[run.range].characters).debugDescription)")
  }
  print(input.debugDescription, "=>", out.joined(separator: " "))
}

import sys, pathlib
root = pathlib.Path(sys.argv[1])
def edit(rel, pairs):
    p = root / rel; s = p.read_text()
    for old, new in pairs:
        assert s.count(old) == 1, (rel, old)
        s = s.replace(old, new)
    p.write_text(s)
edit("Sources/Panels/MarkdownWebRenderer.swift", [
  ("decisionHandler(initial ? .allow : .cancel)", "decisionHandler(.allow) // SYNTH MUTANT"),
  ("""        guard !closed, message.frameInfo.isMainFrame,
              message.frameInfo.request.url?.scheme == MarkdownAssetPolicy.viewerScheme,
              message.frameInfo.request.url?.host == "bundle",
              let body""", """        guard !closed, // SYNTH MUTANT: frame/origin guard removed
              let body"""),
  ("""        if ["=", "+", "-", "0"].contains(event.charactersIgnoringModifiers ?? "") {
            return false // Never let WebKit page zoom claim c11's scale shortcuts.
        }
""", "        // SYNTH MUTANT: zoom-key guard removed\n"),
  ("""                                   "Content-Security-Policy": MarkdownAssetPolicy.csp,
""", ""),
])
edit("Sources/Panels/MarkdownRendererCache.swift", [
  ("""        entry.epoch += 1
        policy.setPinned(panel.id, true)
    }""", """        _ = entry // SYNTH MUTANT: no query pin or epoch
    }"""),
  ("""                  !renderer.hasQueriesInFlight, renderer.canCaptureReadingPosition else { continue }""",
   """                  renderer.canCaptureReadingPosition else { continue }"""),
  ("""                if current.epoch == epoch, !panel.isRendererVisible,
                   !renderer.hasQueriesInFlight, panel.renderer === renderer,""",
   """                if !panel.isRendererVisible, // SYNTH MUTANT: no epoch or in-flight recheck
                   panel.renderer === renderer,"""),
])
print("mutated")

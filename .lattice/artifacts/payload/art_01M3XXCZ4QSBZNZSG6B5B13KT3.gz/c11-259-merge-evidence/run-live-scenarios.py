"""Run only the two requested live scenarios on the reserved build-host build."""
import json,os,subprocess,sys,time,hashlib
from pathlib import Path
sys.path.insert(0,'/tmp/c11-259-perf')
from visual_probe import Target
root=Path('/tmp/c11-259-merge-evidence');root.mkdir(exist_ok=True);source=Path('$HOME/c11-builds/c11-259/source');py=sys.executable
expected='53d88b7c08c4b02c7ca83021f062168c1053a4b3'
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert head==expected
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no'],text=True).strip()
lease=json.loads(subprocess.check_output([py,'/tmp/c11-259-perf/ui_slot.py','take','--tag','c11-259'],text=True));(root/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
with (root/'launch.log').open('w') as f:subprocess.run([str(source/'scripts/launch-tagged-automation.sh'),'c11-259','--qa','fresh'],cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
socket='/tmp/c11-debug-c11-259.sock'
for _ in range(100):
 if Path(socket).is_socket():break
 time.sleep(.1)
with (root/'configure.log').open('w') as f:subprocess.run([py,'/tmp/c11-259-perf/configure.py','--tag','c11-259','--display','9','--started',str(lease['started']),'--out',str(root/'calibration')],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=30)
c=json.loads((root/'calibration/config.json').read_text());t=Target(c,root/'calibration');cli=Path(c['app_path'])/'Contents/Resources/bin/c11'
env=dict(os.environ);env.update(C11_SOCKET=socket,C11_SOCKET_PATH=socket,C11_CLI=str(cli),C11_GROUPS_TEST_TAG='c11-259')
results={}
for name in ['test_workspace_groups.py','test_workspace_batch_reorder.py']:
 with (root/name.replace('.py','.log')).open('w') as f:r=subprocess.run([py,str(source/'tests_v2'/name)],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 results[name]={'returncode':r.returncode,'sha256':hashlib.sha256((source/'tests_v2'/name).read_bytes()).hexdigest()};print(name,r.returncode,flush=True)
 assert r.returncode==0,name
# Both scenarios own/close their additional fixture windows. Keep final screenshot and tree.
r=subprocess.run([str(cli),'--socket',socket,'tree','--all','--json'],capture_output=True,text=True,check=True);(root/'tree-after.json').write_text(r.stdout)
r=subprocess.run([str(cli),'--socket',socket,'tree','--no-layout'],capture_output=True,text=True,check=True);(root/'tree-no-layout.txt').write_text(r.stdout)
t.verify();im,_,timing=t.capture([0,0,1320,880]);t.save_png(im,root/'calibration/final.png')
(root/'runtime-result.json').write_text(json.dumps({'head':head,'tag':'c11-259','source_clean':True,'tests':results,'artifact_sha256':c['artifact_sha256'],'pid':c['pid'],'load':os.getloadavg(),'unix':time.time(),'performance_runs':0},indent=2)+'\n')
print('BOTH LIVE GROUP SCENARIOS PASS',flush=True)

import SwiftUI
enum TitleBarDescriptionBlock: Equatable {
    case paragraph(AttributedString)
    case heading(level: Int, text: AttributedString)
    case listItem(marker: String, text: AttributedString, depth: Int)
    case quote(AttributedString)
    case rule
}

private enum TitleBarDescriptionBlockKind: Equatable {
    case paragraph
    case heading(Int)
    case listItem(marker: String, depth: Int)
    case quote
    case codeBlock
    case rule
}

/// The first presentation-intent component identifies the enclosing block.
/// Keep the semantic component identity too: list items share their enclosing
/// list's first component, but must still become separate native rows.
private struct TitleBarDescriptionBlockKey: Equatable {
    let enclosingIdentity: Int
    let blockIdentity: Int
    let kind: TitleBarDescriptionBlockKind
}

func titleBarDescriptionBlocks(_ text: String) -> [TitleBarDescriptionBlock] {
    guard let parsed = try? AttributedString(
        markdown: text,
        options: .init(interpretedSyntax: .full)
    ) else {
        return text.isEmpty ? [] : [.paragraph(AttributedString(text))]
    }

    var blocks: [TitleBarDescriptionBlock] = []
    var currentKey: TitleBarDescriptionBlockKey?
    var currentText = AttributedString()

    func flushCurrentBlock() {
        guard let key = currentKey else { return }
        let content = titleBarDescriptionTrimmed(currentText)

        switch key.kind {
        case .paragraph:
            guard !content.characters.isEmpty else { break }
            blocks.append(.paragraph(titleBarDescriptionInertLinks(content)))
        case .codeBlock:
            guard !content.characters.isEmpty else { break }
            var code = titleBarDescriptionInertLinks(content)
            for run in code.runs {
                code[run.range].font = .system(size: 11, design: .monospaced)
            }
            blocks.append(.paragraph(code))
        case .heading(let level):
            guard !content.characters.isEmpty else { break }
            blocks.append(.heading(level: level, text: titleBarDescriptionInertLinks(content)))
        case .listItem(let marker, let depth):
            guard !content.characters.isEmpty else { break }
            blocks.append(.listItem(
                marker: marker,
                text: titleBarDescriptionInertLinks(content),
                depth: depth
            ))
        case .quote:
            guard !content.characters.isEmpty else { break }
            blocks.append(.quote(titleBarDescriptionInertLinks(content)))
        case .rule:
            blocks.append(.rule)
        }

        currentKey = nil
        currentText = AttributedString()
    }

    for (runIndex, run) in parsed.runs.enumerated() {
        let key = titleBarDescriptionBlockKey(
            for: run.presentationIntent,
            fallbackIdentity: runIndex
        )

        if currentKey != key {
            flushCurrentBlock()
            currentKey = key
        }

        var fragment = AttributedString(parsed[run.range])
        if key.kind == .rule {
            fragment = AttributedString(String(fragment.characters).replacingOccurrences(of: "\u{2E3B}", with: ""))
        }
        currentText.append(fragment)
    }
    flushCurrentBlock()
    return blocks
}

private func titleBarDescriptionBlockKey(
    for intent: PresentationIntent?,
    fallbackIdentity: Int
) -> TitleBarDescriptionBlockKey {
    let components = intent?.components ?? []
    let enclosingIdentity = components.first?.identity ?? fallbackIdentity

    if let item = components.last(where: {
        if case .listItem = $0.kind { return true }
        return false
    }), case .listItem(let ordinal) = item.kind {
        let itemIndex = components.lastIndex(where: {
            if case .listItem = $0.kind { return true }
            return false
        }) ?? components.endIndex
        let parentList = components.dropFirst(itemIndex + 1).first(where: {
            switch $0.kind {
            case .orderedList, .unorderedList: return true
            default: return false
            }
        })
        let marker: String
        if let parentList, case .orderedList = parentList.kind {
            marker = "\(ordinal)."
        } else {
            marker = "•"
        }
        let depth = max(0, components.reduce(into: 0) { count, component in
            switch component.kind {
            case .orderedList, .unorderedList: count += 1
            default: break
            }
        } - 1)
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: item.identity,
            kind: .listItem(marker: marker, depth: depth)
        )
    }

    if let heading = components.last(where: {
        if case .header = $0.kind { return true }
        return false
    }), case .header(let level) = heading.kind {
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: heading.identity,
            kind: .heading(level)
        )
    }

    if let rule = components.last(where: {
        if case .thematicBreak = $0.kind { return true }
        return false
    }) {
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: rule.identity,
            kind: .rule
        )
    }

    if let codeBlock = components.last(where: {
        if case .codeBlock = $0.kind { return true }
        return false
    }) {
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: codeBlock.identity,
            kind: .codeBlock
        )
    }

    if let quote = components.last(where: {
        if case .blockQuote = $0.kind { return true }
        return false
    }) {
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: quote.identity,
            kind: .quote
        )
    }

    if let paragraph = components.last(where: {
        if case .paragraph = $0.kind { return true }
        return false
    }) {
        return TitleBarDescriptionBlockKey(
            enclosingIdentity: enclosingIdentity,
            blockIdentity: paragraph.identity,
            kind: .paragraph
        )
    }

    return TitleBarDescriptionBlockKey(
        enclosingIdentity: enclosingIdentity,
        blockIdentity: fallbackIdentity,
        kind: .paragraph
    )
}

private func titleBarDescriptionTrimmed(_ input: AttributedString) -> AttributedString {
    guard let first = input.characters.firstIndex(where: { !$0.isWhitespace }),
          let last = input.characters.lastIndex(where: { !$0.isWhitespace }) else {
        return AttributedString()
    }
    return AttributedString(input[first..<input.index(afterCharacter: last)])
}

/// Full Markdown parsing retains inline styling while the native block mapper
/// consumes presentation intents. Drop links after parsing so labels remain
/// visible without creating controls or navigation.
private func titleBarDescriptionInertLinks(_ input: AttributedString) -> AttributedString {
    var result = input
    for run in result.runs where run.link != nil {
        result[run.range].foregroundColor = Color.accentColor
        result[run.range].link = nil
    }
    return result
}

/// Foundation supplies inline emphasis/code parsing for this compatibility
/// helper. Drop the URL attribute entirely so links retain their text but
/// cannot navigate or become controls.
func titleBarDescriptionInline(_ text: String) -> AttributedString {
    let parsed = (try? AttributedString(
        markdown: text,
        options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace)
    )) ?? AttributedString(text)
    return titleBarDescriptionInertLinks(parsed)
}


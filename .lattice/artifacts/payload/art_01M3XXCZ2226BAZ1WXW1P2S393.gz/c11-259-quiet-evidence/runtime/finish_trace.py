import argparse,json,time,sys,subprocess,os
from pathlib import Path
from visual_probe import Target
p=argparse.ArgumentParser();p.add_argument('role',choices=['control','candidate']);p.add_argument('--confirm',action='store_true');a=p.parse_args();root=Path('/tmp/c11-259-perf/diagnostic-trace')/a.role;out=root/'calibration';c=json.loads((out/'config.json').read_text());t=Target(c,out);Q=t.Q
if not a.confirm:
 rows=[]
 for _ in range(5):
  rows.append({'unix':time.time(),'load':os.getloadavg(),'ps':subprocess.check_output(['ps','-p',str(c['pid']),'-o','pid=,pcpu=,rss=,etime='],text=True).strip(),'operations_bytes':(root/'run/churn/operations.jsonl').stat().st_size});time.sleep(1)
 (out/'idle-after-probes.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'host-processes-after.txt').write_text(subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True))
 cli=Path(c['app_path'])/'Contents/Resources/bin/c11';r=subprocess.run([str(cli),'--socket','/tmp/c11-debug-'+json.loads((root/'lease.json').read_text())['tag']+'.sock','tree','--no-layout'],capture_output=True,text=True);(out/'tree-no-layout.txt').write_text(r.stdout+r.stderr);assert r.returncode==0
 tag=json.loads((root/'lease.json').read_text())['tag'];h={}
 for f in [Path('/tmp/c11-debug-'+tag+'-hang.log'),Path('/tmp/c11-hang-'+tag+'.log')]:
  h[str(f)]={'exists':f.exists()}
  if f.exists():(out/f.name).write_bytes(f.read_bytes());h[str(f)]['bytes']=f.stat().st_size
 (out/'hang-telemetry.json').write_text(json.dumps(h,indent=2)+'\n');m=Q.CGDisplayCopyDisplayMode(9);(out/'host-display.json').write_text(json.dumps({'os':subprocess.check_output(['sw_vers'],text=True),'refresh_hz_reported':Q.CGDisplayModeGetRefreshRate(m),'physical_pixels':[Q.CGDisplayModeGetPixelWidth(m),Q.CGDisplayModeGetPixelHeight(m)]},indent=2)+'\n')
 im,_,_=t.capture([0,0,1320,880]);t.save_png(im,out/'final.png');t.post({'kind':'key','keycode':12,'command':True});time.sleep(.4)
 ws=[w for w in Q.CGWindowListCopyWindowInfo(Q.kCGWindowListOptionOnScreenOnly,0) if w.get('kCGWindowOwnerPID')==c['pid'] and w.get('kCGWindowBounds',{}).get('Width')==260];assert len(ws)==1;w=ws[0];b=dict(w['kCGWindowBounds']);im=Q.CGWindowListCreateImage(Q.CGRectMake(b['X'],b['Y'],b['Width'],b['Height']),Q.kCGWindowListOptionIncludingWindow,w['kCGWindowNumber'],Q.kCGWindowImageBoundsIgnoreFraming|Q.kCGWindowImageNominalResolution);t.save_png(im,out/'quit-dialog.png');(out/'quit-dialog.json').write_text(json.dumps({'window_id':w['kCGWindowNumber'],'bounds':b},indent=2)+'\n');print('Review quit-dialog.png',b)
else:
 d=json.loads((out/'quit-dialog.json').read_text());ws=[w for w in Q.CGWindowListCopyWindowInfo(Q.kCGWindowListOptionOnScreenOnly,0) if w.get('kCGWindowOwnerPID')==c['pid'] and w.get('kCGWindowNumber')==d['window_id']];assert len(ws)==1 and dict(ws[0]['kCGWindowBounds'])==d['bounds'];assert d['bounds']=={'X':610.0,'Y':451.0,'Width':260.0,'Height':138.0}
 for typ in (Q.kCGEventMouseMoved,Q.kCGEventLeftMouseDown,Q.kCGEventLeftMouseUp):Q.CGEventPost(Q.kCGHIDEventTap,Q.CGEventCreateMouseEvent(None,typ,(800,560),Q.kCGMouseButtonLeft));time.sleep(.08)
 for _ in range(70):
  if not list(t.A.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id'])):break
  time.sleep(.1)
 assert not list(t.A.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']))
 (out/'dismissal.json').write_text(json.dumps({'synthesized':['Command-Q','HID click reviewed Quit button'],'pid':c['pid'],'gone':True,'unix':time.time()},indent=2)+'\n');lease=json.loads((root/'lease.json').read_text());r=subprocess.check_output([sys.executable,'/tmp/c11-259-perf/ui_slot.py','release','--tag',lease['tag'],'--token',lease['token']],text=True);(out/'ui-release.json').write_text(r);print(r)

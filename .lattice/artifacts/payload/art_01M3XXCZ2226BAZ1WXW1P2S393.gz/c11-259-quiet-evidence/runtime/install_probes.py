import json,sys,time
from pathlib import Path
from g60 import RPC,probe_commands
p=Path(sys.argv[1]);m=json.loads(p.read_text());commands=probe_commands(m,'/tmp/c11-259-perf/probe_terminal.py','/tmp/c11-259-tools/bin/python')
with RPC(m['tag'],m['socket']) as r:
 for item in commands['commands']:
  r.call('workspace.select',window_id=m['initial']['window_id'],workspace_id=item['workspace_id'])
  r.call('tab.send_text',workspace_id=item['workspace_id'],tab_id=item['tab_id'],text=item['command'])
  r.call('tab.send_key',workspace_id=item['workspace_id'],tab_id=item['tab_id'],key='enter');time.sleep(.4)
  item['read_text']=r.call('tab.read_text',workspace_id=item['workspace_id'],tab_id=item['tab_id'])
  assert item['marker'] in item['read_text']['text']
 r.call('workspace.select',window_id=m['initial']['window_id'],workspace_id=m['labels']['w01'])
(p.parent/'probe-install.json').write_text(json.dumps(commands,indent=2)+'\n')

"""Own one build-host UI slot with a hard 20-minute tagged-app watchdog."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid

LOCK = Path('/tmp/c11-1.0-ui.lock')
TAGS = ('c11-259', 'c11-259-control')


def current():
    try:
        return json.loads((LOCK / 'lease.json').read_text())
    except FileNotFoundError:
        return None


def apps(tag):
    import AppKit
    bundle = 'com.stage11.c11.debug.' + tag.replace('-', '.')
    return list(AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bundle))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('take', 'watch', 'release'))
    parser.add_argument('--tag', choices=TAGS, required=True)
    parser.add_argument('--token')
    args = parser.parse_args()
    if args.action == 'take':
        LOCK.mkdir()
        lease = {'owner': 'C11-259', 'tag': args.tag, 'token': uuid.uuid4().hex,
                 'started': time.time(), 'limit_s': 1200}
        (LOCK / 'owner').write_text(f'C11-259 {os.getpid()} {args.tag}\n')
        (LOCK / 'lease.json').write_text(json.dumps(lease))
        log = open('/tmp/c11-259-ui-watchdog.log', 'a')
        proc = subprocess.Popen([sys.executable, __file__, 'watch', '--tag', args.tag,
                                 '--token', lease['token']], stdin=subprocess.DEVNULL,
                                stdout=log, stderr=log, start_new_session=True)
        lease['watchdog_pid'] = proc.pid
        print(json.dumps(lease), flush=True)
    elif args.action == 'release':
        lease = current()
        if not lease or lease['token'] != args.token or lease['tag'] != args.tag:
            raise RuntimeError('UI slot ownership mismatch')
        if apps(args.tag):
            raise RuntimeError('Prove tagged process dismissal before releasing its slot')
        elapsed = time.time() - lease['started']
        shutil.rmtree(LOCK)
        print(json.dumps({'tag': args.tag, 'released': True, 'elapsed_s': elapsed, 'app_running': False}))
    else:
        while True:
            lease = current()
            if not lease or lease['token'] != args.token or lease['tag'] != args.tag:
                return
            if time.time() >= lease['started'] + lease['limit_s']:
                for app in apps(args.tag):
                    app.terminate()
                time.sleep(2)
                for app in apps(args.tag):
                    os.kill(app.processIdentifier(), signal.SIGTERM)
                print(json.dumps({'watchdog_expired': True, 'tag': args.tag, 'time': time.time()}), flush=True)
                if current() and current()['token'] == args.token:
                    shutil.rmtree(LOCK)
                return
            time.sleep(1)


if __name__ == '__main__':
    main()

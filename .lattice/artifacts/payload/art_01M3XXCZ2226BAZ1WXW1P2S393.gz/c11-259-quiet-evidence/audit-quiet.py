import json, hashlib
from pathlib import Path
root=Path(__file__).resolve().parent/'runtime'; q=root/'paired-quiet'
def read(p):return json.loads(p.read_text())
lease=read(q/'lease.json');request=read(q/'release-request.json');guard=read(q/'deadline-guard.json')
assert lease['released'] and lease['release_reason']=='pair-complete'
assert lease['elapsed_s']<2700 and lease['token']==request['token']
assert 0<=lease['released_unix']-request['unix']<2
assert 'forced_release_unix' not in guard and guard['finished_unix']>=lease['released_unix']
loads=[json.loads(s) for s in (q/'load.jsonl').read_text().splitlines()]
assert all(row['held_slots']==[1,2] for row in loads)
assert max(b['monotonic']-a['monotonic'] for a,b in zip(loads,loads[1:]))<3
summary={'build_lease_seconds':lease['elapsed_s'],'release_delay_seconds':lease['released_unix']-request['unix'],'continuous_load_samples':len(loads),'load_gap_max_seconds':max(b['monotonic']-a['monotonic'] for a,b in zip(loads,loads[1:])),'roles':{}}
core=['g60.py','probe_terminal.py','visual_probe.py','run_phases.py','calibrate.py']
for role in ['control','candidate']:
 r=q/role; admission=read(r/'measurement-admission.json');launch=read(r/'launch-admission.json');run=read(r/'run/run.json');config=read(r/'calibration/config.json');old=read(root/'paired-fresh'/role/'calibration/config.json');h=read(r/'probe-script-hashes.json');oldh=read(root/'paired-fresh'/role/'probe-script-hashes.json')
 assert admission['load'][0]<8 and launch['load'][0]<8 and launch['both_flock_probes_blocked']
 assert all(v['monotonic']<=launch['monotonic'] for v in lease['acquired'].values())
 assert run['complete'] and len(run['phases'])==3
 for name in core:assert h[name]==oldh[name]==hashlib.sha256((root/name).read_bytes()).hexdigest()
 dismissal=read(r/'calibration/dismissal.json');ui=read(r/'calibration/ui-release.json')
 assert dismissal['gone'] and ui['released'] and not ui['app_running'] and ui['elapsed_s']<1200
 phases={}
 for p in run['phases']:
  assert p['complete'] and p['model_verified'] and lease['released_monotonic']>p['ended']
  rows=[x for x in loads if p['start']<=x['monotonic']<=p['ended']]
  assert len(rows)>=58
  phases[p['name']]={'load_1_min':min(x['load'][0] for x in rows),'load_1_max':max(x['load'][0] for x in rows),'load_samples':len(rows)}
 summary['roles'][role]={'launch_load':launch['load'][0],'measurement_start_load':admission['load'][0],'additional_quiet_wait_seconds':admission['additional_quiet_wait_s'],'core_protocol_hashes_match':True,'ui_lease_seconds':ui['elapsed_s'],'phases':phases}
comparison=read(q/'comparison-portable.json');assert comparison['status'] in ['PASS','FAIL'] and not comparison['incomplete_reasons']
summary['comparison_status']=comparison['status'];summary['budget_failures']=comparison['budget_failures']
(q/'quiet-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

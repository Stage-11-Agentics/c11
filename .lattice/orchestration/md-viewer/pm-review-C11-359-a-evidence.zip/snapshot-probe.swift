
extension MarkdownWebRendererTests {
    func testPostMergeWorkspaceRestoreKeepsLegacyAndMalformedNeighborPreferences() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("markdown-pm-snapshot-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let path = folder.appendingPathComponent("snapshot.md")
        try "# Restore\n".write(to: path, atomically: true, encoding: .utf8)
        let workspace = Workspace()
        defer { for panel in workspace.panels.values { panel.close() } }
        let area = try XCTUnwrap(workspace.bonsplitController.allPaneIds.first)
        let source = try XCTUnwrap(workspace.newMarkdownPanel(inPane: area, filePath: path.path, focus: false))
        let expected = MarkdownPresentation(fontScale: 1.8, theme: "dark", typeface: "mono", outlineOpen: false)
        source.applyRestoredPresentation(SessionMarkdownPanelSnapshot(filePath: path.path, fontScale: 1.8, theme: "dark", typeface: "mono", outlineOpen: false))
        let snapshot = workspace.sessionSnapshot(includeScrollback: false, conversationsByPanelId: [:])
        let encoded = try JSONEncoder().encode(snapshot)
        for variant in ["populated", "legacy", "malformed"] {
            var json = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
            var panels = try XCTUnwrap(json["panels"] as? [[String: Any]])
            let index = try XCTUnwrap(panels.firstIndex { ($0["id"] as? String)?.lowercased() == source.id.uuidString.lowercased() })
            var markdown = try XCTUnwrap(panels[index]["markdown"] as? [String: Any])
            var wanted = expected
            if variant == "legacy" {
                markdown = ["filePath": path.path, "fontScale": 1.4]
                wanted = MarkdownPresentation(fontScale: 1.4)
            } else if variant == "malformed" {
                markdown["theme"] = ["invalid": true]
                wanted = MarkdownPresentation(fontScale: 1.8, typeface: "mono", outlineOpen: false)
            }
            panels[index]["markdown"] = markdown
            json["panels"] = panels
            let decoded = try JSONDecoder().decode(SessionWorkspaceSnapshot.self, from: JSONSerialization.data(withJSONObject: json))
            let restored = Workspace()
            defer { for panel in restored.panels.values { panel.close() } }
            restored.restoreSessionSnapshot(decoded)
            let result = try XCTUnwrap(restored.markdownPanel(for: source.id), variant)
            XCTAssertEqual(result.filePath, path.path, variant)
            XCTAssertEqual(result.presentation, wanted, variant)
            XCTAssertEqual(result.content, "# Restore\n", variant)
            XCTAssertNil(result.renderer, "Session restore must remain lazy: \(variant)")
        }
    }
}

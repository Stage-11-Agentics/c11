C11-259 round 1 repair checkpoint for review ev_01M3XGEZSK50N39M2QA5WBRH4C.

Pushed a770f89acd500a925a1af25dba85e37f0a7c706b to draft PR #504 at the explicitly authorized repair boundary. All 17 new CLI diagnostic branches now use String(localized:defaultValue:), and the empty-group status does too. CLI commands, flags and the workspace_group:N syntax are interpolated verbatim; group_not_found: remains outside the localized string. English diagnostic output is unchanged. This changes CLI/c11.swift only; GUI/model source is unchanged.

Validation now: Swift frontend parse and git diff --check pass. This is syntax verification, not an executed CLI or XCTest result. Exact-head CI is pending. Repaired CLI diagnostics and both live group/batch scenarios must run against the repaired built CLI on build-host. The matched main/candidate 60-workspace/six-folder comparison remains pending build-host BUILDS LIVE, as explicitly directed. No second HANDOFF yet; the next HANDOFF will cover both repairs.

C11-291 localization manifest (every interpolation is a String, hence %@; preserve each argument exactly, including command/flag/handle syntax):

| Key | Tokens | Argument order |
| --- | --- | --- |
| cli.workspaceGroup.error.duplicateOption | %@ | option |
| cli.workspaceGroup.error.emptyOptionValue | %@ | option |
| cli.workspaceGroup.error.unexpectedArgument | %@ | option |
| cli.workspaceGroup.error.noCurrentWindow | none | none |
| cli.workspaceGroup.error.unsupportedMethod | %@ | socket method |
| cli.workspaceGroup.error.invalidHandle | %@, %@ | supplied handle, workspace_group:N |
| cli.workspaceGroup.error.groupNotFound | %@, %@ | supplied handle, window handle; group_not_found: is outside translation |
| cli.workspaceGroup.error.invalidWorkspaceList | none | none |
| cli.workspaceGroup.error.missingVerb | %@, %@ | workspace-group, --help |
| cli.workspaceGroup.error.unknownVerb | %@, %@ | workspace-group, supplied verb |
| cli.workspaceGroup.error.missingOption | %@, %@, %@ | workspace-group, verb, required flag |
| cli.workspaceGroup.error.propertyOrClear | %@, %@ | --color or --icon, --clear |
| cli.workspaceGroup.error.conflictingPlacement | %@, %@, %@ | --before, --after, --index |
| cli.workspaceGroup.error.invalidMemberMove | %@, %@ | --group, --index |
| cli.workspaceGroup.error.invalidGroupMove | %@, %@, %@, %@ | --before, --after, --index, --to-group |
| cli.workspaceGroup.error.invalidIndex | %@ | --index |
| cli.workspaceGroup.list.empty | none | none |
| cli.reorderWorkspaces.error.missingOrder | %@, %@ | reorder-workspaces, --order |

Six-locale translations remain assigned to C11-291. No skill behavior changed in this repair.

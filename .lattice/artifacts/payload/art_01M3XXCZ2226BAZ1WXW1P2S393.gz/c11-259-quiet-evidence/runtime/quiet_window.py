"""Hold both real build-host flock slots for one bounded C11-259 comparison."""
import fcntl,json,os,signal,subprocess,sys,time,uuid
from pathlib import Path
root=Path('/tmp/c11-259-perf/paired-quiet');root.mkdir(parents=True,exist_ok=False)
started=time.monotonic();deadline=started+2700;token=uuid.uuid4().hex;files={};acquired={};reason='unknown'
state={'owner':'C11-259','pid':os.getpid(),'token':token,'started_unix':time.time(),'started_monotonic':started,'deadline_monotonic':deadline,'cap_s':2700,'acquired':acquired,'released':False,'ready':False}
def write_state():
 tmp=root/'lease.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(root/'lease.json')
def stop(signum,frame):raise RuntimeError('quiet window interrupted by signal '+str(signum))
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
write_state();last_ps=-30
try:
 for n in (1,2):files[n]=Path(f'/tmp/c11-build-host-build-slots/slot-{n}.lock').open('a+')
 with (root/'load.jsonl').open('w') as log:
  while True:
   now=time.monotonic();load=os.getloadavg();row={'unix':time.time(),'monotonic':now,'elapsed_s':now-started,'load':load,'held_slots':sorted(acquired)}
   if now>=deadline:reason='45-minute-cap';break
   if (root/'release-request.json').exists():
    request=json.loads((root/'release-request.json').read_text());assert request['token']==token;reason=request['reason'];break
   for n,f in files.items():
    if n not in acquired:
     try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired[n]={'unix':time.time(),'monotonic':time.monotonic(),'path':f.name};write_state()
     except BlockingIOError:pass
   if len(acquired)==2 and load[0]<8 and not state['ready']:
    state.update(ready=True,ready_unix=time.time(),ready_monotonic=time.monotonic(),ready_load=load);write_state();print('QUIET_READY '+json.dumps(state),flush=True)
   if now-last_ps>=30:
    ps=subprocess.check_output(['ps','-axo','pid,ppid,pcpu,comm'],text=True);(root/f'host-processes-{int(now-started):04d}.txt').write_text(ps);last_ps=now
   row['held_slots']=sorted(acquired);row['ready']=state['ready'];log.write(json.dumps(row)+'\n');log.flush();time.sleep(1)
except BaseException as e:
 reason='error: '+str(e);raise
finally:
 # Release immediately, including on timeout/interruption. Never unlink shared locks.
 for f in files.values():
  try:fcntl.flock(f,fcntl.LOCK_UN)
  finally:f.close()
 state.update(released=True,released_unix=time.time(),released_monotonic=time.monotonic(),elapsed_s=time.monotonic()-started,release_reason=reason);write_state();print('QUIET_RELEASED '+json.dumps(state),flush=True)
 if reason!='pair-complete':
  # Only our two verified tagged apps, never another seat or production.
  import AppKit
  for tag in ['c11-259-control','c11-259']:
   bid='com.stage11.c11.debug.'+tag.replace('-','.')
   for app in AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bid):
    if Path(str(app.bundleURL().path())).name==f'c11 DEV {tag}.app':app.forceTerminate()

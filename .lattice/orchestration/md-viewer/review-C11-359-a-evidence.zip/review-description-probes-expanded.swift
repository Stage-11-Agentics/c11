
extension DescriptionSanitizerTests {
    func testReviewSetextHeadingKeepsHeadingSemantics() {
        XCTAssertEqual(titleBarDescriptionBlocks("Status\n======"), [.heading(level: 1, text: "Status")])
        XCTAssertEqual(titleBarDescriptionBlocks("Status\n------"), [.heading(level: 2, text: "Status")])
    }
    func testReviewClosingATXHashesAreNotRenderedAsText() {
        XCTAssertEqual(titleBarDescriptionBlocks("## Status ##"), [.heading(level: 2, text: "Status")])
    }
    func testReviewWrappedListContinuationStaysInItem() {
        XCTAssertEqual(titleBarDescriptionBlocks("- Deploy the change\n  after CI passes"), [.listItem(marker: "•", text: "Deploy the change after CI passes", depth: 0)])
    }
    func testReviewRepeatedOrderedMarkersRenderSequentially() {
        XCTAssertEqual(titleBarDescriptionBlocks("1. First\n1. Second"), [.listItem(marker: "1.", text: "First", depth: 0), .listItem(marker: "2.", text: "Second", depth: 0)])
    }
}

extension DescriptionSanitizerTests {
    func testReviewReferenceLinkAcrossBlocksKeepsLabel() {
        let blocks = titleBarDescriptionBlocks("See [plan][p].\n\n[p]: https://example.invalid/plan")
        let rendered = blocks.compactMap { block -> String? in
            guard case .paragraph(let text) = block else { return nil }
            return String(titleBarDescriptionInline(text).characters)
        }.joined(separator: "\n")
        XCTAssertEqual(rendered, "See plan.")
    }
    func testReviewHardLineBreakStaysVisible() {
        let blocks = titleBarDescriptionBlocks("First line  \nSecond line")
        guard case .paragraph(let text) = blocks.first else { return XCTFail("Missing paragraph") }
        XCTAssertEqual(String(titleBarDescriptionInline(text).characters), "First line\nSecond line")
    }
}

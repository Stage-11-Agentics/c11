"""Post-capture analysis only; cannot launch, mutate, retry, or change a sample."""
import argparse, collections, hashlib, json, math
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pair',required=True);p.add_argument('--identity',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=Path(a.pair);identity=json.loads(Path(a.identity).read_text())
def read(path):return json.loads(Path(path).read_text())
def stats(values):
    v=sorted(values)
    return {'count':len(v),'mean_ms':sum(v)/len(v) if v else None,
            **{f'p{pct}_ms':v[max(0,math.ceil(len(v)*pct/100)-1)] if v else None for pct in (50,95,99)},'max_ms':max(v) if v else None}
rows=[json.loads(l) for l in (root/'paired-samples.jsonl').read_text().splitlines()] if (root/'paired-samples.jsonl').exists() else []
errors=[];budgets=[];phases={};seen=set()
for row in rows:
    key=(row['phase'],row['index'],row['role'])
    if key in seen:errors.append('duplicate sample '+str(key))
    seen.add(key)
    if row.get('ok'):
        frames=row.get('frames',[])
        if not frames or abs(row['latency_ms']-(frames[-1]['capture_end_ns']-row['input_post_ns'])/1e6)>.000001:errors.append('latency/timestamp mismatch '+str(key))
        role=row['role'];c=read(root/role/'calibration/config.json');template=read(c['templates'][row['expected']])
        if frames[-1]['sha256']!=template['sha256']:errors.append('visible endpoint mismatch '+str(key))
        for suffix in ('before','after'):
            if not (root/role/'run/crops'/(row['id']+'-'+suffix+'.png')).exists():errors.append('missing crop '+str(key))
        if row['metric']=='switch' and row.get('selected_expected')!=row.get('selected_observed'):errors.append('selected identity mismatch '+str(key))
for role in ('control','candidate'):
    c=read(root/role/'calibration/config.json')
    if c['artifact_sha256']!=identity[role]['artifact_sha256']:errors.append('artifact identity mismatch '+role)
    if c['calibration_spec_sha256']!=identity[role]['calibration_spec_sha256']:errors.append('spec identity mismatch '+role)
    if not c.get('templates_visually_verified'):errors.append('unreviewed templates '+role)
    for name,path in c['templates'].items():
        t=read(path);raw=Path(t['pixels']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=t['sha256']:errors.append('template hash mismatch '+role+'/'+name)
for phase in ('no-churn','churn','quiescence'):
    metrics={}
    for metric,total,minimum in (('typing',105,100),('switch',42,40),('scroll',42,40)):
        role_stats={};paired={}
        for role in ('control','candidate'):
            raw=[r for r in rows if r['phase']==phase and r['metric']==metric and r['role']==role];valid=[r for r in raw if r.get('ok')]
            role_stats[role]={'attempted':len(raw),'valid':len(valid),'invalid':len(raw)-len(valid),'latency':stats([r['latency_ms'] for r in valid]),
                'setup_noise':stats([r['setup_ms'] for r in raw]),'activation_noise':stats([r['activation_ms'] for r in raw]),
                'pre_capture_noise':stats([r['pre_capture']['capture_ms'] for r in raw if 'pre_capture' in r]),
                'frame_capture_noise':stats([f['capture_ms'] for r in raw for f in r.get('frames',[])])}
            paired[role]={r['index']:r for r in valid}
            if len(raw)!=total or len(valid)<minimum:errors.append(f'{phase}/{metric}/{role}: attempted {len(raw)}/{total}, valid {len(valid)}/{minimum}')
        deltas=[paired['candidate'][i]['latency_ms']-paired['control'][i]['latency_ms'] for i in sorted(paired['control'].keys()&paired['candidate'].keys())]
        for q,mult,add in ((95,1.20,5),(99,1.25,15)):
            left=role_stats['control']['latency'][f'p{q}_ms'];right=role_stats['candidate']['latency'][f'p{q}_ms'];limit=max(left*mult,left+add) if left is not None else None
            budgets.append({'phase':phase,'metric':metric,'percentile':q,'control_ms':left,'candidate_ms':right,'limit_ms':limit,'pass':right<=limit if right is not None and limit is not None else None})
        metrics[metric]={'roles':role_stats,'paired_delta_candidate_minus_control':stats(deltas),'absolute_pair_noise':stats([abs(d) for d in deltas])}
    phases[phase]=metrics
loads=[r[k]['load'][0] for r in rows for k in ('host_before','host_after') if k in r]
pairloads=[]
for phase in phases:
    for index in sorted({r['index'] for r in rows if r['phase']==phase}):
        pair=[r for r in rows if r['phase']==phase and r['index']==index]
        if len(pair)==2 and [r['role'] for r in pair]==['control','candidate']:
            pairloads.append({'phase':phase,'index':index,'metric':pair[0]['metric'],'candidate_minus_control_ms':pair[1].get('latency_ms',0)-pair[0].get('latency_ms',0) if all(r.get('ok') for r in pair) else None,
                              'control_before_after_load':[pair[0][k]['load'] for k in ('host_before','host_after')],
                              'candidate_before_after_load':[pair[1][k]['load'] for k in ('host_before','host_after')]})
        else:errors.append('unbalanced/out-of-order A/B pair '+phase+'/'+str(index))
complete=(root/'samples-complete.json').exists()
if not complete:errors.append('full collection completion marker absent; no phase extension or retry')
result={'schema':'c11-261-interleaved-comparison-v1','status':'INCOMPLETE' if errors else 'FAIL' if any(b['pass'] is False for b in budgets) else 'PASS',
        'candidate_sha':identity['candidate']['source_sha'],'control_sha':identity['control']['source_sha'],'identity_file':a.identity,
        'protocol':'Orchestrator interleaving ruling, seal015: 60s warmup, fixed130s phases,105/42/42 perrole,1300churn each role at10Hz',
        'errors':errors,'budgets':budgets,'phases':phases,'samples':len(rows),'paired_load_and_deltas':pairloads,
        'load1_min':min(loads) if loads else None,'load1_max':max(loads) if loads else None,
        'noise_subtracted':False,'independent_review':'pending Astra; owner observations only','operator_approval':'blank'}
Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','samples','load1_min','load1_max','errors','budgets')},indent=2))

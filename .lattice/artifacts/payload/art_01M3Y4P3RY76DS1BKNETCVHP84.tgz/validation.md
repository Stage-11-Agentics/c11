C11-295 merged-head validation: 6eaab8c58001cb3ff487355e0332d1c6aa643e2a, merging main dac4fcede017f86f1bf809a57bf5142989992a1e. Draft PR: https://github.com/Stage-11-Agentics/c11/pull/530.

Tagged Debug build PASS. Exact-head isolated keyboard gate PASS: 40 streaming terminals, 100 native keyboard observations across 106.02 seconds, zero misses, workspace create/close and switching included, fixture cleanup clean. Return-event-to-PTY p95 22.144 ms, maximum 28.184 ms. Return-event-to-read-screen p95 39.868 ms, maximum 42.588 ms. Runtime executable SHA256 853cefd304ea28bfe76afb9c63f563855dc6b3b72a5ab09e61a6f8a35aaaabcf matches the original build artifact.

Main's fixture changes add a five-second stream warmup and half-second stable-focus preflight. Pacing and host load differ from earlier runs; no comparative performance gain is claimed. These are synthesized-event metrics, not physical keyboard or visible frame latency. Native lock acquisition remains bounded while formatting/allocation/copy after acquisition remain on main and unbounded.

The seven-step Validator scenario in the preceding validation comment still applies, including 50+ workspace switch/restore checks. Earlier targeted tests and read/transport proofs retain their original heads; the owner did not repeat full suites after merging main. Conflicts combined appended tests, API guidance and fixture metadata, with no manual product-code conflict resolution. Current-head CI is running.

A neutral cropped native-input screenshot and runtime/build summaries accompany this comment. Terminal area readability was checked at 824 × 648 points. No merge, release, or installed-skill sync was performed.

#!/usr/bin/env bash
set -euo pipefail
export C11_SANDBOX_HOST=local
repo="$HOME/c11-builds/md-359/source"
source "$repo/scripts/sandbox-common.sh"
sandbox_guest_script md359-final <<'GUEST'
set -eu
if /bin/ps -p 605 -o command= >/dev/null; then
 printf '%s\n' 'Expected exact DEV PID605 to have exited' >&2; exit 1
fi
printf '%s\n' '{"dismissal":"exact PID menu Quit then AX confirmation","pid":605,"remaining":false}' > '/Volumes/My Shared Files/out/final-dismissal.json'
/usr/bin/find '/Volumes/My Shared Files/out' -maxdepth 1 -type f -print
GUEST
"$repo/scripts/sandbox-down.sh" md359-final
/usr/bin/python3 - <<'PY'
from pathlib import Path
import os,signal,subprocess
path=Path('/tmp/md359-final-hardstop.pid')
pid=int(path.read_text())
check=subprocess.run(['/bin/ps','-p',str(pid),'-o','command='],text=True,capture_output=True)
if check.returncode==0 and '/tmp/md359-final-hardstop.py' in check.stdout:
 os.kill(pid,signal.SIGTERM)
 print('Disarmed exact bounded hardstop PID',pid)
PY
/opt/homebrew/bin/tart list

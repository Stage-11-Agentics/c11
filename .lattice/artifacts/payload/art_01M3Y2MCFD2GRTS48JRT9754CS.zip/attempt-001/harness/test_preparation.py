"""Pure failure-injection checks. No process, signal, app, socket, SSH or real lock access."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import appearance
import ui_slot
from lease import atomic


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='pure-bootstrap-')
        self.root=Path(self.temp.name);self.lock=self.root/'ui-lock';self.events=[];self.started=False
    def tearDown(self):self.temp.cleanup()
    def factory(self,fail=None,abort_raises=False):
        owner=self
        class FakeSupervisor:
            def __init__(self,root,role,state):
                owner.events.append('spawn');self.state=state
                if fail=='spawn':raise OSError('Popen failed')
            def wait(self,stage):
                owner.events.append('wait-'+stage)
                if fail==stage:raise OSError(stage+' failed')
                return dict(self.state,stage=stage,watchdog_ready=True)
            def launch(self):owner.events.append('launch');owner.started=True
            def handoff(self):owner.events.append('handoff')
            def close(self):owner.events.append('close')
            def abort(self):
                owner.events.append('abort')
                if abort_raises:raise RuntimeError('cleanup unproven')
                owner.started=False;return True
        return FakeSupervisor
    def run_bootstrap(self,**kw):
        return ui_slot.bootstrap(self.root,'control','/synthetic/c11 DEV c11-260-control.app',{'token':'PAIR'},lock=self.lock,**kw)
    def test_existing_lock_is_never_deleted_or_adopted(self):
        self.lock.mkdir();atomic(self.lock/'lease.json',{'token':'FOREIGN'});(self.lock/'foreign').write_text('keep')
        with self.assertRaises(FileExistsError):self.run_bootstrap(factory=self.factory())
        self.assertEqual((self.lock/'foreign').read_text(),'keep');self.assertFalse((self.root/'control').exists());self.assertEqual(self.events,[])
    def test_each_state_write_failure_rolls_back_only_owned_reservation_without_launch(self):
        for fail_at in (1,2,3):
            with self.subTest(write=fail_at):
                sub=self.root/str(fail_at);sub.mkdir();calls=0
                def writer(path,value):
                    nonlocal calls
                    calls+=1
                    if calls==fail_at:raise OSError('ENOSPC')
                    atomic(path,value)
                with self.assertRaises(OSError):ui_slot.bootstrap(sub,'control','/synthetic/app',{'token':'P'},lock=sub/'lock',factory=self.factory(),writer=writer)
                self.assertFalse((sub/'lock').exists());self.assertFalse((sub/'control').exists());self.assertTrue((sub/'control-ui-attempt.json').exists())
        self.assertEqual(self.events,[]);self.assertFalse(self.started)
    def test_spawn_and_ready_failure_never_send_launch_permission(self):
        for fail in ('spawn','ready'):
            sub=self.root/fail;sub.mkdir();self.events=[]
            with self.assertRaises(OSError):ui_slot.bootstrap(sub,'control','/synthetic/app',{'token':'P'},lock=sub/'lock',factory=self.factory(fail))
            self.assertNotIn('launch',self.events);self.assertFalse((sub/'lock').exists());self.assertFalse((sub/'control').exists())
    def test_post_launch_failures_stop_exact_owned_child_before_rollback(self):
        for fail in ('launched','active'):
            sub=self.root/fail;sub.mkdir();self.events=[]
            with self.assertRaises(OSError):ui_slot.bootstrap(sub,'control','/synthetic/app',{'token':'P'},lock=sub/'lock',factory=self.factory(fail))
            self.assertFalse(self.started);self.assertIn('abort',self.events);self.assertFalse((sub/'lock').exists());self.assertTrue(list(sub.glob('failed-control-*')))
    def test_unproven_post_launch_cleanup_keeps_reservation(self):
        with self.assertRaises(OSError):self.run_bootstrap(factory=self.factory('launched',abort_raises=True))
        self.assertTrue(self.started);self.assertTrue(self.lock.exists());self.assertTrue((self.root/'control').exists())
    def test_launch_follows_ready_and_active_handoff_precedes_return(self):
        result=self.run_bootstrap(factory=self.factory())
        self.assertEqual(self.events,['spawn','wait-ready','launch','wait-launched','handoff','wait-active','close'])
        self.assertEqual(result['stage'],'active');self.assertLessEqual(result['deadline_monotonic']-result['started_monotonic'],1200.01)
    def test_supervisor_initial_read_or_child_bootstrap_exception_is_inside_cleanup(self):
        for fail in ('read','child'):
            sub=self.root/fail;sub.mkdir();lock=sub/'lock'
            state=ui_slot.bootstrap(sub,'control','/synthetic/app',{'token':'P'},lock=lock,factory=self.factory())
            self.started=False  # Separate pure supervisor scenario; no executable was actually created.
            patches=[patch.object(ui_slot.signal,'signal'),patch.object(ui_slot,'request_release')]
            if fail=='read':patches.append(patch.object(ui_slot,'read',side_effect=OSError('initial read failed')))
            else:patches.append(patch.object(ui_slot,'gated_child',side_effect=OSError('fork failed')))
            with patches[0],patches[1],patches[2]:ui_slot.supervise(sub,'control',state,-1,lock=lock)
            # read failure makes ownership token inspection unavailable, so leave reservation
            # fail-closed rather than delete an unverified directory; no child launched.
            released=json.loads((sub/'control/ui-lease.json').read_text()) if (sub/'control').exists() else json.loads(next(sub.glob('failed-control-*/ui-lease.json')).read_text())
            self.assertTrue(released['released']);self.assertTrue(released['process_gone']);self.assertTrue(released['expired'])
    def test_supervisor_launch_handoff_then_deadline_stops_only_its_child(self):
        state=self.run_bootstrap(factory=self.factory())
        now=[state['started_monotonic']]
        state['deadline_monotonic']=now[0]+1
        atomic(self.root/'lease.json',{'released':False})
        actions=[];commands=iter([b'L',b'H']);polls=[0]
        class FakeChild:
            pid=987
            def poll(self):polls[0]+=1;return False
            def stop(self):actions.append(('stop',987));return True
        def clock():now[0]+=.05;return now[0]
        def ready(fds,*_):return (fds if fds else [],[],[])
        with patch.object(ui_slot.signal,'signal'),patch.object(ui_slot,'request_release'), \
             patch.object(ui_slot,'gated_child',return_value=(FakeChild(),100)), \
             patch.object(ui_slot.os,'read',side_effect=lambda *_:next(commands)), \
             patch.object(ui_slot.os,'write',side_effect=lambda fd,data:actions.append(('write',fd,data))), \
             patch.object(ui_slot.os,'close',side_effect=lambda fd:actions.append(('close',fd))), \
             patch.object(ui_slot.select,'select',side_effect=ready), \
             patch.object(ui_slot.time,'monotonic',side_effect=clock),patch.object(ui_slot.time,'sleep'):
            ui_slot.supervise(self.root,'control',state,99,lock=self.lock)
        final=json.loads((self.root/'control/ui-lease.json').read_text())
        self.assertEqual(final['reason'],'20-minute-cap');self.assertTrue(final['process_gone'])
        self.assertIn(('write',100,b'L'),actions);self.assertIn(('close',99),actions)
        self.assertEqual([a for a in actions if a[0]=='stop'],[('stop',987)])
        self.assertFalse(self.lock.exists());self.assertTrue(final['expired'])
    def test_rollback_refuses_foreign_replacement_even_with_same_path(self):
        state=self.run_bootstrap(factory=self.factory());atomic(self.lock/'lease.json',{'token':'FOREIGN'})
        ui_slot.rollback(self.root,'control',state,self.lock)
        self.assertTrue(self.lock.exists());self.assertEqual(json.loads((self.lock/'lease.json').read_text())['token'],'FOREIGN')
    def test_reaped_child_and_unowned_pid_are_never_signalled(self):
        signals=[]
        child=ui_slot.OwnedChild(123,waitpid=lambda *_:(123,0),kill=lambda *args:signals.append(args))
        self.assertTrue(child.stop());self.assertEqual(signals,[])
        def not_ours(*_):raise ChildProcessError('not a child')
        child=ui_slot.OwnedChild(456,waitpid=not_ours,kill=lambda *args:signals.append(args))
        with self.assertRaises(ChildProcessError):child.stop()
        self.assertEqual(signals,[])
    def test_cleanup_signals_only_owned_unreaped_pid_and_waits_for_exit(self):
        answers=iter([(0,0),(789,0)]);signals=[]
        child=ui_slot.OwnedChild(789,waitpid=lambda *_:next(answers),kill=lambda *a:signals.append(a))
        self.assertTrue(child.stop());self.assertEqual(signals,[(789,ui_slot.signal.SIGKILL)])


class AppearanceTests(unittest.TestCase):
    def setUp(self):
        self.config={k:'synthetic-'+k for k in appearance.IDENTITY};self.config['pid']=42
        self.spec={'theme':'Dark','font':'Synthetic Mono 12','scale':1,'sidebar_width':200}
        self.setup=json.dumps(self.config).encode();self.png=b'synthetic-image-bytes-not-a-runtime-screenshot'
        self.review={'reviewer':'synthetic test','evidence':['synthetic observation'], 'observed_directly':True,
                     'setup_config_sha256':hashlib.sha256(self.setup).hexdigest(),'setup_png_sha256':hashlib.sha256(self.png).hexdigest(),
                     'identity':copy.deepcopy(self.config),'observed':copy.deepcopy(self.spec)}
    def validate(self,review):return appearance.validate(self.config,self.spec,review,self.setup,self.png)
    def test_matching_external_observation_is_accepted(self):self.assertEqual(self.validate(self.review),self.spec)
    def test_spec_copy_without_observed_evidence_is_rejected(self):
        with self.assertRaises(RuntimeError):self.validate({'observed':self.spec})
    def test_wrong_pid_config_image_or_observed_geometry_is_rejected(self):
        for change in ('pid','config','image','width'):
            record=copy.deepcopy(self.review)
            if change=='pid':record['identity']['pid']=43
            elif change=='config':record['setup_config_sha256']='bad'
            elif change=='image':record['setup_png_sha256']='bad'
            else:record['observed']['sidebar_width']=201
            with self.subTest(change=change),self.assertRaises(RuntimeError):self.validate(record)


if __name__=='__main__':unittest.main()


extension DescriptionSanitizerTests {
    func testReviewSetextHeadingKeepsHeadingSemantics() {
        XCTAssertEqual(titleBarDescriptionBlocks("Status\n======"), [.heading(level: 1, text: "Status")])
        XCTAssertEqual(titleBarDescriptionBlocks("Status\n------"), [.heading(level: 2, text: "Status")])
    }
    func testReviewClosingATXHashesAreNotRenderedAsText() {
        XCTAssertEqual(titleBarDescriptionBlocks("## Status ##"), [.heading(level: 2, text: "Status")])
    }
    func testReviewWrappedListContinuationStaysInItem() {
        XCTAssertEqual(titleBarDescriptionBlocks("- Deploy the change\n  after CI passes"), [.listItem(marker: "•", text: "Deploy the change after CI passes", depth: 0)])
    }
    func testReviewRepeatedOrderedMarkersRenderSequentially() {
        XCTAssertEqual(titleBarDescriptionBlocks("1. First\n1. Second"), [.listItem(marker: "1.", text: "First", depth: 0), .listItem(marker: "2.", text: "Second", depth: 0)])
    }
}

# C11-259 round 1 build-host comparison

Execution authorized by the Orchestrator's build-host BUILDS LIVE announcement (C11-216 main 86d45e218f). Do not run this comparison on operator-host. Read the announced main-branch remote-build script and hotload skill before choosing its invocation. Use only dedicated tagged builds, one locked build at a time, with QA launch enabled. Do not modify any production session or other seat's app.

## Identities and setup

- Candidate: 0440a7e939c474db70bed1a9be14c130edbbc062. Control: main 86d45e218f220c89b592653de2f1c488d57068f7, pinned before either run. Record both SHAs, merge-base, Sources and CLI tree IDs, relevant submodule SHAs, build commands, app bundle ID/version, GUI/dylib/CLI SHA256, host/OS, and output manifest hashes.
- Same build-host host, verified display, window dimensions, theme, font, scale and capture mechanism. Record display refresh rate and the two runs' load averages. Our builds and tests completed before measuring. build-host is shared: another seat's xcodebuild was present at control startup and system services/VMs remained active. Preserve process snapshots and phase load; do not claim a quiet host. Do not copy tenant config or session files.
- Provision g60-v1 separately on each app with the same deterministic labels/tab composition: w01-w60; browser tabs on w04/w33; markdown tabs on w05/w34; idle terminals elsewhere; individual pins w01/w02/w29-w32. Candidate groups: Pinned Fleet w01-w08 (pinned), Collapsed Flag w09-w14 (collapsed), Empty Pinned (pinned), Empty Collapsed (collapsed), Tail w15-w24, Move Lane w25-w28; w29-w60 ungrouped. Control has the same workspaces/tabs/pins ungrouped. Preserve every initial workspace/tab UUID and shell PID in a per-build manifest.
- Two pinned terminal workspaces show distinct static synthetic visible markers for switch probes. The typing terminal runs a tiny raw-input echo fixture that paints only the expected input glyph in a fixed cell with cursor blinking disabled, while preserving the normal macOS event/terminal/PTTY/render path. Use the same fixture executable and hash in both builds.
- Before measurement, calibrate expected glyph templates, both workspace marker templates and two actual sidebar scroll endpoints. Save annotated screenshots, crop geometry, templates and template hashes. Prove negative controls: prior glyph, other workspace marker, and prior sidebar position must not satisfy the expected target.

## Measured phases

Each build: 60 seconds no churn, 60 seconds churn, 60 seconds quiescence. Preserve raw monotonic input/capture timestamps. Schedule 105 typing, 42 scroll and 42 switch probes over the first 58 seconds (two seconds completion margin), requiring at least 100 valid typed-glyph observations, 40 valid sidebar-scroll observations and 40 valid workspace-switch observations in EACH phase; additionally retain every failed/timed-out trial. Do not extend an overrun phase silently or pool phases to reach a sample minimum.

Input is synthesized to the verified tagged PID/window. Latency starts immediately before posting the input and ends at the first captured frame containing the EXPECTED glyph/marker/scroll position. A socket ACK, AX state alone, cursor blink, title change or arbitrary pixel difference cannot satisfy the latency oracle. Save enough frame/crop evidence and timestamps to audit each accepted transition. Measure and report capture/template-check overhead independently; report raw end-to-end latency without subtracting it.

During churn, schedule 600 operations at 10/s using a worker independent of the UI probe. Candidate alternates workspace reorder and member transfer (300 each), keeping the probe workspaces stable. Control uses 600 existing singular workspace reorder operations on the same tail population; do not assume it supports batch/group APIs. Record scheduled/started/completed times, method, arguments, IDs, outcome and error for every operation. Rate shortfalls, phase overruns and missing sample counts make the comparison incomplete. The same sampler/workload ordering runs on both builds.

At the churn boundary join the mutation worker, verify it has no queued/pending operations, and take the complete model snapshot. Quiescence uses probes only, with no hidden mutation worker. Record process CPU, footprint and tagged hang telemetry at each phase boundary, plus before/after idle observations. These are descriptive, not invented performance budgets.

## Assertions and acceptance

- For every metric in every matched phase: p95(candidate) <= max(p95(control) * 1.20, p95(control) + 5 ms); p99(candidate) <= max(p99(control) * 1.25, p99(control) + 15 ms). Retain sample count, timeout count, p50/p95/p99/max and achieved churn count/rate. Use nearest-rank percentiles, document the method, and retain raw data.
- Verify all 60 workspace UUIDs remain unique and complete, tabs/PIDs show no anchor creation, pins and expected membership match the operation log, and selected workspace agrees with the last explicit switch probe. Invalid batches must leave the complete candidate model unchanged. Retain initial, phase-boundary and final snapshots.
- Execute WorkspaceGroupTests, WorkspaceReorderPlannerTests and WorkspaceManagerSessionSnapshotTests through their actual registered target (Group/Planner in c11LogicTests; WorkspaceManagerSessionSnapshotTests in hosted c11Tests after correcting its existing bare-runner NSApp-nil crash), recording assertion results and any required host context. Do not accept compilation-only evidence or an advisory host-test failure. Run repaired CLI diagnostics plus tests_v2/test_workspace_groups.py and test_workspace_batch_reorder.py against the candidate's built CLI and exact tagged socket.
- Hard-cap each UI run at 20 minutes. Enumerate displays first. Verify synthesized dismissal of each tagged app and gone PID; retain cleanup evidence. Never leave a benchmark app occupying the display or hold a UI lock after the run.

Attach raw data, scripts/templates, screenshots, logs, identities, checksums and the comparison summary to C11-259. This short matched comparison does not replace W2/W3 UI validation or the deferred C11-270 fleet soak. Send one new HANDOFF only after both the localization repair and this comparison have evidence.

## Setup deviations retained

QA-fresh first launch had a four-tab welcome layout. Provisioning closed only the owned initial extra tabs before measured identity capture. The rejected initial fixture and rejected first control pass remain in the evidence. The first control pass had valid transitions but its final scroll exceeded the fixed window by 165 ms; it is excluded from comparison. Both accepted runs use the revised identical 105/42/42 schedule. Scroll uses real cursor movement and HID wheel input inside the verified tagged window because PID-posted wheel events did not scroll; keys/clicks are PID-targeted.

## Matched preconditioning correction

The first full pair (`control-run-r2` vs `candidate-run-r2`) produced three p99 failures, retained verbatim in `comparison.json`. Before measurement the candidate had run both functional suites and 37 CLI cases while the control ran only two unsupported-method cases; after-phase footprint was about 3482 MB vs2904 MB. These are unequal preconditions, so that pair is exploratory rather than the primary acceptance pair. The candidate's first partial run is also retained.

The primary comparison is `paired-fresh/control/run` vs `paired-fresh/candidate/run`: each app is quit and launched QA-fresh; only the same g60 fixture/probe/calibration sequence runs before a fixed60-second idle settling interval and the same three60-second phases. No diagnostic/functional suite runs in either primary benchmark process. No source or binary changes occur between exploratory and primary runs. All prior failures stay visible; do not infer their cause from the footprint difference.

The recorder originally stopped on any failed setup or >100ms operation start delay, which exceeded the review's requirements. It now collects all three phases, requires at least100/40/40 valid samples and600 successful scheduled mutations completed in60seconds, and retains all failed/precondition/timeout/late observations. The comparison still enforces every p95/p99 limit. The before-fix recorder is preserved.

The primary fresh no-churn after-phase footprints were3362 MB control and3363 MB candidate (RSS681952 vs683728 KiB). Both cases use normal Debug bundles on the same 24-core/128GB build-host and display9 (1920x1080 logical,3840x2160 physical,60Hz reported). Shared load is recorded, not held constant. Primary runs are reported once as measured; prior exploratory budgets are neither pooled nor silently replaced.

"""Behavioral schedule tests; no native app, SSH, input, or workload."""
import unittest
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch
from collections import Counter
from schedule import schedule, pairs, assert_complete


class ABBATests(unittest.TestCase):
    def rows(self):
        return [dict(r, phase='no-churn', ok=True,
                     latency_ms=10 + (r['role'] == 'candidate')) for r in schedule()]

    def test_balanced_counts_and_ten_trial_blocks(self):
        rows = schedule()
        self.assertEqual(len(rows), 400)
        for role in ('control', 'candidate'):
            self.assertEqual(Counter(r['metric'] for r in rows if r['role'] == role),
                             {'typing': 120, 'switch': 40, 'scroll': 40})
        for cycle in range(10):
            roles = [r['role'] for r in rows if r['cycle'] == cycle]
            self.assertEqual(roles, ['control'] * 10 + ['candidate'] * 20 + ['control'] * 10)

    def test_pairs_counterbalance_and_preserve_delta(self):
        result = assert_complete(self.rows(), 'no-churn')
        self.assertEqual(len(result), 200)
        self.assertEqual(Counter(r['order'] for r in result), {'AB': 100, 'BA': 100})
        self.assertTrue(all(r['candidate_minus_control_ms'] == 1 for r in result))

    def test_duplicate_missing_or_mismatched_pair_rejected(self):
        rows = self.rows()
        for bad in (rows[:-1], rows + [rows[0]],
                    [dict(r, metric='scroll') if r['trial'] == 10 else r for r in rows]):
            with self.assertRaises(ValueError): pairs(bad)

    def test_noop_or_partial_order_cannot_pass(self):
        rows = self.rows()
        rows[0], rows[1] = rows[1], rows[0]
        with self.assertRaises(ValueError): assert_complete(rows, 'no-churn')
        with self.assertRaises(ValueError): assert_complete(self.rows()[:-2], 'no-churn')

    def test_minima_and_invalid_retention(self):
        rows = self.rows()
        for r in rows:
            if r['role'] == 'control' and r['metric'] == 'typing' and r['index'] < 20:
                r['ok'] = False
        self.assertEqual(len(assert_complete(rows, 'no-churn')), 200)
        self.assertEqual(len(rows), 400)
        next(r for r in rows if r['role'] == 'control' and r['metric'] == 'switch')['ok'] = False
        with self.assertRaises(ValueError): assert_complete(rows, 'no-churn')

    def test_abba_contrast_cancels_linear_trial_drift(self):
        for cycle in range(10):
            rows = [r for r in schedule() if r['cycle'] == cycle]
            means = [sum(10 + .5*r['trial'] + (r['role'] == 'candidate')*3
                         for r in rows if r['block'] == b) / 10 for b in range(4)]
            self.assertEqual((means[1] + means[2] - means[0] - means[3]) / 2, 3)

    def test_full_2400_operation_oracle_replay_preserves_probe_prefix(self):
        from g60 import next_operation, operation_category
        labels = {f'w{i:02d}': f'workspace-{i}' for i in range(1, 61)}
        order = [labels[f'w{i:02d}'] for i in range(1, 61)]
        attention = {k: {'flag': 'W2 synthetic flag' if k == 'w10' else None,
                         'suppressed': False} for k in ('w10', 'w46', 'w11', 'w45')}
        manifest = {'labels': labels, 'initial': {'window_id': 'owned', 'pins': dict.fromkeys(order, False)},
                    'stable_prefix': order[:24], 'groups': {'Move Lane': 'lane'},
                    'attention_tabs': dict.fromkeys(attention, {'tab_id': 'synthetic-tab'})}
        expected = {'order': order, 'membership': dict.fromkeys(order), 'attention': attention}
        categories = Counter()
        for n in range(2400):
            _, _, after = next_operation(manifest, expected, n, count=2400)
            self.assertNotEqual(after, expected)
            self.assertEqual(after['order'][:24], order[:24])
            expected = after
            categories[operation_category(n)] += 1
        self.assertEqual(categories, dict.fromkeys(('reorder', 'transfer', 'flag', 'waiting_suppression'), 600))
        with self.assertRaises(RuntimeError): next_operation(manifest, expected, 2400, count=2400)

    def test_post_capture_cleanup_never_admits_sampling_or_new_setup(self):
        import lease
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'control').mkdir()
            (root / 'lease.json').write_text(json.dumps({'released': True, 'token': 'PAIR'}))
            (root / 'samples-complete.json').write_text(json.dumps({'monotonic': 100}))
            ui = {'tag': 'c11-261', 'pair_token': 'PAIR', 'released': False, 'watchdog_ready': True,
                  'stage': 'active', 'deadline_monotonic': 150, 'heartbeat_monotonic': 110}
            (root / 'control/ui-lease.json').write_text(json.dumps(ui))
            with patch.dict(os.environ, {'C11_PERF_PAIR': directory, 'C11_PERF_ROLE': 'control'}, clear=True), \
                    patch.object(lease.time, 'monotonic', return_value=111):
                with self.assertRaises(RuntimeError): lease.require_runtime('c11-261')
                os.environ['C11_PERF_CLEANUP'] = '1'
                self.assertEqual(lease.require_runtime('c11-261'), ui)
                with patch.object(lease.time, 'monotonic', return_value=131):
                    with self.assertRaises(RuntimeError): lease.require_runtime('c11-261')
                (root / 'samples-complete.json').unlink()
                with self.assertRaises(FileNotFoundError): lease.require_runtime('c11-261')

    def test_full_3000_operation_oracle_replay_preserves_probe_prefix(self):
        from g60 import next_operation, operation_category
        labels = {f'w{i:02d}': f'workspace-{i}' for i in range(1, 61)}
        order = list(labels.values())
        attention = {k: {'flag': 'W2 synthetic flag' if k == 'w10' else None,
                         'suppressed': False} for k in ('w10', 'w46', 'w11', 'w45')}
        manifest = {'labels': labels, 'initial': {'window_id': 'owned', 'pins': dict.fromkeys(order, False)},
                    'stable_prefix': order[:24], 'groups': {'Move Lane': 'lane'},
                    'attention_tabs': dict.fromkeys(attention, {'tab_id': 'synthetic-tab'})}
        expected = {'order': order, 'membership': dict.fromkeys(order), 'attention': attention}
        counts = Counter()
        for n in range(3000):
            _, _, after = next_operation(manifest, expected, n, count=3000)
            self.assertNotEqual(after, expected)
            self.assertEqual(after['order'][:24], order[:24])
            expected = after
            counts[operation_category(n)] += 1
        self.assertEqual(counts, dict.fromkeys(('reorder', 'transfer', 'flag', 'waiting_suppression'), 750))
        with self.assertRaises(RuntimeError): next_operation(manifest, expected, 3000, count=3000)


if __name__ == '__main__': unittest.main()

"""Own the Atlas UI slot while the signoff runner gracefully answers its quit sheet."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import AppKit
import ApplicationServices as AX
import Quartz

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True)
p.add_argument('--results', required=True)
p.add_argument('--display', type=int, required=True)
a = p.parse_args()
lock = Path('/tmp/c11-1.0-ui.lock')
if Path('/tmp/c11-1.0-ui.reserved').exists():
    raise RuntimeError('Validator reservation is active')
lock.mkdir()
owner = {'ticket': 'C11-261', 'pid': os.getpid(), 'started': time.time(), 'cap_s': 1200}
(lock / 'owner.json').write_text(json.dumps(owner))
app_path = '/Users/atinwoodard/Library/Developer/Xcode/DerivedData/c11-c11-261/Build/Products/Debug/c11 DEV c11-261.app'
bundle = 'com.stage11.c11.debug.c11.261'
result_dir = Path(a.results)
result_dir.mkdir(exist_ok=False)
process = None
def attr(node, key):
    error, value = AX.AXUIElementCopyAttributeValue(node, key, None)
    return value if error == 0 else None
def walk(node, pid, seen, depth=0):
    if depth > 18 or len(seen) > 2000 or any(node == old for old in seen):
        return []
    seen.append(node)
    error, actual = AX.AXUIElementGetPid(node, None)
    if error or actual != pid:
        raise RuntimeError('AX node left assigned app')
    nodes = [node]
    for child in list(attr(node, 'AXChildren') or []):
        nodes.extend(walk(child, pid, seen, depth+1))
    return nodes
try:
    with (result_dir / 'runner.log').open('x') as runner_log, (result_dir / 'quit-ui.jsonl').open('x') as evidence:
        process = subprocess.Popen([str(Path(a.source)/'scripts/groups-signoff.sh'), 'c11-261',
                                   '--results', str(result_dir)], stdout=runner_log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        deadline = time.monotonic()+1200
        dismissed = set()
        while process.poll() is None and time.monotonic() < deadline:
            apps = list(AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bundle))
            for app in apps:
                if str(app.bundleURL().path()) != app_path:
                    raise RuntimeError('Unexpected path for assigned bundle')
                pid = app.processIdentifier()
                if pid in dismissed:
                    continue
                root = AX.AXUIElementCreateApplication(pid)
                AX.AXUIElementSetMessagingTimeout(root, .5)
                for window in list(attr(root, 'AXWindows') or []):
                    for sheet in list(attr(window, 'AXSheets') or []):
                        nodes = walk(sheet, pid, [])
                        labels = [str(attr(n, 'AXValue') or attr(n, 'AXTitle') or '') for n in nodes]
                        if 'Quit c11?' not in labels or 'This will close all windows and workspaces.' not in labels:
                            continue
                        buttons = [n for n in nodes if attr(n, 'AXRole') == 'AXButton' and attr(n, 'AXTitle') == 'Quit']
                        if len(buttons) != 1:
                            raise RuntimeError('Ambiguous quit action')
                        display = Quartz.CGDisplayBounds(a.display)
                        windows = [w for w in Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListOptionOnScreenOnly,0)
                                   if w.get('kCGWindowOwnerPID') == pid and w.get('kCGWindowLayer') == 0]
                        if not windows:
                            raise RuntimeError('No assigned visible window')
                        for item in windows:
                            b = item['kCGWindowBounds']
                            if not (b['X'] >= display.origin.x and b['Y'] >= display.origin.y and
                                    b['X']+b['Width'] <= display.origin.x+display.size.width and
                                    b['Y']+b['Height'] <= display.origin.y+display.size.height):
                                raise RuntimeError('Assigned quit UI escaped the verified display')
                        error = AX.AXUIElementPerformAction(buttons[0], 'AXPress')
                        evidence.write(json.dumps({'pid': pid, 'app_path': app_path, 'display': a.display,
                            'windows': windows, 'observed_labels': labels, 'synthesized': 'AXPress Quit',
                            'returncode': error, 'unix': time.time()})+'\n')
                        evidence.flush()
                        if error:
                            raise RuntimeError('Quit button action failed')
                        dismissed.add(pid)
            time.sleep(.15)
        if process.poll() is None:
            raise RuntimeError('20-minute signoff cap reached')
        raise SystemExit(process.returncode)
finally:
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=50)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    # Only our exclusively created lease files, never a foreign/replaced lock.
    if (lock / 'owner.json').exists() and json.loads((lock / 'owner.json').read_text()) == owner:
        (lock / 'owner.json').unlink()
        lock.rmdir()

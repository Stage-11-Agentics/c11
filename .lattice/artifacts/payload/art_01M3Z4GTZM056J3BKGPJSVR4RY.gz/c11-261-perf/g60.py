#!/usr/bin/env python3
"""g60-w2-v1 fixture and model oracle. Runtime is explicitly gated by --execute.

Standalone stdlib only. Does not discover, launch, build or quit any app.
Use only on Atlas after ATLAS BUILDS LIVE, with a separately authorized QA tag.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import socket
import subprocess
import threading
import time

PINS = {1, 2, 29, 30, 31, 32}
FOLDERS = [
    ("Pinned Fleet", True, False, range(1, 9)),
    ("Collapsed Flag", False, True, range(9, 15)),
    ("Empty Pinned", True, False, []),
    ("Empty Collapsed", False, True, []),
    ("Tail", False, False, range(15, 25)),
    ("Move Lane", False, False, range(25, 29)),
]


def check(ok, message):
    if not ok:
        raise RuntimeError(message)


def write_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def authorized_socket(tag, path):
    from lease import require_runtime
    check(tag in ("c11-261", "c11-261"), "only assigned W2 tags allowed")
    role = 'control' if path.endswith('-control.sock') else 'candidate' if path.endswith('-candidate.sock') else None
    require_runtime(tag, role)
    check(re.fullmatch(r"[a-z0-9][a-z0-9_.-]*", tag), "tag must already be a sanitized tag slug")
    expected = Path("/tmp") / ("c11-debug-" + tag + (('-'+role) if role else '') + ".sock")
    check(Path(path) == expected and not expected.is_symlink(), "explicit socket must match the exact tagged QA socket")
    check(expected.resolve().parent == Path("/tmp").resolve(), "socket escapes /tmp")
    check(expected.is_socket(), "tagged socket missing")
    return str(expected)


class RPC:
    def __init__(self, tag, path):
        self.tag, self.path = tag, path
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.socket.settimeout(3)
        self.socket.connect(authorized_socket(tag, path))
        self.file = self.socket.makefile("rb")
        self.serial = 0
        brand = self.call("system.brand")
        check(brand["bundle"]["identifier"] == "com.stage11.c11.debug." + tag.replace("-", "."),
              "socket bundle identity does not match assigned tag")

    def call(self, method, **params):
        authorized_socket(self.tag, self.path)
        self.serial += 1
        self.socket.sendall((json.dumps({"id": self.serial, "method": method, "params": params}) + "\n").encode())
        raw = self.file.readline(8 * 1024 * 1024)
        check(bool(raw) and raw.endswith(b"\n"), "truncated/closed RPC reply")
        reply = json.loads(raw)
        check(reply.get("id") == self.serial, "RPC response ID mismatch")
        check(reply.get("ok") is True, json.dumps(reply.get("error", reply)))
        return reply["result"]

    def close(self):
        self.file.close()
        self.socket.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def tree_state(rpc):
    raw = rpc.call("system.tree", scope="all")
    windows = raw["windows"]
    check(len(windows) == 1, "dedicated QA app must have exactly one window")
    window = windows[0]
    workspaces = window["workspaces"]
    state = {"window_id": window["id"], "selected": window["selected_workspace_id"],
             "order": [w["id"] for w in workspaces],
             "pins": {w["id"]: w["pinned"] for w in workspaces},
             "membership": {w["id"]: w.get("group_id") for w in workspaces},
             "groups": window.get("workspace_groups", []), "tabs": {}}
    for ws in workspaces:
        tabs = [tab for area in ws.get("areas", ws.get("panes", []))
                for tab in area.get("tabs", area.get("surfaces", []))]
        state["tabs"][ws["id"]] = [{"id": t["id"], "type": t["type"]} for t in tabs]
    return state, raw


def process_identity(pid):
    # Start time protects against a terminated shell's PID being reused.
    proc = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "pid=,lstart="],
                          capture_output=True, text=True, timeout=3)
    check(proc.returncode == 0 and proc.stdout.strip(), f"shell PID {pid} is gone")
    return " ".join(proc.stdout.split())


def capture(rpc, manifest, out_path):
    state, raw = tree_state(rpc)
    state["shells"] = {tab: process_identity(value["pid"])
                       for tab, value in manifest["shells"].items()}
    if "attention_tabs" in manifest:
        state["attention"] = {}
        for label, params in manifest["attention_tabs"].items():
            metadata = rpc.call("tab.get_metadata", **params)["metadata"]
            state["attention"][label] = {"flag": metadata.get("flag"), "suppressed": metadata.get("suppressed", False)}
        state["notifications"] = rpc.call("notification.list")["notifications"]
    write_json(out_path, {"monotonic": time.monotonic(), "wall_time": time.time(),
                          "load": os.getloadavg(), "state": state, "raw_tree": raw})
    return state


def assert_model(state, manifest, expected, selected):
    initial = manifest["initial"]
    ids = initial["order"]
    check(len(state["order"]) == len(set(state["order"])) == 60, "workspace count/uniqueness failed")
    check(set(state["order"]) == set(ids), "workspace identity set changed or anchor created")
    check(state["window_id"] == initial["window_id"], "fixture window identity changed")
    check(state["tabs"] == initial["tabs"], "tab identities/composition changed or anchor created")
    check(state["pins"] == initial["pins"], "pin bits changed")
    check(state["shells"] == initial["shells"], "shell PID/start identity changed")
    check(state["order"] == expected["order"], "canonical order differs from mutation oracle")
    check(state["membership"] == expected["membership"], "membership differs from mutation oracle")
    if "attention" in expected:
        check(state["attention"] == expected["attention"], "attention differs from mutation oracle")
        check(state["notifications"] == initial["notifications"], "notification identities/read state changed")
    prefix = manifest["stable_prefix"]
    check(state["order"][:len(prefix)] == prefix, "mutation moved top/probe rows")
    check(state["selected"] == selected, "selection differs from last explicit switch probe")
    # Group metadata/order stay stable; the derived member arrays/counts follow canonical order.
    predicted_groups = copy.deepcopy(initial["groups"])
    for group in predicted_groups:
        members = [ws for ws in expected["order"] if expected["membership"][ws] == group["id"]]
        group.update(member_workspace_ids=members, member_count=len(members))
    check(state["groups"] == predicted_groups, "group properties/order/member projection changed")


def provision(args):
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    note = out / "synthetic-note.md"
    note.write_text("# g60-w2-v1\n\nSynthetic workspace performance fixture.\n")
    manifest = {"version": "g60-w2-v1", "mode": args.mode, "tag": args.tag, "socket": args.socket,
                "host": platform.node(), "platform": platform.platform(), "source_sha": args.source_sha,
                "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "labels": {}, "groups": {}, "shells": {}, "probe_labels": ["w01", "w02"]}
    with RPC(args.tag, args.socket) as rpc:
        initial, raw = tree_state(rpc)
        check(len(initial["order"]) == 1 and not initial["groups"], "provision requires pristine --qa fresh app")
        win = initial["window_id"]
        # A QA-fresh first launch may show the four-tab welcome layout. Normalize
        # only this owned initial workspace before recording measured identities.
        first_ws = initial["order"][0]
        startup_tabs = rpc.call("tab.list", workspace_id=first_ws)["tabs"]
        keep = next((tab for tab in startup_tabs if tab["type"] == "terminal"), None)
        check(keep is not None, "fresh app has no starter terminal")
        manifest["removed_startup_tabs"] = [tab["id"] for tab in startup_tabs if tab["id"] != keep["id"]]
        for tab in startup_tabs:
            if tab["id"] != keep["id"]:
                rpc.call("tab.close", window_id=win, workspace_id=first_ws, tab_id=tab["id"])
        manifest["mount_log"] = args.mount_log
        manifest["mount_log_offset"] = Path(args.mount_log).stat().st_size
        manifest["labels"]["w01"] = first_ws
        for n in range(2, 61):
            manifest["labels"][f"w{n:02d}"] = rpc.call("workspace.create", window_id=win, focus=False)["workspace_id"]
            write_json(out / "provision-progress.json", manifest)
        # Observe the whole real background queue before selecting any new member.
        # Selection during creation could cancel queue entries and invalidate this proof.
        from prime_gate import evaluate
        prime_manifest = {"labels": manifest["labels"], "initial": {"order": list(manifest["labels"].values()), "window_id": win}}
        prime_deadline = time.monotonic() + 135
        while True:
            from lease import require_runtime
            require_runtime(args.tag)
            raw_prime = Path(args.mount_log).read_bytes()[manifest["mount_log_offset"]:]
            prime = evaluate(raw_prime.decode(errors="replace"), prime_manifest, max_mounts=2)
            if prime["complete"]: break
            check(time.monotonic() < prime_deadline, "Background prime queue failed to settle")
            time.sleep(.1)
        (out / "creation-prime.log").write_bytes(raw_prime)
        write_json(out / "creation-prime.json", prime)
        for n in range(1, 61):
            label = f"w{n:02d}"
            ws = manifest["labels"][label]
            manifest["labels"][label] = ws
            # Preserve recovery evidence if provisioning stops partway through.
            write_json(out / "provision-progress.json", manifest)
            rpc.call("workspace.rename", window_id=win, workspace_id=ws, title="g60-" + label)
            rpc.call("workspace.select", window_id=win, workspace_id=ws)
            tabs = rpc.call("tab.list", workspace_id=ws)["tabs"]
            check(len(tabs) == 1 and tabs[0]["type"] == "terminal", "unexpected initial tab composition")
            tab = tabs[0]["id"]
            kind = "browser" if n in (4, 33) else "markdown" if n in (5, 34) else "terminal"
            if kind != "terminal":
                params = {"url": "about:blank"} if kind == "browser" else {"file": str(note)}
                rpc.call("tab.create", window_id=win, workspace_id=ws, type=kind, focus=False, **params)
                rpc.call("tab.close", window_id=win, workspace_id=ws, tab_id=tab)
            else:
                pid_path = out / (label + ".pid")
                text = "export PS1='$ '; export PROMPT='$ '; unset RPROMPT; printf '%s\\n' \"$$\" > " + shlex.quote(str(pid_path)) + "; printf '\\033[2J\\033[H'"
                rpc.call("tab.send_text", workspace_id=ws, tab_id=tab, text=text)
                rpc.call("tab.send_key", workspace_id=ws, tab_id=tab, key="enter")
                deadline = time.monotonic() + 12
                pid_text = ""
                while time.monotonic() < deadline:
                    pid_text = pid_path.read_text().strip() if pid_path.exists() else ""
                    if pid_text.isdigit():
                        break
                    time.sleep(0.05)
                check(pid_text.isdigit(), f"shell {label} failed to attach/report PID (screen lock can prevent attachment)")
                pid = int(pid_text)
                manifest["shells"][tab] = {"pid": pid, "identity": process_identity(pid), "label": label}
            if n in PINS:
                rpc.call("workspace.action", window_id=win, workspace_id=ws, action="pin")
        # Normalize creation/preference-dependent insertion order using legacy singular API only.
        ordered = [manifest["labels"][f"w{n:02d}"] for n in sorted(PINS)]
        ordered += [manifest["labels"][f"w{n:02d}"] for n in range(1, 61) if n not in PINS]
        for index, ws in enumerate(ordered):
            rpc.call("workspace.reorder", window_id=win, workspace_id=ws, index=index)
        if args.mode in ("control", "candidate"):
            for name, pin, collapse, numbers in FOLDERS:
                group = rpc.call("workspace.group.create", window_id=win, name=name)["group"]["id"]
                manifest["groups"][name] = group
                if numbers:
                    rpc.call("workspace.group.add", window_id=win, group_id=group,
                             workspace_ids=[manifest["labels"][f"w{n:02d}"] for n in numbers])
                for enabled, verb in ((pin, "pin"), (collapse, "collapse")):
                    if enabled:
                        rpc.call("workspace.group." + verb, window_id=win, group_id=group)
        manifest["attention_tabs"] = {}
        for label in ("w10", "w11", "w45", "w46"):
            ws = manifest["labels"][label]
            tab = rpc.call("tab.list", workspace_id=ws)["tabs"][0]["id"]
            manifest["attention_tabs"][label] = {"workspace_id": ws, "tab_id": tab}
        # Exact unread tab notifications produce real waiting; no fake status pill.
        for label in ("w11", "w45"):
            params = manifest["attention_tabs"][label]
            rpc.call("tab.set_metadata", **params, metadata={"terminal_type": "codex"}, source="explicit")
            rpc.call("notification.create_for_tab", **params, title="W2 synthetic waiting", body=label)
        rpc.call("flag.suppress", **manifest["attention_tabs"]["w10"], by="operator")
        rpc.call("flag.raise", **manifest["attention_tabs"]["w10"], by="operator", reason="W2 synthetic flag")
        # Notification creation can promote its unpinned workspace to the top.
        # Restore the registered fixture order after all attention seeding, while
        # preserving notifications, membership, pins, selection and live tabs.
        for index, ws in enumerate(ordered):
            rpc.call("workspace.reorder", window_id=win, workspace_id=ws, index=index)
        rpc.call("workspace.select", window_id=win, workspace_id=manifest["labels"]["w01"])
        state = capture(rpc, manifest, out / "initial-snapshot.json")
        check(state["order"] == ordered, "provision canonical ordering mismatch")
        check(sum(len(tabs) for tabs in state["tabs"].values()) == 60, "expected exactly one tab/workspace")
        for n in range(1, 61):
            ws = manifest["labels"][f"w{n:02d}"]
            kind = "browser" if n in (4, 33) else "markdown" if n in (5, 34) else "terminal"
            check(len(state["tabs"][ws]) == 1 and state["tabs"][ws][0]["type"] == kind, "tab fixture mismatch")
            check(state["pins"][ws] == (n in PINS), "pin fixture mismatch")
        expected_members = {ws: None for ws in ordered}
        if args.mode in ("control", "candidate"):
            check(len(state["groups"]) == 6 and sum(g["member_count"] == 0 for g in state["groups"]) == 2,
                  "both roles must have exactly six groups, two empty")
            for name, _, _, numbers in FOLDERS:
                for n in numbers:
                    expected_members[manifest["labels"][f"w{n:02d}"]] = manifest["groups"][name]
        check(state["membership"] == expected_members, "initial membership mismatch")
        check(len(manifest["shells"]) == 56, "expected 56 distinct terminal PID records")
        check(len({s["pid"] for s in manifest["shells"].values()}) == 56, "shell PIDs are not unique")
        manifest["initial"] = state
        manifest["stable_prefix"] = ordered[:ordered.index(manifest["labels"]["w25"])]
        manifest["expected"] = {"order": ordered, "membership": expected_members, "attention": state["attention"]}
        assert_model(state, manifest, manifest["expected"], state["selected"])
        write_json(out / "manifest.json", manifest)
        write_json(out / "expected.json", manifest["expected"])
        write_json(out / "selection.json", {"workspace_id": state["selected"], "monotonic": time.monotonic()})
    print(str(out / "manifest.json"))


def operation_category(number):
    return ("reorder", "transfer", "flag", "waiting_suppression")[number % 4]


def next_operation(manifest, expected, number):
    """Same semantic 150/150/150/150 workload on both builds; no probe movement."""
    check(0 <= number < 600, "operation outside frozen schedule")
    labels, result = manifest["labels"], copy.deepcopy(expected)
    category, turn = operation_category(number), number // 4
    params = {"window_id": manifest["initial"]["window_id"]}
    if category in ("flag", "waiting_suppression"):
        label = (("w10", "w46") if category == "flag" else ("w11", "w45"))[turn % 2]
        params.update(manifest["attention_tabs"][label], by="operator")
        state = result["attention"][label]
        if category == "flag":
            raised = state["flag"] is None
            method = "flag.raise" if raised else "flag.lower"
            state["flag"] = "W2 synthetic flag" if raised else None
            if raised: params["reason"] = state["flag"]
        else:
            state["suppressed"] = not state["suppressed"]
            method = "flag.suppress" if state["suppressed"] else "flag.unsuppress"
        return method, params, result
    ws = labels[(("w25", "w26") if category == "reorder" else ("w27", "w28"))[turn % 2]]
    params["workspace_id"] = ws
    order = expected["order"]
    remaining = [item for item in order if item != ws]
    if category == "transfer":
        target = None if expected["membership"][ws] is not None else manifest["groups"]["Move Lane"]
        params["to_group_id"] = target
        peers = [item for item in remaining if result["membership"][item] == target
                 and not manifest["initial"]["pins"][item]]
        insert = remaining.index(peers[-1]) + 1 if peers else len(remaining)
        result["membership"][ws] = target
        method = "workspace.group.move"
    else:
        target = labels["w60"]
        insert = remaining.index(target) + (0 if order.index(ws) > order.index(target) else 1)
        params["index"] = insert
        method = "workspace.reorder"
    remaining.insert(insert, ws)
    result["order"] = remaining
    prefix = manifest["stable_prefix"]
    check(remaining[:len(prefix)] == prefix, "planned mutation escaped tail")
    check(result != expected, "scheduled operation would be a no-op")
    return method, params, result


class ChurnWorker(threading.Thread):
    """Own connection, one in-flight request, no operation queue, bounded timeout."""
    def __init__(self, manifest, expected, start_at, log_path, count=600, duration=60):
        super().__init__(name="g60-churn", daemon=False)
        self.manifest = manifest
        self.expected = copy.deepcopy(expected)
        self.start_at = start_at
        self.stop_requested = threading.Event()
        self.records = []
        self.error = None
        self.log_path = Path(log_path)
        self.pending = False
        self.count, self.duration = count, duration

    def run(self):
        try:
            with RPC(self.manifest["tag"], self.manifest["socket"]) as rpc, self.log_path.open("x") as log:
                for n in range(self.count):
                    scheduled = self.start_at + n / 10
                    if self.stop_requested.wait(max(0, scheduled - time.monotonic())):
                        break
                    if time.monotonic() >= self.start_at + self.duration:
                        raise RuntimeError("churn exceeded the fixed 60-second phase")
                    method, params, predicted = next_operation(self.manifest, self.expected, n)
                    record = {"n": n, "scheduled": scheduled, "started": time.monotonic(),
                              "method": method, "category": operation_category(n), "params": params, "expected_after": predicted}
                    try:
                        from lease import SELECTION_LOCK
                        SELECTION_LOCK.acquire()
                        record["selected_before"] = rpc.call("workspace.current")["workspace_id"]
                        self.pending = True
                        record["response"] = rpc.call(method, **params)
                        record["selected_after"] = rpc.call("workspace.current")["workspace_id"]
                        check(record["selected_before"] == record["selected_after"], "non-focus mutation stole selection")
                        self.expected = predicted
                        record["outcome"] = "ok"
                    except Exception as error:
                        record.update(outcome="error", error=str(error))
                        raise
                    finally:
                        self.pending = False
                        SELECTION_LOCK.release()
                        record["completed"] = time.monotonic()
                        self.records.append(record)
                        log.write(json.dumps(record) + "\n")
                        log.flush()
        except Exception as error:
            self.error = str(error)

    def stop_and_join(self):
        self.stop_requested.set()
        self.join(timeout=4)
        check(not self.is_alive() and not self.pending, "worker failed to stop; no quiescence allowed")


def load_manifest(args):
    manifest = json.loads(Path(args.manifest).read_text())
    check(manifest["tag"] == args.tag and manifest["socket"] == args.socket, "manifest/tag/socket mismatch")
    check(manifest["mode"] == args.mode, "manifest mode mismatch")
    check(manifest["host"] == platform.node(), "manifest belongs to another host")
    return manifest


def selected(path, manifest):
    if path:
        return json.loads(Path(path).read_text())["workspace_id"]
    return manifest["initial"]["selected"]


def probe_commands(manifest, script_path, python="python3"):
    """Return normal shell commands; caller sends text then enter before calibration.

    No exec: keeping the original shell alive preserves its PID continuity oracle.
    This pure helper does not send, run or launch anything.
    """
    path = Path(script_path)
    check(path.is_absolute() and path.is_file(), "probe script must be an explicit local file")
    commands = []
    for label, marker in (("w01", "G60-PROBE-ONE"), ("w02", "G60-PROBE-TWO")):
        ws = manifest["labels"][label]
        tab = manifest["initial"]["tabs"][ws][0]["id"]
        commands.append({"workspace_id": ws, "tab_id": tab, "marker": marker,
                         "command": shlex.join([python, str(path), marker])})
    return {"script_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "commands": commands}


def churn(args):
    manifest = load_manifest(args)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    expected = json.loads(Path(args.expected).read_text())
    with RPC(args.tag, args.socket) as rpc:
        before = capture(rpc, manifest, out / "before.json")
        assert_model(before, manifest, expected, selected(args.selection_file, manifest))
    start_at = args.start_at if args.start_at is not None else time.monotonic() + 1
    check(start_at > time.monotonic(), "start_at must still be in the future after preflight")
    worker = ChurnWorker(manifest, expected, start_at, out / "operations.jsonl")
    worker.start()
    try:
        # Wait to the fixed phase boundary; no extension to reach 600 requests.
        worker.join(timeout=max(0, start_at + 60 - time.monotonic()))
        if not worker.is_alive():
            time.sleep(max(0, start_at + 60 - time.monotonic()))
    finally:
        worker.stop_and_join()
    write_json(out / "expected.json", worker.expected)
    records = worker.records
    summary = {"phase_start": start_at, "phase_end": start_at + 60,
               "scheduled_count": 600, "completed_count": len(records),
               "achieved_hz": len(records) / 60, "worker_alive": worker.is_alive(),
               "pending": worker.pending, "queued": 0, "worker_error": worker.error,
               "method_counts": {m: sum(r["method"] == m for r in records)
                                 for m in {r["method"] for r in records}},
               "late_start_count": sum(r["started"] >= r["scheduled"] + 0.1 for r in records),
               "phase_overrun": any(r["completed"] > start_at + 60 for r in records)}
    summary["schedule_complete"] = (len(records) == 600 and worker.error is None
                                    and not summary["phase_overrun"])
    summary["model_verified"] = False
    summary["complete"] = False
    write_json(out / "summary.json", summary)
    try:
        with RPC(args.tag, args.socket) as rpc:
            state = capture(rpc, manifest, out / "after-joined.json")
            assert_model(state, manifest, worker.expected, selected(args.selection_file, manifest))
        summary["model_verified"] = True
    except Exception as error:
        summary["model_error"] = str(error)
        raise
    finally:
        summary["complete"] = summary["schedule_complete"] and summary["model_verified"]
        write_json(out / "summary.json", summary)
    check(summary["complete"], "churn rate/count/timing incomplete; see summary.json")
    print(json.dumps(summary, sort_keys=True))


def verify(args):
    manifest = load_manifest(args)
    expected = json.loads(Path(args.expected).read_text())
    with RPC(args.tag, args.socket) as rpc:
        state = capture(rpc, manifest, args.snapshot)
        assert_model(state, manifest, expected, selected(args.selection_file, manifest))
    print("PASS: complete identities, tabs, shell PIDs, pins, order, membership and selection")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="explicit runtime authorization; use only after Atlas gate")
    parser.add_argument("--tag", required=True)
    parser.add_argument("--socket", required=True)
    parser.add_argument("--mode", choices=("control", "candidate"), required=True)
    sub = parser.add_subparsers(dest="action", required=True)
    create = sub.add_parser("provision")
    create.add_argument("--out", required=True)
    create.add_argument("--source-sha", required=True)
    create.add_argument("--mount-log", required=True)
    for name in ("churn", "verify"):
        action = sub.add_parser(name)
        action.add_argument("--manifest", required=True)
        action.add_argument("--expected", required=True)
        action.add_argument("--selection-file", help="sampler atomically records last explicit switch UUID here")
        if name == "churn":
            action.add_argument("--out", required=True)
            action.add_argument("--start-at", type=float, help="shared time.monotonic() phase boundary")
        else:
            action.add_argument("--snapshot", required=True)
    args = parser.parse_args()
    check(args.execute, "refusing runtime access without --execute")
    authorized_socket(args.tag, args.socket)
    globals()[args.action](args)


if __name__ == "__main__":
    main()

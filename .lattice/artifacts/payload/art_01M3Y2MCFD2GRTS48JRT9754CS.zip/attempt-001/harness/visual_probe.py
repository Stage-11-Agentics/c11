"""validation-host-only, PID-targeted visible-state latency probe. Never launches an app.

Templates must be calibrated and visually reviewed before a measured run. The
oracle is exact expected crop content, never merely a changed frame. All times
are monotonic nanoseconds; raw capture overhead remains in the reported latency.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import time


class Target:
    def __init__(self, config: dict, output: Path):
        from lease import require_runtime
        require_runtime("c11-260-control" if config["bundle_id"].endswith(".control") else "c11-260")
        import AppKit
        import Quartz
        self.A, self.Q = AppKit, Quartz
        self.config, self.output = config, Path(output)
        self.output.mkdir(parents=True, exist_ok=True)
        hostname = subprocess.check_output(["scutil", "--get", "ComputerName"], text=True).strip()
        if config.get("transport_host") != "validation-host" or hostname != config["host"]:
            raise RuntimeError(f"validation-host host mismatch: {hostname!r}")
        bundle = config["bundle_id"]
        if not bundle.startswith("com.stage11.c11.debug."):
            raise RuntimeError("Only an explicit tagged c11 bundle is allowed")
        apps = list(AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bundle))
        if len(apps) != 1 or apps[0].processIdentifier() != config["pid"]:
            raise RuntimeError("Tagged process identity mismatch")
        self.app = apps[0]
        self.pid = config["pid"]
        if str(self.app.bundleURL().path()) != config["app_path"]:
            raise RuntimeError("Tagged app path mismatch")
        self.verify()

    def verify(self):
        Q, c = self.Q, self.config
        from lease import require_runtime
        lease = require_runtime("c11-260-control" if c["bundle_id"].endswith(".control") else "c11-260")
        if lease["bound_pid"] != self.pid: raise RuntimeError("UI lease PID mismatch")
        if not 0 <= time.time() - c["run_started_unix"] < 1200:
            raise RuntimeError("20-minute UI run limit exceeded")
        windows = [w for w in Q.CGWindowListCopyWindowInfo(Q.kCGWindowListOptionOnScreenOnly, 0)
                   if w.get("kCGWindowNumber") == c["window_id"] and w.get("kCGWindowOwnerPID") == self.pid]
        if len(windows) != 1:
            raise RuntimeError("Verified tagged window is no longer visible")
        bounds = dict(windows[0]["kCGWindowBounds"])
        if bounds != c["window_bounds"]:
            raise RuntimeError("Window moved or resized during measurement")
        d = Q.CGDisplayBounds(c["display_id"])
        if not (bounds["X"] >= d.origin.x and bounds["Y"] >= d.origin.y
                and bounds["X"] + bounds["Width"] <= d.origin.x + d.size.width
                and bounds["Y"] + bounds["Height"] <= d.origin.y + d.size.height):
            raise RuntimeError("Window escaped the verified display")
        if self.A.NSWorkspace.sharedWorkspace().frontmostApplication().processIdentifier() != self.pid:
            raise RuntimeError("Tagged app lost macOS focus; refusing input")

    def post(self, action: dict) -> int:
        self.verify()
        Q = self.Q
        kind = action["kind"]
        events = []
        if kind == "key":
            for down in (True, False):
                event = Q.CGEventCreateKeyboardEvent(None, action.get("keycode", 0), down)
                if "text" in action:
                    text = action["text"]
                    Q.CGEventKeyboardSetUnicodeString(event, len(text), text)
                Q.CGEventSetFlags(event, Q.kCGEventFlagMaskCommand if action.get("command") else 0)
                events.append(event)
        elif kind in ("scroll", "click"):
            bounds = self.config["window_bounds"]
            x, y = action["point"]
            if not 0 <= x < bounds["Width"] or not 0 <= y < bounds["Height"]:
                raise ValueError("Input point is outside the tagged window")
            point = (bounds["X"] + x, bounds["Y"] + y)
            if kind == "scroll":
                event = Q.CGEventCreateScrollWheelEvent(None, Q.kCGScrollEventUnitPixel, 1, action["pixels"])
                Q.CGEventSetLocation(event, point)
                events.append(event)
                # Scroll hit testing follows the real cursor; move only inside the verified tagged window.
                move = Q.CGEventCreateMouseEvent(None, Q.kCGEventMouseMoved, point, Q.kCGMouseButtonLeft)
                Q.CGEventPost(Q.kCGHIDEventTap, move)
            else:
                for typ in (Q.kCGEventLeftMouseDown, Q.kCGEventLeftMouseUp):
                    events.append(Q.CGEventCreateMouseEvent(None, typ, point, Q.kCGMouseButtonLeft))
        else:
            raise ValueError(f"Unsupported input kind: {kind}")
        started = time.perf_counter_ns()
        for event in events:
            Q.CGEventPost(Q.kCGHIDEventTap, event) if kind == "scroll" else Q.CGEventPostToPid(self.pid, event)
        return started

    def capture(self, roi: list[int]):
        Q = self.Q
        x, y, width, height = roi
        b = self.config["window_bounds"]
        if min(x, y) < 0 or width <= 0 or height <= 0 or x + width > b["Width"] or y + height > b["Height"]:
            raise ValueError("Capture crop is outside tagged window")
        started = time.perf_counter_ns()
        image = Q.CGWindowListCreateImage(
            Q.CGRectMake(b["X"] + x, b["Y"] + y, width, height),
            Q.kCGWindowListOptionIncludingWindow, self.config["window_id"],
            Q.kCGWindowImageBoundsIgnoreFraming | Q.kCGWindowImageNominalResolution)
        if image is None:
            raise RuntimeError("Screen capture unavailable")
        if Q.CGImageGetBitsPerPixel(image) != 32 or Q.CGImageGetWidth(image) != width or Q.CGImageGetHeight(image) != height:
            raise RuntimeError("Capture pixel format/scale changed")
        raw = bytes(Q.CGDataProviderCopyData(Q.CGImageGetDataProvider(image)))
        stride = Q.CGImageGetBytesPerRow(image)
        pixels = b"".join(raw[row * stride:row * stride + width * 4] for row in range(height))
        ended = time.perf_counter_ns()
        return image, pixels, {"capture_begin_ns": started, "capture_end_ns": ended,
                               "capture_ms": (ended - started) / 1e6,
                               "sha256": hashlib.sha256(pixels).hexdigest()}

    def save_png(self, image, path: Path):
        import Foundation
        ImageIO = self.Q
        url = Foundation.NSURL.fileURLWithPath_(str(path))
        dest = ImageIO.CGImageDestinationCreateWithURL(url, "public.png", 1, None)
        ImageIO.CGImageDestinationAddImage(dest, image, None)
        if not ImageIO.CGImageDestinationFinalize(dest):
            raise RuntimeError(f"Could not save evidence: {path}")

    def template(self, label: str, roi: list[int], semantic_expectation: str) -> dict:
        """Capture settled state; caller must verify its semantics independently."""
        self.verify()
        image, pixels, timing = self.capture(roi)
        stem = self.output / label
        stem.with_suffix(".bin").write_bytes(pixels)
        self.save_png(image, stem.with_suffix(".png"))
        result = {"label": label, "roi": roi, "semantic_expectation": semantic_expectation,
                  "pixels": str(stem.with_suffix(".bin")), "screenshot": str(stem.with_suffix(".png")),
                  **timing}
        stem.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
        return result

    def measure(self, ident: str, metric: str, action: dict, before: dict, expected: dict,
                timeout_s: float = 1.0) -> dict:
        if before["roi"] != expected["roi"] or before["sha256"] == expected["sha256"]:
            raise ValueError("Distinct before/expected templates with identical geometry are required")
        before_pixels, expected_pixels = Path(before["pixels"]).read_bytes(), Path(expected["pixels"]).read_bytes()
        self.verify()
        pre_image, pixels, pre_timing = self.capture(before["roi"])
        result = {"id": ident, "metric": metric, "action": action, "expected": expected["label"],
                  "before": before["label"], "roi": before["roi"], "pre_capture": pre_timing,
                  "frames": [], "ok": False}
        if pixels != before_pixels:
            result["error"] = "precondition_template_mismatch"
            self.save_png(pre_image, self.output / f"{ident}-bad-precondition.png")
            return result
        # Persist evidence after timing, so disk writes cannot affect input latency.
        started = self.post(action)
        result["input_post_ns"] = started
        matched_image = None
        while time.perf_counter_ns() - started < timeout_s * 1e9:
            image, pixels, timing = self.capture(expected["roi"])
            result["frames"].append(timing)
            if pixels == expected_pixels and timing["capture_end_ns"] - started <= timeout_s * 1e9:
                result["ok"] = True
                result["latency_ms"] = (timing["capture_end_ns"] - started) / 1e6
                matched_image = image
                break
        if matched_image is None:
            result["error"] = "expected_state_timeout"
            result["timeout_s"] = timeout_s
            matched_image = image
        self.save_png(pre_image, self.output / f"{ident}-before.png")
        self.save_png(matched_image, self.output / f"{ident}-after.png")
        return result


def percentile(values, percent):
    import math
    return sorted(values)[max(0, math.ceil(len(values) * percent / 100) - 1)]


def summarize(records):
    result = {}
    for metric in ("typing", "scroll", "switch"):
        rows = [r for r in records if r["metric"] == metric]
        valid = [r["latency_ms"] for r in rows if r["ok"]]
        result[metric] = {"valid": len(valid), "errors": len(rows) - len(valid),
                          "p95_ms": percentile(valid, 95) if valid else None,
                          "p99_ms": percentile(valid, 99) if valid else None,
                          "max_ms": max(valid) if valid else None}
    return result

# g60-v1

Synthetic workspace performance fixture.

"""Offline authorized cross-window accounting. Never starts apps or samples."""
import argparse
import hashlib
import json
from pathlib import Path
from compare import stats
from schedule import pairs
from abba_compare import audit_run

OLD_ROWS_SHA = 'b010b350a313ecf1a750dc78bc8e98cdc812430f91d8d06aabd4f9e890723480'
OLD_SEAL_SHA = '8a7318d2d1d7b639999ee8281b44eefbfa356e13741222205ff8a918720c92a6'


def measurements(rows, phase, metric):
    result = {}
    for role in ('control', 'candidate'):
        own = [r for r in rows if (r['phase'], r['metric'], r['role']) == (phase, metric, role)]
        valid = [r for r in own if r.get('ok')]
        result[role] = {'attempted': len(own), 'valid': len(valid), 'invalid': len(own)-len(valid),
                        'latency': stats([r['latency_ms'] for r in valid])}
    return result


def budgets(roles, phase, metric, cohort):
    result = []
    for q, factor, additive in ((95, 1.20, 5), (99, 1.25, 15)):
        a, b = (roles[role]['latency'][f'p{q}_ms'] for role in ('control', 'candidate'))
        limit = max(a*factor, a+additive) if a is not None else None
        result.append({'phase': phase, 'metric': metric, 'cohort': cohort, 'percentile': q,
                       'control_ms': a, 'candidate_ms': b, 'limit_ms': limit,
                       'pass': b <= limit if b is not None and limit is not None else None})
    return result


def assemble(old, new, topup):
    """Pure data assembly: no averaging quantiles or pairing across windows."""
    limits, phases, issues = [], {}, []
    for phase, metrics in (('no-churn', ('typing', 'switch', 'scroll')),
                           ('churn', ('typing', 'switch'))):
        phases[phase] = phases.get(phase, {})
        for metric in metrics:
            roles = measurements(old, phase, metric)
            minimum = 100 if metric == 'typing' else 40
            for role, counts in roles.items():
                if counts['valid'] < minimum: issues.append(f'carried {phase}/{metric}/{role} below minimum')
            phases[phase][metric] = {'cohort': 'window2-unchanged', 'roles': roles}
            limits.extend(budgets(roles, phase, metric, 'window2-unchanged'))
    scroll = [dict(r, cohort='window2') for r in old if r['phase'] == 'churn' and r['metric'] == 'scroll']
    scroll += [dict(r, cohort='final-topup') for r in new if r['phase'] == 'churn' and r['metric'] == 'scroll']
    roles = measurements(scroll, 'churn', 'scroll')
    for role, counts in roles.items():
        if counts['attempted'] != 60 or counts['valid'] < 40:
            issues.append(f'combined churn/scroll/{role}: {counts["valid"]}/{counts["attempted"]}, need >=40/60')
    phases['churn']['scroll'] = {'cohort': 'authorized-window2-plus-final-topup', 'roles': roles,
                                'window2': measurements(old, 'churn', 'scroll'),
                                'final_topup': measurements(new, 'churn', 'scroll'),
                                'invalids': [r for r in scroll if not r.get('ok')]}
    limits.extend(budgets(roles, 'churn', 'scroll', 'authorized-pooled-raw'))
    phases['quiescence'] = {}
    for metric in ('typing', 'switch', 'scroll'):
        roles = measurements(new, 'quiescence', metric)
        phases['quiescence'][metric] = {'cohort': 'final-topup-only', 'roles': roles}
        limits.extend(budgets(roles, 'quiescence', metric, 'final-topup-only'))
    supplemental = budgets(measurements(old, 'churn', 'scroll'), 'churn', 'scroll', 'window2-only')
    supplemental += budgets(measurements(new, 'churn', 'scroll'), 'churn', 'scroll', 'topup-only')
    failed = [b for b in limits + supplemental if b['pass'] is False]
    issues.extend(topup.get('incomplete_reasons', []))
    if any(b['pass'] is None for b in limits): issues.append('unmeasured final budget')
    old_pairs = pairs(old)
    new_pairs = pairs(new)
    return {'schema': 'c11-261-authorized-perf-delta-v1',
            'status': 'FAIL' if failed else 'INCOMPLETE' if issues else 'PASS',
            'complete_by_authorized_delta': not issues, 'original_window2_status': 'INCOMPLETE',
            'budgets': limits, 'supplemental_scroll_budgets': supplemental,
            'observed_budget_failures': failed, 'incomplete_reasons': issues, 'phases': phases,
            'per_pair_deltas': {'window2': old_pairs, 'final_topup': new_pairs},
            'topup_full_audit': topup,
            'limitations': ['Window2 churn typing/switch and old scroll retain 2165/2400 dose and global-lock harness.',
                            'New scroll/quiescence follow corrected 2400/2400 churn only if audited complete.',
                            'No corrected-10Hz typing/switch claim; no reclassification of historical dose failure.',
                            'Variation is not pure isolated noise; no overhead subtraction or confidence claim.',
                            'Not full ticket acceptance, independent review, human signoff or a soak.']}


def audit_delta(pair, identity, baseline):
    baseline = Path(baseline)
    raw = (baseline / 'attempt-001/paired-samples.jsonl').read_bytes()
    seal_bytes = (baseline / 'identity-017.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != OLD_ROWS_SHA or hashlib.sha256(seal_bytes).hexdigest() != OLD_SEAL_SHA:
        raise RuntimeError('Pinned immutable window2 evidence differs')
    old_identity, new_identity = json.loads(seal_bytes), json.loads(Path(identity).read_text())
    for role in ('control', 'candidate'):
        for key in ('source_sha', 'artifact_sha256', 'calibration_spec_sha256'):
            if old_identity[role][key] != new_identity[role][key]:
                raise RuntimeError('Frozen old/new pair differs: ' + role + '/' + key)
    old = [json.loads(line) for line in raw.splitlines()]
    if len(old) != 800: raise RuntimeError('Window2 raw accounting differs')
    new = [json.loads(line) for line in (Path(pair)/'paired-samples.jsonl').read_text().splitlines()]
    report = assemble(old, new, audit_run(pair, identity))
    report['baseline_rows_sha256'] = OLD_ROWS_SHA
    report['baseline_seal_sha256'] = OLD_SEAL_SHA
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('pair', 'identity', 'baseline', 'out'): parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    try: result = audit_delta(args.pair, args.identity, args.baseline)
    except Exception as error:
        result = {'status': 'INCOMPLETE', 'complete_by_authorized_delta': False,
                  'incomplete_reasons': [{'location': 'delta-parser', 'reason': str(error)}]}
    Path(args.out).write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k in ('status', 'complete_by_authorized_delta', 'budgets', 'incomplete_reasons')}, indent=2))
    raise SystemExit({'PASS': 0, 'FAIL': 1, 'INCOMPLETE': 2}[result['status']])

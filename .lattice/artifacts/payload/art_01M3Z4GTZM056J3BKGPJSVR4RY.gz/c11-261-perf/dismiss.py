"""Synthesize bounded dismissal of the exact leased tagged app, after measurement."""
import argparse
import json
import time
from pathlib import Path
from lease import atomic, read
from g60 import RPC
from visual_probe import Target

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--config', required=True)
p.add_argument('--manifest', required=True)
p.add_argument('--out', required=True)
a = p.parse_args()
c, manifest = read(a.config), read(a.manifest)
target = Target(c, Path(a.out).parent)
actions = []
# Stop only our two probe children; original parent shells remain for normal quit.
with RPC(manifest['tag'], manifest['socket']) as rpc:
    for label in manifest['probe_labels']:
        wid = manifest['labels'][label]
        tid = manifest['initial']['tabs'][wid][0]['id']
        response = rpc.call('tab.send_key', workspace_id=wid, tab_id=tid, key='ctrl+c')
        actions.append({'kind': 'probe-interrupt', 'workspace_id': wid, 'tab_id': tid, 'response': response})
time.sleep(.5)
target.post({'kind': 'key', 'keycode': 12, 'command': True})
actions.append({'kind': 'Command-Q', 'pid': c['pid'], 'unix': time.time()})
time.sleep(.5)
# The shipped warning defaults to Cancel. Answer only the observed owned quit
# sheet, not arbitrary dialogs or a global Return key.
import ApplicationServices as AX
def attr(node, key):
    error, value = AX.AXUIElementCopyAttributeValue(node, key, None)
    return value if error == 0 else None
def walk(node, seen, depth=0):
    if depth > 18 or len(seen) > 2000 or any(node == old for old in seen):
        return []
    seen.append(node)
    error, pid = AX.AXUIElementGetPid(node, None)
    if error or pid != c['pid']:
        raise RuntimeError('Quit AX traversal left assigned PID')
    nodes = [node]
    for child in list(attr(node, 'AXChildren') or []):
        nodes.extend(walk(child, seen, depth+1))
    return nodes
root = AX.AXUIElementCreateApplication(c['pid'])
AX.AXUIElementSetMessagingTimeout(root, .5)
for window in list(attr(root, 'AXWindows') or []):
    for sheet in list(attr(window, 'AXSheets') or []):
        nodes = walk(sheet, [])
        labels = [str(attr(n, 'AXValue') or attr(n, 'AXTitle') or '') for n in nodes]
        if 'Quit c11?' not in labels or 'This will close all windows and workspaces.' not in labels:
            continue
        target.verify()
        buttons = [n for n in nodes if attr(n, 'AXRole') == 'AXButton' and attr(n, 'AXTitle') == 'Quit']
        if len(buttons) != 1:
            raise RuntimeError('Quit button is ambiguous')
        image, _, timing = target.capture([0, 0, int(c['window_bounds']['Width']), int(c['window_bounds']['Height'])])
        target.save_png(image, Path(a.out).parent / 'quit-sheet.png')
        error = AX.AXUIElementPerformAction(buttons[0], 'AXPress')
        actions.append({'kind': 'AXPress Quit', 'pid': c['pid'], 'labels': labels,
                        'returncode': error, 'capture': timing})
        if error:
            raise RuntimeError('Quit action failed')
deadline = time.monotonic() + 10
while time.monotonic() < deadline:
    apps = list(target.A.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']))
    if not any(app.processIdentifier() == c['pid'] for app in apps):
        atomic(a.out, {'pid': c['pid'], 'gone': True, 'synthesized': actions, 'unix': time.time()})
        print('DISMISSED', flush=True)
        break
    time.sleep(.1)
else:
    image, _, timing = target.capture([0, 0, int(c['window_bounds']['Width']), int(c['window_bounds']['Height'])])
    target.save_png(image, Path(a.out).parent / 'dismiss-pending.png')
    atomic(a.out, {'pid': c['pid'], 'gone': False, 'synthesized': actions, 'pending_capture': timing})
    raise RuntimeError('Synthesized quit remains pending; inspect its actual dialog, never count a forced exit')

import os
from pathlib import Path
import signal
import subprocess

def stop(*_):
    with open('/tmp/md359-final-hardstop.log', 'w') as log:
        subprocess.run([str(Path.home()/'c11-builds/md-359/source/scripts/sandbox-down.sh'), 'md359-final'],
                       env=dict(os.environ,C11_SANDBOX_HOST='local'),stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raise SystemExit

Path('/tmp/md359-final-hardstop.pid').write_text(str(os.getpid()))
signal.signal(signal.SIGALRM,stop)
signal.alarm(1500)
signal.pause()

#!/usr/bin/env python3
"""One post-primary functional pointer burst; never launches, quits or retries.

Requires the same C11_PERF_PAIR / C11_PERF_IDENTITY and active role leases as
run_phases.py. No import or --help path performs runtime work.
"""
import argparse
import copy
import math
from pathlib import Path
import re
import signal
import time

from g60 import RPC, assert_model, capture, check, write_json
from lease import pair_root, read, verify_seal
from visual_probe import Target


class Pointer:
    def __init__(self, config, out, deadline):
        import ApplicationServices as AX
        self.t, self.AX, self.out, self.deadline = Target(config, out), AX, out, deadline
        self.app = AX.AXUIElementCreateApplication(self.t.pid)
        AX.AXUIElementSetMessagingTimeout(self.app, 1.0)
        self.nodes = []

    def guard(self):
        check(time.monotonic() < self.deadline, '90-second pointer burst expired')
        self.t.verify()  # Perf quiet/build/UI leases, exact PID/window/display/frontmost.
        d = self.t.Q.CGDisplayBounds(self.t.config['display_id'])
        check(self.t.config['display_bounds'] == dict(x=d.origin.x, y=d.origin.y,
              width=d.size.width, height=d.size.height), 'Display geometry changed')

    def attr(self, element, key):
        error, value = self.AX.AXUIElementCopyAttributeValue(element, key, None)
        return value if error == 0 else None

    def geometry(self, element, key, kind):
        value = self.attr(element, key)
        if value is None:
            return None
        ok, value = self.AX.AXValueGetValue(value, kind, None)
        if not ok:
            return None
        return [float(value.x), float(value.y)] if key == 'AXPosition' else [float(value.width), float(value.height)]

    def tree(self, label):
        self.guard()
        seen, nodes = [], []

        def walk(element, ancestors, depth):
            self.guard()
            check(depth <= 35 and len(nodes) < 4000, 'AX tree limit exceeded')
            if any(element == old for old in seen):
                return
            seen.append(element)
            error, pid = self.AX.AXUIElementGetPid(element, None)
            check(error == 0 and pid == self.t.pid, 'AX traversal left exact PID')
            node = {key: self.attr(element, 'AX' + key) for key in ('Role', 'Title', 'Description', 'Identifier')}
            node.update(position=self.geometry(element, 'AXPosition', self.AX.kAXValueCGPointType),
                        size=self.geometry(element, 'AXSize', self.AX.kAXValueCGSizeType), ancestors=ancestors)
            nodes.append(node)
            children = list(self.attr(element, 'AXChildren') or [])
            if depth == 0:
                children += list(self.attr(element, 'AXWindows') or [])
            lineage = ancestors + ([node['Identifier']] if node['Identifier'] else [])
            for child in children:
                walk(child, lineage, depth + 1)
        walk(self.app, [], 0)
        self.nodes = nodes
        write_json(self.out / (label + '-ax.json'), nodes)
        return nodes

    def node(self, identifier=None, workspace_label=None):
        if identifier is not None:
            matches = [n for n in self.nodes if n['Identifier'] == identifier
                       and (identifier != 'Sidebar' or n['Role'] == 'AXScrollArea')]
        else:
            # Product rows have no UUID AXIdentifier. This is the actual combined
            # accessibilityTitle contract, joined to the manifest's UUID map.
            pattern = re.compile(r'^g60-' + re.escape(workspace_label) + r', workspace [0-9]+ of 60$')
            matches = [n for n in self.nodes if 'Sidebar' in n['ancestors']
                       and any(pattern.fullmatch(n[k] or '') for k in ('Title', 'Description'))]
        check(len(matches) == 1, f'Missing/ambiguous AX target: {identifier or workspace_label}')
        n = matches[0]
        check(n['position'] is not None and n['size'] is not None, 'AX target has no geometry')
        x, y = n['position']; w, h = n['size']
        b = self.t.config['window_bounds']
        check(all(math.isfinite(v) for v in (x, y, w, h)) and w > 0 and h > 0
              and b['X'] <= x and b['Y'] <= y and x + w <= b['X'] + b['Width']
              and y + h <= b['Y'] + b['Height'], 'AX target is not fully inside verified window')
        if identifier != 'Sidebar':
            viewport = self.node(identifier='Sidebar')
            vx, vy = viewport['position']; vw, vh = viewport['size']
            check(vx <= x and vy <= y and x+w <= vx+vw and y+h <= vy+vh,
                  'AX target is clipped or outside the visible sidebar viewport')
        return n

    @staticmethod
    def point(node, y_fraction=.5):
        x, y = node['position']; w, h = node['size']
        return x + w * .5, y + h * y_fraction

    def hit(self, point):
        self.guard()
        b = self.t.config['window_bounds']
        check(b['X'] <= point[0] < b['X'] + b['Width'] and b['Y'] <= point[1] < b['Y'] + b['Height'],
              'Pointer escaped exact window')
        error, hit = self.AX.AXUIElementCopyElementAtPosition(self.AX.AXUIElementCreateSystemWide(), *point, None)
        check(error == 0 and hit is not None, f'AX pointer hit unavailable: {error}')
        error, pid = self.AX.AXUIElementGetPid(hit, None)
        check(error == 0 and pid == self.t.pid, f'AX pointer hit is not exact target PID: {pid}')

    def mouse(self, kind, point):
        self.hit(point)
        self.guard()
        Q = self.t.Q
        Q.CGEventPost(Q.kCGHIDEventTap, Q.CGEventCreateMouseEvent(None, kind, point, Q.kCGMouseButtonLeft))

    def top(self):
        sidebar = self.node(identifier='Sidebar')
        point = self.point(sidebar)
        Q = self.t.Q
        self.mouse(Q.kCGEventMouseMoved, point)
        self.hit(point)
        event = Q.CGEventCreateScrollWheelEvent(None, Q.kCGScrollEventUnitPixel, 1, 10000)
        Q.CGEventSetLocation(event, point)
        self.guard()
        Q.CGEventPost(Q.kCGHIDEventTap, event)
        time.sleep(.2)

    def screenshot(self, label):
        self.guard()
        node = self.node(identifier='Sidebar')
        x, y = node['position']; w, h = node['size']; b = self.t.config['window_bounds']
        left, top = math.floor(x-b['X']), math.floor(y-b['Y'])
        roi = [left, top, math.ceil(x+w-b['X'])-left, math.ceil(y+h-b['Y'])-top]
        image, _, timing = self.t.capture(roi)
        self.t.save_png(image, self.out / (label + '-sidebar.png'))
        return dict(roi=roi, **timing)

    def drag(self, label, source, destination, fraction=.5):
        Q = self.t.Q
        start, end = self.point(source), self.point(destination, fraction)
        record = dict(label=label, source_ax=source, destination_ax=destination,
                      start=start, end=end, started_ns=time.perf_counter_ns(), steps=24, requested_duration_s=.6)
        last, down = start, False
        try:
            self.mouse(Q.kCGEventMouseMoved, start)
            self.mouse(Q.kCGEventLeftMouseDown, start); down = True
            for i in range(1, 25):
                time.sleep(.025)
                last = tuple(a + (b-a)*i/24 for a, b in zip(start, end))
                self.mouse(Q.kCGEventLeftMouseDragged, last)
            self.mouse(Q.kCGEventLeftMouseUp, end); down = False
        finally:
            if down and not self.t.app.isTerminated():
                # Fail-closed cleanup: no unverified global mouse-up.
                Q.CGEventPostToPid(self.t.pid, Q.CGEventCreateMouseEvent(None, Q.kCGEventLeftMouseUp, last, Q.kCGMouseButtonLeft))
            record['ended_ns'] = time.perf_counter_ns()
            write_json(self.out / (label + '-pointer.json'), record)
        time.sleep(.25)  # One fixed settlement period, never retry a failed drag.
        return record


def run(args):
    check(args.execute, 'Explicit --execute required')
    config, manifest, primary = read(args.config), read(args.manifest), read(Path(args.phases) / 'run.json')
    role = manifest['mode']
    check(role in ('control', 'candidate'), 'Unassigned role')
    identity = verify_seal(role)
    check(primary['complete'] is True and primary['config'] == config, 'Primary run incomplete or config mismatch')
    check([p['name'] for p in primary['phases']] == ['no-churn', 'churn', 'quiescence']
          and all(p['complete'] for p in primary['phases']), 'All three completed primary phases required')
    check(config['artifact_sha256'] == identity['artifact_sha256'] and manifest['source_sha'] == identity['source_sha'],
          'Source/artifact seal mismatch')
    check(config['bundle_id'] == 'com.stage11.c11.debug.' + manifest['tag'].replace('-', '.'), 'Role/PID config mismatch')
    # Permanent per-role claim blocks rerunning against the same attempt, even
    # with a different evidence directory. Preserve failed evidence; no retries.
    (pair_root() / role / 'pointer-burst-claim').mkdir(exist_ok=False)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    result = dict(complete=False, role=role, started=started, deadline=started+90, actions=[],
                  manifest=str(Path(args.manifest).resolve()), phases=str(Path(args.phases).resolve()),
                  ax_fixture_bindings={name: manifest['labels'][name] for name in ('w29', 'w30')},
                  latency_percentiles=None)
    def expired(*_):
        raise TimeoutError('90-second pointer burst limit')
    old = signal.signal(signal.SIGALRM, expired); signal.setitimer(signal.ITIMER_REAL, 90)
    try:
        ui = Pointer(config, out, started+90)
        oracle = copy.deepcopy(manifest)
        expected = read(Path(args.phases) / 'quiescence' / 'expected.json')
        final_primary = read(Path(args.phases) / 'quiescence' / 'after.json')['state']
        with RPC(manifest['tag'], manifest['socket']) as rpc:
            def snapshot(label, preserve_selection=True):
                ui.guard()
                state = capture(rpc, manifest, out / (label + '-snapshot.json'))
                ui.tree(label)
                timing = ui.screenshot(label)
                assert_model(state, oracle, expected, final_primary['selected'] if preserve_selection else state['selected'])
                check(state['selected'] in manifest['initial']['order'], 'Selection left fixture')
                result['actions'].append(dict(label=label, selected=state['selected'], capture=timing,
                                              monotonic=time.monotonic()))
                write_json(out / 'summary.json', result)
                return state

            snapshot('00-before')
            raw = read(out / '00-before-snapshot.json')['raw_tree']['windows'][0]['workspaces']
            for name in ('w29', 'w30'):
                matches = [w for w in raw if w['id'] == manifest['labels'][name] and w['title'] == 'g60-' + name]
                check(len(matches) == 1, 'AX fixture label does not bind to expected workspace UUID: ' + name)
            w29, w30 = (manifest['labels'][name] for name in ('w29', 'w30'))
            check(expected['membership'][w29] is None and expected['membership'][w30] is None
                  and manifest['initial']['pins'][w29] and manifest['initial']['pins'][w30], 'Pinned ungrouped fixture absent')
            for group in oracle['initial']['groups']:
                ui.guard()
                rpc.call('workspace.group.collapse', window_id=manifest['initial']['window_id'], group_id=group['id'])
                group['is_collapsed'] = True
                check(rpc.call('workspace.current')['workspace_id'] == final_primary['selected'], 'Collapse stole selection')
            ui.tree('01-collapsed-before-scroll'); ui.top()
            snapshot('02-collapsed-top')
            original_order = list(expected['order'])
            # Primary stable prefix is intentionally rearranged only after all
            # primary samples finish. Every UUID/tab/pin/shell check stays active.
            oracle['stable_prefix'] = []
            for label, edge in (('03-reorder-after', .8), ('04-reorder-back', .2)):
                source, dest = ui.node(workspace_label='w29'), ui.node(workspace_label='w30')
                order = [w for w in expected['order'] if w != w29]
                order.insert(order.index(w30) + (1 if edge > .5 else 0), w29)
                check(order != expected['order'], 'Requested reorder is a no-op')
                ui.drag(label, source, dest, edge)
                expected['order'] = order
                snapshot(label, preserve_selection=role == 'candidate')
            check(expected['order'] == original_order, 'Reorder roundtrip did not restore canonical order')
            if role == 'candidate':
                empty = manifest['groups']['Empty Pinned']
                check(not any(g == empty for g in expected['membership'].values()), 'Empty Pinned is not empty')
                ui.drag('05-into-empty', ui.node(workspace_label='w29'),
                        ui.node(identifier='workspace-group-header-' + empty.upper()))
                expected['membership'][w29] = empty
                order = [w for w in expected['order'] if w != w29]
                order.insert(sum(manifest['initial']['pins'][w] for w in order), w29)
                expected['order'] = order
                snapshot('05-into-empty')
                # The intentionally collapsed target hides the member. Explicit
                # non-focus expansion is setup for the real outgoing pointer drag.
                rpc.call('workspace.group.expand', window_id=manifest['initial']['window_id'], group_id=empty)
                next(g for g in oracle['initial']['groups'] if g['id'] == empty)['is_collapsed'] = False
                time.sleep(.2)
                snapshot('06-expanded-for-return')
                ui.drag('07-to-ungrouped', ui.node(workspace_label='w29'), ui.node(identifier='WorkspaceGroupNew'))
                expected['membership'][w29] = None
                # Root drop lane appends at the matching pin boundary. w29 is
                # already there after transfer into the empty pinned group.
                snapshot('07-to-ungrouped')
            result['complete'] = True
    except BaseException as error:
        result['error'] = str(error)
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)
        result['ended'] = time.monotonic()
        write_json(out / 'summary.json', result)
    print(str(out / 'summary.json'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    for key in ('config', 'manifest', 'phases', 'out'):
        parser.add_argument('--' + key, required=True)
    run(parser.parse_args())

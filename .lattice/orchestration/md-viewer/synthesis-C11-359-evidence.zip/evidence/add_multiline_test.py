import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "c11Tests/MarkdownWebRendererTests.swift"
s = p.read_text()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old, s.count(old))
    s = s.replace(old, new)
rep("""    func testNarrowReadModeEvictionRestoresReadingState() async throws {
        try await evictionRestoresReadingState(sourceMode: false)
    }
""", """    func testNarrowReadModeEvictionRestoresReadingState() async throws {
        try await evictionRestoresReadingState(sourceMode: false)
    }

    // SYNTH PROBE: the captured line lies inside a multi-line paragraph.
    func testSynthMultilineReadModeEvictionRestoresInteriorLine() async throws {
        try await evictionRestoresReadingState(sourceMode: false, multiline: true)
    }
""")
rep("private func evictionRestoresReadingState(sourceMode: Bool) async throws {",
    "private func evictionRestoresReadingState(sourceMode: Bool, multiline: Bool = false) async throws {")
rep("""        let text = "# Reader\\n\\n```mermaid\\ngraph TD\\nA-->B\\n```\\n\\n" + (1...80).map { "## Section \\($0)\\n\\nParagraph \\($0).\\n\\n" }.joined()
        try text.write(to: path, atomically: true, encoding: .utf8)
        let panel""", """        let text = "# Reader\\n\\n```mermaid\\ngraph TD\\nA-->B\\n```\\n\\n" + (1...80).map {
            multiline ? "## Section \\($0)\\n\\nLine a of \\($0)\\nLine b of \\($0)\\nLine c of \\($0)\\nLine d of \\($0)\\n\\n"
                      : "## Section \\($0)\\n\\nParagraph \\($0).\\n\\n"
        }.joined()
        try text.write(to: path, atomically: true, encoding: .utf8)
        // Section 20 starts at 8 + 7 * 19 = 141; "Line c of 20" is source line 145.
        let targetLine = multiline ? 145 : 160
        let findQuery = multiline ? "Line c of 40" : "Paragraph 40"
        let topOfTarget = "(()=>{const sc=document.getElementById('scroller');const w=document.createTreeWalker(document.getElementById('article'),NodeFilter.SHOW_TEXT);let n;while((n=w.nextNode())){const i=n.data.indexOf('Line c of 20');if(i>=0){const r=document.createRange();r.setStart(n,i);r.setEnd(n,i+1);return r.getBoundingClientRect().top-sc.getBoundingClientRect().top;}}return null;})()"
        let panel""")
rep("""        _ = try await call(first!, "find", arguments: ["Paragraph 40"])
        _ = try await call(first!, "scrollToLine", arguments: [160, 7.25])""",
    """        _ = try await call(first!, "find", arguments: [findQuery])
        _ = try await call(first!, "scrollToLine", arguments: [targetLine, 7.25])""")
rep("""        XCTAssertEqual(position.findQuery, "Paragraph 40")""",
    """        XCTAssertEqual(position.findQuery, findQuery)
        if multiline {
            XCTAssertEqual(position.line, 145, "SYNTH: visible() must report the interior source line")
            let y = try await evaluate(first!, topOfTarget) as? Double
            XCTAssertEqual(try XCTUnwrap(y), -7.25, accuracy: 1, "SYNTH: scrollToLine must align the interior line's text, not an interpolated block origin")
        }""")
rep("""        XCTAssertEqual(restored.findQuery, position.findQuery)
""", """        XCTAssertEqual(restored.findQuery, position.findQuery)
        if multiline {
            let y = try await evaluate(recreated, topOfTarget) as? Double
            XCTAssertEqual(try XCTUnwrap(y), -7.25, accuracy: 1, "SYNTH: restored reader shows the same text row")
        }
""")
p.write_text(s)
print("ok", p)

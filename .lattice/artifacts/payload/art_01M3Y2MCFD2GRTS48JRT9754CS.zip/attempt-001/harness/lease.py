"""Shared fail-closed admission. No runtime work occurs on import."""
import json
import os
from pathlib import Path
import platform
import tempfile
import threading
import time

SELECTION_LOCK = threading.RLock()
TAGS = {"control": "c11-260-control", "candidate": "c11-260"}


def atomic(path, value):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)


def read(path):
    return json.loads(Path(path).read_text())


def pair_root():
    value = os.environ.get('C11_PERF_PAIR')
    if not value or not Path(value).is_absolute():
        raise RuntimeError('C11_PERF_PAIR must explicitly name the new absolute attempt directory')
    return Path(value)


def require_pair():
    root = pair_root()
    state = read(root / 'lease.json')
    if (state['released'] or not state['ready'] or state['host'] != platform.node()
            or time.monotonic() >= state['deadline_monotonic']
            or (root / 'release-request.json').exists()):
        raise RuntimeError('Quiet-window lease unavailable/expired/revoked')
    if time.monotonic() - state['heartbeat_monotonic'] > 3:
        raise RuntimeError('Quiet guardian heartbeat is stale')
    if os.getloadavg()[0] >= 8:
        request_release('load-threshold; attribution-required')
        raise RuntimeError('Load >=8: retain attempt, stop, classify attribution before any new run')
    return state


def require_runtime(tag):
    pair = require_pair()
    role = next((role for role, assigned in TAGS.items() if assigned == tag), None)
    if role is None: raise RuntimeError('Unassigned tag')
    ui = read(pair_root() / role / 'ui-lease.json')
    if (ui['tag'] != tag or ui['pair_token'] != pair['token'] or ui['released']
            or not ui.get('watchdog_ready') or ui.get('stage') != 'active'
            or time.monotonic() >= ui['deadline_monotonic']
            or time.monotonic() - ui['heartbeat_monotonic'] > 3):
        raise RuntimeError('UI lease unavailable/expired')
    return ui


def request_release(reason):
    root = pair_root()
    state = read(root / 'lease.json')
    # Every writer uses unique temporary files + rename; guardian never sees partial JSON.
    atomic(root / 'release-request.json', {'token': state['token'], 'reason': reason,
                                         'unix': time.time(), 'monotonic': time.monotonic()})


def verify_seal(role):
    import hashlib
    identity = read(os.environ['C11_PERF_IDENTITY'])
    item = identity[role]
    root = Path(__file__).parent
    for name, sha in item['script_sha256'].items():
        if Path(name).name != name or hashlib.sha256((root/name).read_bytes()).hexdigest() != sha:
            raise RuntimeError('Frozen helper changed: '+name)
    if hashlib.sha256((root/'PROTOCOL.md').read_bytes()).hexdigest() != item['protocol_sha256']:
        raise RuntimeError('Frozen protocol changed')
    return item

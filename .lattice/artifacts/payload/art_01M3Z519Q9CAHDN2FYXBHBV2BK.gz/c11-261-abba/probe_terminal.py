"""Synthetic raw-input terminal fixture, identical on control and candidate."""
import os
import signal
import sys
import termios
import tty

marker = sys.argv[1]
if marker not in ("G60-PROBE-ONE", "G60-PROBE-TWO"):
    raise SystemExit("Supply a synthetic probe marker")
fd = sys.stdin.fileno()
old = termios.tcgetattr(fd)


def finish(*_):
    raise SystemExit(0)


signal.signal(signal.SIGTERM, finish)
signal.signal(signal.SIGINT, finish)
try:
    tty.setraw(fd)
    os.write(1, f"\x1b[?25l\x1b[2J\x1b[H{marker}\x1b[3;4Ha".encode())
    while True:
        value = os.read(fd, 1)
        if not value or value == b"\x03":
            break
        if value in (b"a", b"b"):
            os.write(1, b"\x1b[3;4H" + value)
finally:
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
    os.write(1, b"\x1b[?25h\r\n")

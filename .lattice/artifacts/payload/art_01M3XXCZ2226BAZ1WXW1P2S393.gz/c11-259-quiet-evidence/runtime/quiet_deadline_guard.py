"""Independent guard for the already-running flock owner's cap/release path."""
import json,os,signal,subprocess,time
from pathlib import Path
p=Path('/tmp/c11-259-perf/paired-quiet');lease=json.loads((p/'lease.json').read_text());pid=lease['pid'];token=lease['token'];deadline=lease['deadline_monotonic'];guard={'pid':os.getpid(),'controller_pid':pid,'token':token,'started_unix':time.time(),'deadline_monotonic':deadline}
(p/'deadline-guard.json').write_text(json.dumps(guard,indent=2)+'\n')
while True:
 current=json.loads((p/'lease.json').read_text())
 if current['token']!=token or current['released']:break
 request=p/'release-request.json';overdue=False
 if request.exists():
  r=json.loads(request.read_text());overdue=r['token']==token and time.time()>r.get('unix',time.time())+2
 if time.monotonic()>=deadline-1 or overdue:
  command=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True,timeout=2).strip()
  if '/tmp/c11-259-perf/quiet_window.py' not in command:raise RuntimeError('Controller PID identity changed')
  os.kill(pid,signal.SIGTERM);time.sleep(.3)
  try:os.kill(pid,0)
  except ProcessLookupError:pass
  else:os.kill(pid,signal.SIGKILL)
  guard.update(forced_release_unix=time.time(),reason='cap' if not overdue else 'release-request-overdue');break
 time.sleep(.2)
guard['finished_unix']=time.time();(p/'deadline-guard.json').write_text(json.dumps(guard,indent=2)+'\n')

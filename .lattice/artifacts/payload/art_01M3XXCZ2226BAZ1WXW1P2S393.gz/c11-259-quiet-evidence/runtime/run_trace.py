"""Single candidate-only stack trace; no latency samples or comparison verdict."""
import json,subprocess,time
from pathlib import Path
from visual_probe import Target
from g60 import ChurnWorker,RPC,capture,assert_model,write_json
r=Path('/tmp/c11-259-perf/diagnostic-trace/candidate');out=r/'run';(out/'churn').mkdir(parents=True,exist_ok=False)
c=json.loads((r/'calibration/config.json').read_text());m=json.loads((r/'fixture/manifest.json').read_text());e=json.loads((r/'fixture/expected.json').read_text());t=Target(c,out)
t.post({'kind':'key','keycode':18,'command':True});time.sleep(.3)
im,_,_=t.capture([0,0,1320,880]);t.save_png(im,out/'before.png')
log=open(out/'sample-command.log','w');sampler=subprocess.Popen(['sample',str(c['pid']),'22','1','-file',str(out/'candidate-stacks.txt')],stdout=log,stderr=log)
start=time.monotonic()+1;worker=ChurnWorker(m,e,start,out/'churn/operations.jsonl');worker.start();events=[]
try:
 for n in range(40):
  time.sleep(max(0,start+n*.5-time.monotonic()))
  action={'kind':'scroll','point':c['sidebar_point'],'pixels':10000 if n%2==0 else -c['scroll_pixels']}
  events.append({'sequence':n,'posted_ns':t.post(action),'action':action})
finally:
 worker.stop_and_join()
 (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
 try:sampler.wait(timeout=60)
 except subprocess.TimeoutExpired:sampler.terminate();sampler.wait(timeout=5);raise
 log.close()
assert sampler.returncode==0 and not worker.error and not worker.pending
with RPC(m['tag'],m['socket']) as rpc:
 state=capture(rpc,m,out/'after.json');assert_model(state,m,worker.expected,m['labels']['w01'])
im,_,_=t.capture([0,0,1320,880]);t.save_png(im,out/'after.png')
write_json(out/'trace-result.json',{'purpose':'candidate-only stack diagnosis; not a latency rerun; no percentile result','sampler_exit':sampler.returncode,'scroll_events':len(events),'churn_operations':len(worker.records),'model_verified':True,'source_sha':m.get('source_sha'),'pid':c['pid'],'load':__import__('os').getloadavg()})
print('DIAGNOSTIC TRACE COMPLETE',flush=True)

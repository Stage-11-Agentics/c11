# C11-259 main integration

Merge53d88b7c08c4b02c7ca83021f062168c1053a4b3 joins candidate0440a7e939c474db70bed1a9be14c130edbbc062 and fetched main2d2440ac65425b0041aad2b3117f6c1c5e612768. No rebase.

Two files had textual conflicts:

- Sources/TerminalController.swift: union the worker-method set. Retain all group/batch methods and main's history.list. History back/forward and group focus remain explicit focus-intent methods. No condition, algorithm or execution path was rewritten.
- GhosttyTabs.xcodeproj/project.pbxproj: union three source-phase entry blocks. Preserve group/planner tests alongside BundledSkill/CapabilityFeatures tests in c11LogicTests; preserve group/planner/handler sources alongside main's new guide/capability sources in c11; preserve both WorkspaceManagerSessionSnapshotTests and TabIdentityRestoreTests in hosted c11Tests. C11-284 had also landed by fetch, so its additive entries are included.

Automatic merges in SessionPersistence.swift, Workspace.swift and WorkspaceManager.swift retain C11-299 duplicate-tab normalization, C11-262 focus-history snapshot state and C11-300 ownership-before-close behavior alongside group state. A fresh read-only review found no concrete integration defect. Snapshot normalization copies the original and mutates only tab/layout data; group fields/history survive. Close resolves the owned object before teardown, while cross-window detach still clears membership. History resolves live UUIDs, independent of group/order.

Project parser and git diff --check pass. The exact-head Atlas22-test action passed:12 hosted snapshot,4 group,6 reorder-planner. Test manifest/build log/xcresult are attached. Tagged packaged build and live-scenario evidence are recorded separately.

The Orchestrator performance ruling ev_01M3XQG282KACRCM9GZZTQ0E6G stands. No new performance runs. Both historical comparisons remain disclosed in art_01M3XQBMMKPTCPA6AVXTS3AJ9H. The strict groups performance gate belongs to C11-260/261 and final soak; C11-260 has not started.

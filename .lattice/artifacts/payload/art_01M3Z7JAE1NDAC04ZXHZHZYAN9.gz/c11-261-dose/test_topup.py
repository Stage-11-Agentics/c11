"""Behavioral preparation tests; no apps, sockets, native samples or real slot locks."""
from collections import Counter
import threading
import unittest
from unittest.mock import patch
from lease import selection_lock
from schedule import schedule, pairs, assert_complete, PHASE_DURATIONS


class TopupTests(unittest.TestCase):
    def rows(self, phase):
        return [dict(r, phase=phase, ok=True, latency_ms=10 + (r['role'] == 'candidate'))
                for r in schedule(phase)]

    def test_complete_symmetric_churn_and_quiescent_headroom(self):
        for phase, expected in [('churn', {'typing': 120, 'switch': 60, 'scroll': 60}),
                                ('quiescence', {'typing': 120, 'switch': 60, 'scroll': 60})]:
            rows = self.rows(phase)
            for role in ('control', 'candidate'):
                self.assertEqual(Counter(r['metric'] for r in rows if r['role'] == role), expected)
            self.assertEqual(len(assert_complete(rows, phase)), sum(expected.values()))
            for cycle in sorted({r['cycle'] for r in rows}):
                self.assertEqual([r['role'] for r in rows if r['cycle'] == cycle],
                                 ['control'] * 10 + ['candidate'] * 20 + ['control'] * 10)
        self.assertEqual(PHASE_DURATIONS, {'churn': 300, 'quiescence': 300})

    def test_minima_fail_without_deleting_invalids(self):
        rows = self.rows('quiescence')
        for role in ('control', 'candidate'):
            for metric in ('typing', 'switch', 'scroll'):
                own = [r for r in rows if r['role'] == role and r['metric'] == metric]
                for r in own[:20]: r['ok'] = False
        self.assertEqual(len(assert_complete(rows, 'quiescence')), 240)
        self.assertEqual(len(rows), 480)
        next(r for r in rows if r['ok'] and r['metric'] == 'scroll')['ok'] = False
        with self.assertRaises(ValueError): assert_complete(rows, 'quiescence')

    def test_complete_new_churn_minima_required(self):
        rows = self.rows('churn')
        for role in ('control', 'candidate'):
            for metric in ('typing', 'switch', 'scroll'):
                own = [r for r in rows if r['role'] == role and r['metric'] == metric]
                for r in own[:20]: r['ok'] = False
        self.assertEqual(len(assert_complete(rows, 'churn')), 240)
        next(r for r in rows if r['ok'] and r['metric'] == 'scroll')['ok'] = False
        with self.assertRaises(ValueError): assert_complete(rows, 'churn')
        self.assertEqual(len(rows), 480)

    def test_same_role_serializes_but_other_role_remains_independent(self):
        acquired = threading.Event()
        attempted = threading.Event()
        def worker():
            attempted.set()
            with selection_lock('control'): acquired.set()
        with selection_lock('control'):
            self.assertTrue(selection_lock('control').acquire(blocking=False))
            selection_lock('control').release()
            thread = threading.Thread(target=worker)
            thread.start()
            self.assertTrue(attempted.wait(1))
            self.assertFalse(acquired.wait(.02))
            self.assertTrue(selection_lock('candidate').acquire(blocking=False))
            selection_lock('candidate').release()
        thread.join(timeout=1)
        self.assertFalse(thread.is_alive())
        self.assertTrue(acquired.is_set())
        with self.assertRaises(RuntimeError): selection_lock('unassigned')

    def test_actual_ordinal_pairs_cancel_drift_without_cross_cohort_pairing(self):
        rows = self.rows('quiescence')
        self.assertTrue(all(p['candidate_minus_control_ms'] == 1 for p in pairs(rows)))
        for cycle in range(12):
            own = [r for r in rows if r['cycle'] == cycle]
            means = [sum(10 + .5 * r['trial'] + 3 * (r['role'] == 'candidate')
                         for r in own if r['block'] == b) / 10 for b in range(4)]
            self.assertEqual((means[1] + means[2] - means[0] - means[3]) / 2, 3)

    def test_worker_uses_explicit_role_lock_and_records_held_oracle(self):
        import tempfile
        from pathlib import Path
        from g60 import ChurnWorker
        calls = []
        class FakeRPC:
            def __init__(self, *_): pass
            def __enter__(self): return self
            def __exit__(self, *_): pass
            def call(self, method, **params):
                calls.append(method)
                return {'workspace_id': 'selected'} if method == 'workspace.current' else {}
        for role in ('control', 'candidate'):
            with tempfile.TemporaryDirectory() as directory:
                manifest = {'tag': 'c11-261', 'socket': 'synthetic', 'mode': role}
                worker = ChurnWorker(manifest, {'n': 0}, 0, Path(directory)/'ops.jsonl', count=4, duration=240)
                def mutation(manifest, expected, n, count): return 'synthetic.mutate', {}, {'n': n+1}
                with patch('g60.RPC', FakeRPC), patch('g60.next_operation', mutation), \
                     patch('g60.time.monotonic', return_value=1), \
                     patch('lease.selection_lock', wraps=selection_lock) as choose:
                    worker.run()
                self.assertIsNone(worker.error)
                self.assertEqual(len(worker.records), 4)
                self.assertEqual(choose.call_args_list, [unittest.mock.call(role)]*4)
                for row in worker.records:
                    self.assertEqual(row['selected_before'], row['selected_after'])
                    self.assertLessEqual(row['lock_requested'], row['lock_acquired'])
                    self.assertLessEqual(row['lock_acquired'], row['lock_released'])
                self.assertEqual(worker.expected, {'n': 4})

    def baseline(self):
        from schedule import CYCLE_METRICS
        # The frozen old schedule has ten cycles for BOTH phases, not the top-up schedule.
        rows = []
        for phase in ('no-churn', 'churn'):
            for cycle, metric in enumerate(CYCLE_METRICS):
                for block, role in enumerate(('control', 'candidate', 'candidate', 'control')):
                    for ordinal in range(10):
                        rows.append({'phase': phase, 'cycle': cycle, 'block': block, 'role': role,
                                     'metric': metric, 'ordinal': ordinal,
                                     'index': cycle*20+(block//2)*10+ordinal, 'ok': True, 'latency_ms': 10})
        return rows

    def test_old_churn_is_never_pooled_into_fresh_full_dose(self):
        from delta_compare import assemble
        old = self.baseline()
        new = self.rows('churn') + self.rows('quiescence')
        for row in old:
            if row['phase'] == 'churn' and row['metric'] == 'scroll': row['latency_ms'] = 1
        for row in new:
            if row['phase'] == 'churn': row['latency_ms'] = 100
        result = assemble(old, new, {'incomplete_reasons': []})
        roles = result['phases']['churn']['scroll']['roles']
        self.assertEqual(roles['control']['attempted'], 60)
        self.assertEqual(roles['control']['latency']['p95_ms'], 100)
        self.assertEqual(len(result['budgets']), 18)
        self.assertEqual(len(result['per_pair_deltas']['window2-no-churn-only']), 200)
        self.assertEqual(len(result['per_pair_deltas']['full-dose-final-cohort']), 480)
        self.assertEqual(result['original_window2_status'], 'INCOMPLETE')
        self.assertIs(result['pooling'], False)
        for row in old:
            if row['phase'] == 'churn': row.update(latency_ms=9999, ok=False, error='retained old failure')
        changed = assemble(old, new, {'incomplete_reasons': []})
        self.assertEqual(changed['budgets'], result['budgets'])
        self.assertEqual(changed['status'], result['status'])

    def test_shortfall_does_not_hide_clear_numeric_regression(self):
        from delta_compare import assemble
        old = self.baseline()
        new = self.rows('churn') + self.rows('quiescence')
        for row in new:
            if row['phase'] == 'churn': row.update(ok=False, error='retained-timeout')
            elif row['role'] == 'candidate': row['latency_ms'] = 100
        result = assemble(old, new, {'incomplete_reasons': ['retained failure']})
        self.assertEqual(result['status'], 'FAIL')
        self.assertTrue(result['observed_budget_failures'])
        self.assertTrue(result['incomplete_reasons'])
        self.assertTrue(any('below minimum' in str(i) for i in result['incomplete_reasons']))


if __name__ == '__main__': unittest.main()

import json,subprocess,sys,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('role',choices=['control','candidate']);a=p.parse_args();tag='c11-259-control' if a.role=='control' else 'c11-259';sha='86d45e218f220c89b592653de2f1c488d57068f7' if a.role=='control' else '0440a7e939c474db70bed1a9be14c130edbbc062';root=Path('$HOME/c11-builds')/tag/'source';tools=Path('/tmp/c11-259-perf');out=tools/'paired-fresh'/a.role;out.mkdir(parents=True,exist_ok=False);py=sys.executable
lease=json.loads(subprocess.check_output([py,str(tools/'ui_slot.py'),'take','--tag',tag],text=True));(out/'lease.json').write_text(json.dumps(lease));
def call(argv,name,cwd=None):
 with (out/name).open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,cwd=cwd)
 if r.returncode:raise RuntimeError(name+' FAILED')
 print(a.role+' '+name+' PASS',flush=True)
call([str(root/'scripts/launch-tagged-automation.sh'),tag,'--qa','fresh'],'launch.log',root)
call([py,str(tools/'g60.py'),'--execute','--tag',tag,'--socket','/tmp/c11-debug-'+tag+'.sock','--mode',a.role,'provision','--source-sha',sha,'--out',str(out/'fixture')],'provision.log')
call([py,str(tools/'install_probes.py'),str(out/'fixture/manifest.json')],'probes.log')
call([py,str(tools/'configure.py'),'--tag',tag,'--display','9','--started',str(lease['started']),'--out',str(out/'calibration')],'configure.log')
call([py,str(tools/'calibrate.py'),str(out/'calibration/config.json')],'calibrate.log')

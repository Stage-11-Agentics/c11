# C11-259 main integration validation

**PASS for requested merge validation at53d88b7c08c4b02c7ca83021f062168c1053a4b3.** One merge commit joins prior candidate0440a7e939c474db70bed1a9be14c130edbbc062 and fetched main2d2440ac65425b0041aad2b3117f6c1c5e612768. No rebase, no source changes beyond the merge, and one push to the existing draft PR504.

## Conflict resolution

See RESOLUTION.md and resolution.patch. The only textual conflicts were Sources/TerminalController.swift and GhosttyTabs.xcodeproj/project.pbxproj. Their resolution is an additive union: group/batch and history worker methods coexist; both sets of sources/tests remain registered, including hosted snapshot and duplicate-tab identity tests. Main had also gained C11-284 guide/capability sources/tests, which were retained. No condition or algorithm was rewritten to resolve these conflicts.

C11-299 duplicate-tab recovery, C11-262 focus history and C11-300 close-ownership behavior auto-merged with group state. A fresh read-only agent reviewed those seams and the literal conflict resolutions: PASS, no concrete defect. Project parsing and git diff --check pass.

## Exact-head executed checks

- build-host remote test invocation2c173e6c32174aff9f3d834e5afb4401:12 hosted WorkspaceManagerSessionSnapshotTests,4 logic WorkspaceGroupTests and6 logic WorkspaceReorderPlannerTests,22 total, zero failures; TEST SUCCEEDED. Log, manifest and xcresult in targeted-tests/.
- build-host tagged Debug invocation15e7e912fcc04b9d9b9e1f4c6c51583f:BUILD SUCCEEDED, clean checkout, no overlay. Logs and manifest in debug-build/.
- The retained packaged build-host app, not the re-signed laptop copy, was launched with c11-259 and QA fresh. GUI executable SHA256 b4091aea787b62c0e3b8470cbbac6bed839794ebb4877a678d934b3c0e550871 matches the build manifest. GUI/dylib/CLI hashes are in runtime/runtime-result.json and calibration/config.json.
- tests_v2/test_workspace_groups.py:PASS groups, atomic errors, lifecycle, selection preservation and CLI parity.
- tests_v2/test_workspace_batch_reorder.py:PASS mixed-pin atomic batch reorder, dry-run, selection and CLI parity.

Both scripts explicitly target /tmp/c11-debug-c11-259.sock and the bundled candidate CLI, with C11_GROUPS_TEST_TAG=c11-259. They close only their own fixture windows. Afterward tree/screenshots retain the original tagged window with four readable560x424 terminal areas. Display9 was enumerated and the tagged window confined to its1920x1080 logical bounds. Synthesized Command-Q and the reviewed Quit button closed the app. Process absence and UI-slot release are recorded; lease81.593seconds, below20minutes. No production window was driven. The smoke/cleanup scripts are included; cleanup invocation uses PYTHONPATH=/tmp/c11-259-perf for its shared Target helper.

## Performance ruling and prior evidence

No new performance runs or diagnosis. Orchestrator ruling ev_01M3XQG282KACRCM9GZZTQ0E6G accepts the prior noise-level result for C11-259 and carries the strict gate to C11-260/261 and final soak. C11-260 remains unstarted.

Both prior comparisons were at pre-merge head0440a7e, not this new head. They remain disclosed in art_01M3XQBMMKPTCPA6AVXTS3AJ9H: shared-host quiescent-scroll p99109.254ms vs69.674ms limit plus one typing timeout; build-slot-excluded churn-scroll p9972.623ms vs71.264ms limit,567 valid/zero errors each, with control load later20.893. Their raw numeric results are unchanged. No new-head performance result is claimed.

Localization repair carries forward unchanged; C11-291's18-key manifest remains ev_01M3XGMZMCGN380J1G7N5NQPWY. No installed skills were edited or synced. The merge includes main's skill-source changes plus the group documentation.

## Handoff boundary

The requested single push completed. GitHub reports the new head mergeable; full PR CI is now scheduled and pending. Review may proceed under the owner contract; landing still requires green exact-head CI. This report does not claim merge, deployment or CI completion. SHA256SUMS covers every attached file.

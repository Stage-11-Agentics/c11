# Authorized final top-up, not a new full comparison

Read PROTOCOL.md completely. Freeze and publish protocol/helper/build identity before sampling. Existing window2 helpers/observations remain immutable. Runtime: granted holder -> quiet_external.py -> ui_pair.py -> fresh g60/configure/install/calibrate/prime preparation and actual owner crop review -> interleave.py (churn-scroll240s then quiescence300s only) -> QUIET DONE immediately -> bounded dismiss.py -> offline topup audit. Interpreter /tmp/c11-259-tools/bin/python on Atlas. No new native workload before grant.

Other copied historical run_phases.py/compare.py/ui_slot.py/quiet_window.py remain dependencies, NOT entry points. Never run their sequential workload/slot admission. Same frozen artifacts/tag/geometry, new role PIDs/templates/fixtures/seal. Tests are pure behavioral/unit checks, not native samples or independent review. Perf remains INCOMPLETE until the delta is actually captured and audited.

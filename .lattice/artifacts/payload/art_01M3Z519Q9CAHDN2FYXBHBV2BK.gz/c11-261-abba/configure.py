"""Configure only a known tagged Atlas app/window and capture setup evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def dismiss_setup_notification_sheet(pid):
    """Dismiss only the observed app-owned optional notification setup sheet."""
    import ApplicationServices as AX
    app = AX.AXUIElementCreateApplication(pid)
    AX.AXUIElementSetMessagingTimeout(app, 1)
    def attr(node, name):
        err, value = AX.AXUIElementCopyAttributeValue(node, name, None)
        return value if err == 0 else None
    seen = []
    def walk(node, depth=0):
        if depth > 20 or len(seen) >= 1600 or any(node == old for old in seen): return []
        seen.append(node)
        err, owner = AX.AXUIElementGetPid(node, None)
        if err != 0 or owner != pid: raise RuntimeError('Setup AX traversal left assigned PID')
        rows = [node]
        for child in list(attr(node, 'AXChildren') or []): rows.extend(walk(child, depth+1))
        if depth == 0:
            for child in list(attr(node, 'AXWindows') or []): rows.extend(walk(child, depth+1))
        return rows
    for node in walk(app):
        if attr(node, 'AXRole') != 'AXSheet': continue
        seen = []
        nodes = walk(node)
        labels = [str(attr(child, 'AXValue') or attr(child, 'AXTitle') or '') for child in nodes]
        if 'Turn on notifications for c11' not in labels: continue
        buttons = [child for child in nodes if attr(child, 'AXRole') == 'AXButton' and attr(child, 'AXTitle') == 'Not Now']
        if len(buttons) != 1: raise RuntimeError('Notification setup sheet has ambiguous Not Now action')
        err = AX.AXUIElementPerformAction(buttons[0], 'AXPress')
        if err != 0: raise RuntimeError('Notification setup dismissal failed')
        time.sleep(.2)
        return {'present': True, 'sheet': 'Turn on notifications for c11', 'action': 'Not Now', 'pid': pid}
    return {'present': False, 'pid': pid}


def main():
    import AppKit
    import Foundation
    import Quartz
    from visual_probe import Target
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--display", type=int, required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--started", type=float, required=True)
    args = parser.parse_args()
    if args.tag not in ("c11-261", "c11-261"):
        raise SystemExit("Only the two assigned tags are permitted")
    from lease import require_runtime
    lease = require_runtime(args.tag)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    hostname = subprocess.check_output(["scutil", "--get", "ComputerName"], text=True).strip()
    # Capture stdout of scutil over the explicitly authorized atlas SSH endpoint.
    bundle = "com.stage11.c11.debug." + args.tag.replace("-", ".")
    apps = [app for app in AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(bundle) if app.processIdentifier() == lease['bound_pid']]
    if len(apps) != 1:
        raise RuntimeError("Exactly one tagged app must be running")
    app = apps[0]
    app_path = str(app.bundleURL().path())
    if Path(app_path).name != f"c11 DEV {args.tag}.app":
        raise RuntimeError("Tagged application path mismatch")
    pid = app.processIdentifier()
    if pid != lease["bound_pid"]: raise RuntimeError("UI lease PID mismatch")
    display = Quartz.CGDisplayBounds(args.display)
    if display.size.width < 1480 or display.size.height < 1000:
        raise RuntimeError("Verified display is too small for the paired geometry")
    app.activateWithOptions_(AppKit.NSApplicationActivateIgnoringOtherApps)
    time.sleep(.2)
    notification_setup = dismiss_setup_notification_sheet(pid)
    x, y = int(display.origin.x + 80), int(display.origin.y + 80)
    script = (f'tell application "System Events" to tell (first process whose unix id is {pid})\n'
              f'set position of window 1 to {{{x}, {y}}}\n'
              'set size of window 1 to {1320, 880}\nend tell')
    subprocess.run(["osascript", "-e", script], check=True, timeout=10)
    time.sleep(0.4)
    windows = [w for w in Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListOptionOnScreenOnly, 0)
               if w.get("kCGWindowOwnerPID") == pid and w.get("kCGWindowLayer") == 0
               and w.get("kCGWindowBounds", {}).get("Width", 0) > 800]
    if len(windows) != 1:
        raise RuntimeError("Expected one visible tagged fixture window")
    window = windows[0]
    hashes = {}
    for relative in ("Contents/MacOS/c11", "Contents/MacOS/c11.debug.dylib", "Contents/Resources/bin/c11"):
        hashes[relative] = hashlib.sha256((Path(app_path) / relative).read_bytes()).hexdigest()
    display_mode = Quartz.CGDisplayCopyDisplayMode(args.display)
    import os
    config = {"role": os.environ['C11_PERF_ROLE'], "refresh_hz": Quartz.CGDisplayModeGetRefreshRate(display_mode),
              "physical_pixels": [Quartz.CGDisplayModeGetPixelWidth(display_mode), Quartz.CGDisplayModeGetPixelHeight(display_mode)],"host": hostname, "transport_host": "atlas", "bundle_id": bundle,
              "pid": pid, "app_path": app_path, "window_id": window["kCGWindowNumber"],
              "window_bounds": dict(window["kCGWindowBounds"]), "display_id": args.display,
              "display_bounds": {"x": display.origin.x, "y": display.origin.y,
                                 "width": display.size.width, "height": display.size.height},
              "run_started_unix": args.started, "artifact_sha256": hashes,
              "templates_visually_verified": False}
    from lease import atomic
    atomic(out / "notification-setup.json", notification_setup)
    # Observe configuration provenance without reading unrelated preferences.
    store = Foundation.NSUserDefaults.alloc().initWithSuiteName_(bundle)
    settings = {key: store.objectForKey_(key) for key in
                ('appearanceMode', 'theme.active.light', 'theme.active.dark', 'chromeScalePreset')}
    home = Path.home()
    candidates = [home/'.config/ghostty/config', home/'.config/ghostty/config.ghostty']
    for identifier in ('com.mitchellh.ghostty', 'com.stage11.c11', bundle):
        for name in ('config', 'config.ghostty'):
            candidates.append(home/'Library/Application Support'/identifier/name)
    config_files = []
    for item in candidates:
        record = {'path': str(item).replace(str(home), '$HOME'), 'exists': item.exists()}
        if item.exists():
            raw = item.read_bytes()
            record.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            if raw.strip(): raise RuntimeError('Frozen native-default font condition has a nonempty override')
        config_files.append(record)
    atomic(out / 'settings-audit.json', {'preferences': settings, 'configuration_files': config_files,
                                       'resolved_font_family_exposed': False})
    atomic(out / "config.json", config)
    if (out / "setup-config.json").exists(): raise RuntimeError("Setup identity already recorded")
    atomic(out / "setup-config.json", config)
    target = Target(config, out)
    width, height = (int(config["window_bounds"][k]) for k in ("Width", "Height"))
    image, _, timing = target.capture([0, 0, width, height])
    target.save_png(image, out / "setup.png")
    (out / "setup-capture.json").write_text(json.dumps(timing, indent=2) + "\n")
    print(json.dumps(config, indent=2))


if __name__ == "__main__":
    main()

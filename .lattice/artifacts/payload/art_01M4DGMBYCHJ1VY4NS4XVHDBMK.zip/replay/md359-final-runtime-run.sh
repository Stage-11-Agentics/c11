#!/usr/bin/env bash
set -euo pipefail
export C11_SANDBOX_HOST=local
source "$HOME/c11-builds/md-359/source/scripts/sandbox-common.sh"
body_b64="$(base64 </tmp/md359-final-runtime.py | tr -d '\n')"
quoted_args=""
for argument in "$@"; do quoted_args+=" $(printf '%q' "$argument")"; done
sandbox_guest_script md359-final <<GUEST
set -eu
printf %s '$body_b64' | /usr/bin/base64 -D > /tmp/md359-final-runtime.py
uid="\$(id -u)"
user="\$(id -un)"
/usr/bin/sudo -n /bin/launchctl asuser "\$uid" /usr/bin/sudo -n -u "\$user" \
/usr/bin/env HOME="\$HOME" USER="\$user" LOGNAME="\$user" PATH='/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' \
/usr/bin/python3 /tmp/md359-final-runtime.py $quoted_args
GUEST

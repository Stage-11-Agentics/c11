# Round-2 FINAL full-dose cohort, no pooling

Read PROTOCOL.md fully. It supersedes UNUSED seal018 scroll-only preparation. Never run that protocol. All historical cohorts/helpers remain immutable.

Freeze/publish seal019 and protocol before sampling. Runtime on explicit17-minute grant only: quiet_external observes holder -> ui_pair supervises exact frozen apps -> fresh g60/configure/install/calibrate/prime and actual owner crop review -> interleave (full churn300s/3000ops each +quiescence300s,120/60/60 attempts each perphase) -> QUIET DONE immediately -> bounded dismiss -> offline abba_compare/delta_compare. Interpreter /tmp/c11-259-tools/bin/python. New attempt directory only.

Historical run_phases/compare/ui_slot/quiet_window are dependencies, NOT sequential/slot-taking entry points. Per-role locks, unchanged calibration/limits/frozenGUI artifacts. delta_compare carries only complete no-churn; excludes every old churn latency from final budgets/pairs. Full post-state/resource/termination evidence required. Pure preparation tests are not native proof or independent review. Perf remains INCOMPLETE until capture and audit.

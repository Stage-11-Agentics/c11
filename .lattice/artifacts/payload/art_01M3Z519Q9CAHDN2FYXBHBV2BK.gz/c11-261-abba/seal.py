"""Seal locally prepared protocol/scripts and explicit build provenance before collection.

Does not build, inspect Git, or launch apps. Source/build claims are supplied by
owner; actual tagged GUI/dylib/CLI files are hashed here and again by configure.
"""
import argparse
import hashlib
from pathlib import Path
from lease import atomic, read, TAGS
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--identity-input', required=True);p.add_argument('--spec',required=True);p.add_argument('--out',required=True)
a=p.parse_args();root=Path(__file__).parent;identity=read(a.identity_input)
script_hashes={str(f.name):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(root.glob('*.py'))}
for role,tag in TAGS.items():
    item=identity[role]
    for key in ('source_sha','base_sha','merge_base_sha','remote_build_invocation','build_options'):
        if not item.get(key):raise RuntimeError('Missing provenance '+role+'.'+key)
    if item.get('source_tree_dirty') is not False:raise RuntimeError('Clean source attestations required')
    app=Path(item['app_path'])
    if app.name != f'c11 DEV {tag}.app':raise RuntimeError('Wrong tag app path')
    item['artifact_sha256']={rel:hashlib.sha256((app/rel).read_bytes()).hexdigest() for rel in
                            ('Contents/MacOS/c11','Contents/MacOS/c11.debug.dylib','Contents/Resources/bin/c11')}
    item['script_sha256']=script_hashes
    item['calibration_spec_sha256']=hashlib.sha256(Path(a.spec).read_bytes()).hexdigest()
    item['protocol_sha256']=hashlib.sha256((root/'PROTOCOL.md').read_bytes()).hexdigest()
if Path(a.out).exists():raise RuntimeError('Seal output already exists; retain earlier attempts')
atomic(a.out,identity)

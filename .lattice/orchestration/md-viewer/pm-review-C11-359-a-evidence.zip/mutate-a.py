from pathlib import Path
import subprocess
root=Path('/tmp/c11-pm-359-a-probes')
def original(name):
    return subprocess.check_output(['git','-C',str(root),'show','HEAD:'+name]).decode()
def change(name, old, new):
    value=original(name)
    assert old in value, name
    (root/name).write_text(value.replace(old,new,1))
(root/'c11Tests/MarkdownWebRendererTests.swift').write_text(original('c11Tests/MarkdownWebRendererTests.swift'))
change('Sources/Panels/MarkdownWebRenderer.swift','else if frame.width > 0, frame.height > 0 { retainedViewport = frame.size }','else { retainedViewport = nil }')
change('Sources/WorkspaceManager.swift','for panel in markdownPanels {','for panel in [] as [MarkdownPanel] {')
change('Sources/MarkdownAssetPolicy.swift','              URLComponents(url: url, resolvingAgainstBaseURL: true)?.percentEncodedPath.removingPercentEncoding?.rangeOfCharacter(from: .controlCharacters) == nil,\n','')
change('Sources/PanelTitleBarView.swift','components.firstIndex(where: {','components.lastIndex(where: {')
change('Sources/ContentView.swift','return types.filter { !blocked.contains($0) }','return types')

"""Ruling-authorized A/B visible probes; equal fixed counts and paired raw deltas."""
import json, os, subprocess, time
from pathlib import Path
import AppKit
import Foundation
from lease import atomic, read, pair_root, require_pair, verify_seal, SELECTION_LOCK
from visual_probe import Target, percentile
from g60 import RPC, ChurnWorker, capture, assert_model
root=pair_root(); contexts={}
def activate(role):
    os.environ['C11_PERF_ROLE']=role
    c=contexts[role]['config']
    app=next(a for a in AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']) if a.processIdentifier()==c['pid'])
    subprocess.run(['/usr/bin/osascript','-e',f'tell application "System Events" to tell (first process whose unix id is {c["pid"]}) to set frontmost to true'],check=True,timeout=3)
    Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.03))
    contexts[role]['target'].verify()
def uptime():
    return {'monotonic':time.monotonic(),'load':os.getloadavg(),
            'uptime':subprocess.check_output(['/usr/bin/uptime'],text=True).strip()}
def choose(t,templates,one,two):
    _,pixels,_=t.capture(templates[one]['roi'])
    for label in (one,two):
        if pixels==Path(templates[label]['pixels']).read_bytes(): return label
    raise RuntimeError('Neither template visible: '+one+'/'+two)
key1={'kind':'key','keycode':18,'command':True};key2={'kind':'key','keycode':19,'command':True}
for role in ('control','candidate'):
    verify_seal(role); os.environ['C11_PERF_ROLE']=role
    c=read(root/role/'calibration/config.json'); m=read(root/role/'fixture/manifest.json')
    if not c.get('templates_visually_verified'): raise RuntimeError('Unreviewed templates')
    contexts[role]={'config':c,'manifest':m,'expected':read(root/role/'fixture/expected.json'),
                    'templates':{k:read(v) for k,v in c['templates'].items()},'selected':m['labels']['w01']}
    app=next(a for a in AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']) if a.processIdentifier()==c['pid'])
    subprocess.run(['/usr/bin/osascript','-e',f'tell application "System Events" to tell (first process whose unix id is {c["pid"]}) to set frontmost to true'],check=True,timeout=3)
    Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.05))
    contexts[role]['target']=Target(c,root/role/'run/crops')
atomic(root/'measurement-claim.json',{'unix':time.time(),'counts':{'typing':105,'switch':42,'scroll':42},'roles':['control','candidate']})
warm=time.monotonic()
while time.monotonic()-warm<60: require_pair();time.sleep(.2)
atomic(root/'warmup.json',{'start':warm,'end':time.monotonic(),'seconds':60})
def sample(role,metric,ident):
    activation_started=time.perf_counter_ns();activate(role);activation_ms=(time.perf_counter_ns()-activation_started)/1e6
    x=contexts[role]; t=x['target']; c=x['config']; ts=x['templates']; m=x['manifest']
    before_host=uptime(); start=time.perf_counter_ns()
    if metric in ('typing','scroll'):
        t.post(key1);time.sleep(.12);x['selected']=m['labels']['w01']
    if metric=='typing':
        t.post({'kind':'click','point':c['terminal_point']})
        before=choose(t,ts,'glyph-a','glyph-b');after='glyph-b' if before=='glyph-a' else 'glyph-a'
        action={'kind':'key','text':after[-1]}
    elif metric=='switch':
        before=choose(t,ts,'workspace-1','workspace-2');after='workspace-2' if before=='workspace-1' else 'workspace-1'
        action=key2 if after=='workspace-2' else key1
    else:
        t.post({'kind':'scroll','point':c['sidebar_point'],'pixels':10000});time.sleep(.12)
        before,after='scroll-top','scroll-down';action={'kind':'scroll','point':c['sidebar_point'],'pixels':-c['scroll_pixels']}
    setup=(time.perf_counter_ns()-start)/1e6
    if metric=='switch':
        with SELECTION_LOCK:
            row=t.measure(ident,metric,action,ts[before],ts[after])
            with RPC(m['tag'],m['socket']) as rpc:observed=rpc.call('workspace.current')['workspace_id']
    else: row=t.measure(ident,metric,action,ts[before],ts[after])
    row.update(role=role,setup_ms=setup,activation_ms=activation_ms,host_before=before_host,host_after=uptime())
    if metric=='switch' and row['ok']:
        x['selected']=m['labels']['w02' if after=='workspace-2' else 'w01']
        row['selected_expected']=x['selected'];row['selected_observed']=observed
        if observed!=x['selected']:raise RuntimeError('Switch selected identity mismatch')
    return row
schedule=(['typing']*5+['switch']*2+['scroll']*2)*21
all_rows=[]
with (root/'paired-samples.jsonl').open('x') as log:
    for phase in ('no-churn','churn','quiescence'):
        workers=[]
        for role in contexts:
            activate(role);x=contexts[role]
            with RPC('c11-261',x['manifest']['socket']) as rpc:
                state=capture(rpc,x['manifest'],root/role/(phase+'-before.json'))
                assert_model(state,x['manifest'],x['expected'],x['selected'])
        started=time.monotonic()+1;deadline=started+130
        if phase=='churn':
            for role in contexts:
                x=contexts[role];w=ChurnWorker(x['manifest'],x['expected'],started,root/role/'operations.jsonl',count=1300,duration=130)
                workers.append((role,w));w.start()
        try:
            for index,metric in enumerate(schedule):
                due=started+index*128/len(schedule);time.sleep(max(0,due-time.monotonic()))
                if time.monotonic()>=deadline:raise RuntimeError('Fixed interleaved phase overrun')
                pair=[]
                for role in ('control','candidate'):
                    row=sample(role,metric,f'{phase}-{index:03d}-{metric}')
                    row.update(phase=phase,index=index,due=due,completed=time.monotonic());pair.append(row)
                    log.write(json.dumps(row)+'\n');log.flush();all_rows.append(row)
                delta=None if not all(r['ok'] for r in pair) else pair[1]['latency_ms']-pair[0]['latency_ms']
                with (root/'deltas.jsonl').open('a') as deltas:deltas.write(json.dumps({'phase':phase,'metric':metric,'index':index,'candidate_minus_control_ms':delta})+'\n')
            time.sleep(max(0,deadline-time.monotonic()))
        finally:
            for role,w in workers:
                w.stop_and_join();contexts[role]['expected']=w.expected
                atomic(root/role/'churn-summary.json',{'count':len(w.records),'error':w.error,'pending':w.pending,'alive':w.is_alive()})
        for role in contexts:
            activate(role);x=contexts[role]
            with RPC('c11-261',x['manifest']['socket']) as rpc:
                state=capture(rpc,x['manifest'],root/role/(phase+'-after.json'))
                assert_model(state,x['manifest'],x['expected'],x['selected'])
        print(phase+' captured',flush=True)
atomic(root/'samples-complete.json',{'unix':time.time(),'monotonic':time.monotonic(),'samples':len(all_rows)})
print('SAMPLES COMPLETE: SEND QUIET DONE NOW',flush=True)

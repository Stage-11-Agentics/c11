import json,sys,time
from pathlib import Path
def release_on_error(error):
 p=Path('/tmp/c11-259-perf/paired-quiet/lease.json')
 if p.exists():
  lease=json.loads(p.read_text())
  if not lease['released']:
   request={'token':lease['token'],'reason':'pair-aborted: '+str(error),'unix':time.time()}
   (p.parent/'release-request.json').write_text(json.dumps(request)+'\n')
def main():
 import json,subprocess,sys,time,hashlib,argparse,os
 from pathlib import Path
 p=argparse.ArgumentParser();p.add_argument('role',choices=['control','candidate']);a=p.parse_args();tools=Path('/tmp/c11-259-perf');root=tools/'paired-quiet'/a.role;cpath=root/'calibration/config.json';c=json.loads(cpath.read_text());proof={}
 # Exact bytes match previously visually verified synthetic templates.
 for label,path in c['templates'].items():
  new=json.loads(Path(path).read_text());old=json.loads((tools/'control-calibration/templates'/f'{label}.json').read_text());assert new['sha256']==old['sha256'] and new['roi']==old['roi'];proof[label]={'sha256':new['sha256'],'matches_reviewed_control_template':True}
 c['templates_visually_verified']=True;cpath.write_text(json.dumps(c,indent=2)+'\n');(root/'calibration/template-review.json').write_text(json.dumps(proof,indent=2)+'\n')
 # Both roles get the same idle settling interval after provision/calibration.
 started=time.monotonic();time.sleep(60);(root/'settling.json').write_text(json.dumps({'requested_idle_s':60,'observed_idle_s':time.monotonic()-started,'unix_end':time.time()},indent=2)+'\n')
 quiet_gate_started=time.monotonic()
 lease=json.loads((root.parent/'lease.json').read_text());assert not lease['released'] and len(lease['acquired'])==2 and time.monotonic()<lease['deadline_monotonic']
 while os.getloadavg()[0]>=8:
  lease=json.loads((root.parent/'lease.json').read_text());assert not lease['released'] and time.monotonic()<lease['deadline_monotonic'];time.sleep(1)
 (root/'measurement-admission.json').write_text(json.dumps({'unix':time.time(),'monotonic':time.monotonic(),'load':os.getloadavg(),'additional_quiet_wait_s':time.monotonic()-quiet_gate_started},indent=2)+'\n')
 (root/'host-processes-before.txt').write_text(subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True));(root/'probe-script-hashes.json').write_text(json.dumps({n:hashlib.sha256((tools/n).read_bytes()).hexdigest() for n in ['g60.py','probe_terminal.py','visual_probe.py','run_phases.py','calibrate.py','setup_quiet.py','run_quiet.py']},indent=2)+'\n')
 r=subprocess.run([sys.executable,str(tools/'run_phases.py'),'--config',str(cpath),'--manifest',str(root/'fixture/manifest.json'),'--expected',str(root/'fixture/expected.json'),'--out',str(root/'run')])
 if a.role=='candidate' or r.returncode:
  lease=json.loads((root.parent/'lease.json').read_text());request={'token':lease['token'],'reason':'pair-complete' if r.returncode==0 else 'pair-aborted','unix':time.time()};(root.parent/'release-request.json').write_text(json.dumps(request)+'\n')
 raise SystemExit(r.returncode)

try:
 main()
except BaseException as error:
 if not isinstance(error,SystemExit) or error.code not in (None,0):release_on_error(error)
 raise

"""Capture role-specific templates using a frozen shared semantic/geometry specification.

capture --config CONFIG --spec SPEC; review --config CONFIG --review REVIEW.
Review is external visual evidence, never inferred from prior C11-259 pixels.
"""
import argparse
import hashlib
from pathlib import Path
import time
from lease import atomic, read
from visual_probe import Target

LABELS=('glyph-a','glyph-b','workspace-1','workspace-2','scroll-top','scroll-down')


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('action',choices=['capture','review'])
    p.add_argument('--config',required=True);p.add_argument('--spec');p.add_argument('--review');p.add_argument('--appearance-review')
    a=p.parse_args();path=Path(a.config);c=read(path)
    if a.action=='review':
        review=read(a.review)
        if not review.get('reviewer') or not review.get('evidence') or review.get('role') != c['role']:
            raise RuntimeError('External role-specific visual review record required')
        for label in LABELS:
            t=read(c['templates'][label]);r=review['templates'][label]
            if r.get('sha256')!=t['sha256'] or r.get('semantics_verified') is not True:
                raise RuntimeError('Template not visually verified: '+label)
        for one,two in [('glyph-a','glyph-b'),('workspace-1','workspace-2'),('scroll-top','scroll-down')]:
            if read(c['templates'][one])['sha256']==read(c['templates'][two])['sha256']:
                raise RuntimeError('Negative control equals target')
        c['templates_visually_verified']=True;c['template_review']=review;atomic(path,c);return
    spec=read(a.spec)
    for key in ('terminal_point','sidebar_point','scroll_pixels','theme','font','scale','sidebar_width'):
        if spec.get(key) is None: raise RuntimeError('Unreviewed calibration input: '+key)
    for label in LABELS:
        item=spec['templates'][label]
        if (not isinstance(item.get('roi'),list) or len(item['roi'])!=4
                or not all(item.get('role_expected_content',{}).get(role) for role in ('control','candidate'))):
            raise RuntimeError('ROI and both expected visible contents must be reviewed before capture: '+label)
    import os
    role = os.environ['C11_PERF_ROLE']
    from appearance import validate
    appearance_review=read(a.appearance_review)
    observed=validate(c,spec,appearance_review,(path.parent/'setup-config.json').read_bytes(),(path.parent/'setup.png').read_bytes())
    c.update(observed)
    c.update(appearance_review=appearance_review,calibration_spec_path=str(Path(a.spec).absolute()))
    c.update({k:spec[k] for k in ('terminal_point','sidebar_point','scroll_pixels','setup_settle_s')})
    c.update(role=role,calibration_spec_sha256=hashlib.sha256(Path(a.spec).read_bytes()).hexdigest(),templates={})
    target=Target(c,path.parent/'templates')
    def snap(label):
        time.sleep(.5)
        item=spec['templates'][label]
        template=target.template(label,item['roi'],item['semantic_expectation'])
        template['role_expected_content']=item['role_expected_content'][role]
        bounds=c['window_bounds']
        context, _, context_timing=target.capture([0,0,int(bounds['Width']),int(bounds['Height'])])
        context_path=path.parent/'templates'/f'{label}-context.png'
        target.save_png(context,context_path)
        template['context_screenshot']=str(context_path)
        template['context_capture']=context_timing
        dest=path.parent/'templates'/f'{label}.json';atomic(dest,template);c['templates'][label]=str(dest)
    target.post({'kind':'key','keycode':18,'command':True});time.sleep(.3)
    target.post({'kind':'click','point':c['terminal_point']});target.post({'kind':'key','text':'a'})
    snap('glyph-a');snap('workspace-1')
    target.post({'kind':'key','text':'b'});snap('glyph-b')
    target.post({'kind':'key','keycode':19,'command':True});snap('workspace-2')
    target.post({'kind':'key','keycode':18,'command':True});time.sleep(.3)
    target.post({'kind':'scroll','point':c['sidebar_point'],'pixels':10000});snap('scroll-top')
    target.post({'kind':'scroll','point':c['sidebar_point'],'pixels':-c['scroll_pixels']});snap('scroll-down')
    target.post({'kind':'scroll','point':c['sidebar_point'],'pixels':10000})
    c['templates_visually_verified']=False;atomic(path,c)


if __name__=='__main__':main()

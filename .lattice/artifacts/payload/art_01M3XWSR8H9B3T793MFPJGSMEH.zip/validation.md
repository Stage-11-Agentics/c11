C11-294 repair round 1 validation

Parent:54e7c46026ddb47fe662b2607c5d21ba7022bd18 (exactly one parent commit after e2af4cb60c). Engine:5830d1976eecca0d7dee202aef8fb2338d99ed6d, pushed to the Stage11 fork main before parent pointer. B1 from review ev_01M3XKQRSM0AA6RD1X3ACTPNTG is repaired.

Cancelled POSIX close transfers only numeric process IDs and KillTimeouts values to a detached std.Thread. The IO join returns without waiting through signal escalation. No Surface, Command, PTY or allocator pointer escapes. Existing synchronous helper remains for tests/startup paths. Spawn failure logs and falls back to bounded synchronous cleanup; resource-exhaustion fallback can still stall and is not claimed prompt. Fresh static review found no high-confidence defect.

[build host] validation

- Focused shutdown tests:79/79 passed,59/59 steps, including the new actual detached-worker prompt-return/eventual-reap test for both ignored-signal cases. Exact tested source hashes matched local files. /tmp/c11-294-r1-[build host]-tests.log and r1-tested-source.sha256.
- Universal ReleaseFast GhosttyKit:262/262 steps, exit0 on [build host]. macOS archive SHA256:9de72e37d85837c62ee4cc5926520e198deeb7f10120eeed90ba2c46a167cc08.
- Tagged Debug app:[build host] invocation2b452a8380054948be13c7ed6b7f0ab5, clean exact parent54e7c46026, engine5830d1976, compile=ok. Retrieved executable/debug-dylib/CLI hashes in artifact-manifest.json. No local C11 build and no hand-edited checksum.

Tagged runtime B1 proof

QA-fresh c11-294-ghostty on [client], PID71075, exact CGWindow34003, verified built-in display1 (external display was no longer present). Held the shared UI slot. Thirty real PTYs streamed at20Hz throughout; three initial keyboard probes plus post-transition/post-close probes used PID-scoped Quartz/AppKit input. This is focused repair proof, not a new100samplecomparison or the full C11-270 soak.

| Child mode | Close return ms | Survivor ACK after close ms | Eventual reap ms | Alive after survivor ACK |
|---|---:|---:|---:|---|
| graceful | 42.921 | 365.170 | 426.626 | False |
| ignore-hup | 52.311 | 345.391 | 12134.493 | True |
| ignore-both | 51.473 | 347.235 | 12113.823 | True |
| detached | 51.506 | 355.911 | 426.334 | False |

Both ignoring jobs were alive before AND after the survivor ACK, then disappeared under original PID/start-time identity checks. Their closes returned in52.3/51.5ms instead of the prior main-thread12.1s park. The ACK-after-close interval includes driver startup, focus checks and text/Return posting; it is not pure key latency. All30streaming workers stayed alive through each case. The detached keep sentinel survived; fixture cleanup then removed only its owned identities.

Load average1/5/15 start:[5.5390625, 5.98291015625, 6.14892578125]; end:[5.97900390625, 6.056640625, 6.16796875].
Fresh C11_HANG_LOG=/tmp/c11-294-r1-hang.log with monitor enabled: no file/event emitted during the run, hence no observed Surface.deinit lock-wait episode. Runtime PASS, zero missed probes, zero cleanup errors. Exact paste remained138022UTF8 bytes with one bracket pair and replies outside it. Raw results and screenshot of survivor ACK during the ignored-HUP grace are attached.

After proof: synthesized Cmd-H made the exact window offscreen; verified, then terminated only PID71075. UI slot released and production CLI pointer restored. No production-window input or installed-skill edits.

Non-blocking findings

- N1 addressed: docs record why the ring stays64slots instead of enlarging it.
- N4 addressed: the cancellation interception comment explains why .forever must not be restored as a blocking producer wait.
- N3 deferred: removing the unused helper/mutex plumbing would broaden this local shutdown repair.
- N2: this new bundle redacts both operator and [build host] home prefixes. Historical evidence also has a redacted replacement art_01M3XM29FXCMEK9WTTVFYV22R1. Existing artifact IDs are immutable through lattice attach; owner did not edit the main checkout directly. Merge Captain should use the redacted replacement and resolve/exclude the old untracked art_01M3XJZDS8YEQ2ZT6XQJ15FX0T before publishing the board.

Validator scenario

1. Build this exact repair source (or merged equivalent) with scripts/remote-build.sh and launch QA-fresh in the authorized UI slot with a fresh C11_HANG_LOG.
2. Run runtime-fixture via run-runtime-sandbox.sh with30streams,3samples, same explicit tagged app/CLI/socket and PID-scoped UI driver. No --comparison-only on candidate.
3. Require close_ms <=500 for both ignoring modes, survivor input ACK while old child remains alive, eventual reap_ms <=18000, all stream workers alive, detached sentinel kept, and zero cleanup errors. Inspect raw per-phase records; do not combine close return and reap time.
4. Prove synthesized dismissal, restore clipboard if used, dispose only fixtures, and release UI slot. Full fleet soak remains deferred to C11-270.

Formal repair re-review and new-engine checksum/exact-head CI are pending. Not merged or released.

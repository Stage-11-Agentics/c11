import json,os,signal,sys,time
from pathlib import Path
out=Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
signal.alarm(300)
for batch in range(200):
    os.write(1,b''.join((f'C11-302 row {batch*100+i:05d} '+ '0123456789abcdef'*12+'\r\n').encode() for i in range(100)))
os.write(1,b'\r\nC11_302_FINAL_SENTINEL\r\n')
(out/'final-written.json').write_text(json.dumps({'pid':os.getpid(),'time_ns':time.monotonic_ns(),'rows':20000}))
for line in sys.stdin:
    command=line.strip()
    if command=='blue': os.write(1,b'\x1b]11;#123456\x07')
    elif command=='red': os.write(1,b'\x1b]11;#562412\x07')
    elif command=='reset': os.write(1,b'\x1b]111\x07')
    elif command=='quit': break
    os.write(1,('C11_302_ACK:'+command+'\r\n').encode())
    with (out/'commands.jsonl').open('a') as f: f.write(json.dumps({'command':command,'time_ns':time.monotonic_ns()})+'\n')

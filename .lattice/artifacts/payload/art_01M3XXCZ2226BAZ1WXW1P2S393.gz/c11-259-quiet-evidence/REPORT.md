# C11-259: one authorized follow-up pair and diagnosis

**Performance FAIL remains. No review handoff: the source-level cause is not established.** Candidate head `0440a7e939c474db70bed1a9be14c130edbbc062` is unchanged and already pushed to draft PR #504. Control remains main `86d45e218f220c89b592653de2f1c488d57068f7`. Exactly one additional matched pair was run after the Orchestrator's quiet-window instruction. No additional control/candidate pair or latency quantile rerun was performed.

## Lock and load conditions

Both real `/tmp/c11-build-host-build-slots/slot-{1,2}.lock` files were held with exclusive `flock` locks for the whole pair. Acquisition waited for existing owners through the same kernel lock mechanism; both were available at acquisition. Launch-time independent nonblocking flock probes confirmed both were held. The controller started at load above 8, waited, and admitted work only below 8. Both role launches and measurement starts separately checked load below 8.

The controller held both locks for **968.043 seconds (16.13 minutes)**, under the 45-minute cap, then released them **0.702 seconds** after the candidate completion request. A separate deadline guard exited normally after release. The shared lock files were never unlinked. These are observed normal-release results; the helper scripts' unexercised exceptional paths are not claimed as a tested reusable locking system.

The continuous log has **962 observations**, maximum gap **1.090 seconds**, and both locks held in every row. Main control measurement admission load was **6.006836**, candidate **3.664551**. All five core fixture/probe script hashes and all three GUI/dylib/CLI hashes per role exactly match the prior pair. Same source heads, display 9, window geometry, fixture, templates, protocol, fixed settling time, and percentile calculations. Wrapper changes only added admission/lease handling and redirected evidence paths; cleanup/watchdog corrections did not alter the probes.

**This was not continuously quiet.** Both build slots were excluded as requested, but unrelated activity remained. Control load rose during the run. No claim that these locks isolated every process on build-host is made.

| Role | No-churn load range | Churn load range | Quiescence load range |
| --- | ---: | ---: | ---: |
| control | 5.482–6.329 | 5.525–17.084 | 11.737–20.893 |
| candidate | 3.316–4.226 | 2.735–3.316 | 2.779–3.206 |

The control peak was 20.893066 while both flocks were held. Process snapshots at +332 and +362 seconds show an unrelated Acetate app/test-worker family doing CPU work during control churn; later snapshots show `du`. The build locks did not exclude those jobs. This identifies concurrent non-build activity, without assigning all load to one process. The candidate stayed below 4.227 during all measured phases.

## Follow-up results

Same 60-workspace/60-tab fixture (56 terminals, two browsers, two markdown tabs); candidate six groups including two empty. Three 60-second phases; each schedules 105 typing, 42 scroll and 42 workspace-switch samples. Both roles yielded **567 valid samples, zero errors/timeouts**. All model/order/pin/membership/selection/tab/shell-identity assertions passed. Each churn worker completed 600 operations at 10 Hz, with zero failed/late/overrun operations and no pending work: control 600 reorders; candidate 300 reorders plus 300 transfers.

| Phase | Metric | Control p95 / p99 ms | Candidate p95 / p99 ms | Result |
| --- | --- | ---: | ---: | --- |
| no-churn | typing | 57.444 / 59.110 | 53.986 / 56.951 | PASS |
| no-churn | scroll | 47.888 / 68.016 | 46.618 / 49.095 | PASS |
| no-churn | switch | 122.797 / 127.808 | 120.295 / 124.713 | PASS |
| churn | typing | 64.312 / 70.396 | 59.913 / 73.312 | PASS |
| churn | scroll | 52.172 / 56.264 | 59.079 / 72.623 | FAIL |
| churn | switch | 115.530 / 125.647 | 112.981 / 119.876 | PASS |
| quiescence | typing | 53.868 / 56.083 | 54.847 / 56.664 | PASS |
| quiescence | scroll | 44.768 / 49.287 | 45.614 / 50.380 | PASS |
| quiescence | switch | 117.117 / 127.323 | 114.463 / 128.792 | PASS |

Only **churn scroll p99** fails: **72.623083 ms**, control **56.264125 ms**, registered limit **71.264125 ms**, excess **1.358958 ms**. All nine p95 checks and eight other p99 checks pass. The earlier quiescent scroll failure and typing timeout did not recur. The result remains FAIL under the unchanged capture-end metric; capture granularity is not used as a waiver.

Control footprint was 3369 MB after each phase; candidate 3371/3372/3372 MB. These values are descriptive. Tagged hang-log paths were absent, so no stronger hang-monitor conclusion is asserted. Synthesized Quit dismissed both tagged apps; UI leases were 526.101 seconds control and 333.538 seconds candidate, both below 20 minutes. All UI locks released. No production app was driven.

## Diagnosis and its limit

The failing sample is `churn-026-scroll`, input monotonic timestamp 2716378.543029250. Six captures still showed the top-of-list template, ending at +13.155, +23.260, +34.295, +43.976, +53.208 and +62.705 ms. The seventh showed the correct scrolled endpoint at +72.623 ms. Individual captures cost 9.218–13.141 ms; there is no screenshot-call spike that explains the outlier. PNGs and raw expected-state hashes are retained.

The only overlapping operation was reorder #84, starting +8.176 ms and completing +12.525 ms (4.349 ms duration). The preceding group transfer completed 90.165 ms before input. This excludes a long overlapping synchronous group/planner call as the direct explanation. Four other slow candidate scroll trials do not overlap a socket operation. Full operation results remain in raw evidence; `failed-trial-analysis.json` contains the reduced timeline.

Source inspection identifies deferred SwiftUI work as a plausible remaining path: `WorkspaceManager.applyWorkspaceReorderPlan` publishes the array (WorkspaceManager.swift:5844), whose observers and sidebar LazyVStack receive updates (ContentView.swift:2695, 8535). Group transfer also publishes `Workspace.groupId` (WorkspaceManager.swift:5913). However, the sidebar source is unchanged, the affected transfer workspaces are offscreen, and control already published twice per reorder versus candidate once. These facts do not establish a new regression in any particular method.

After releasing the build locks and closing the pair, one candidate-only **diagnostic stack capture**, separate from acceptance measurement, exercised 40 wheel events with 195 churn operations. It calculated no visual latency or quantiles and had no control arm. `sample` captured 22 seconds, with 11,164 main-thread observations: one SwiftUI `NSRunLoop.flushObservers` branch contains 3,854 observations, while a run-loop wait branch contains 5,507. Deferred graph/layout work is real and occurs outside synchronous RPC duration. The trace ran on the now-shared host (load 37.207 at completion) and has no event-receipt or frame-presentation boundaries. It therefore cannot causally assign the earlier 72.623 ms trial to that work. The initial trace setup omitted two config fields and stopped before posting any scroll event; its failed setup and idle profile are preserved. The corrected trace completed, verified model identity, and was dismissed by synthesized Quit; its 191.698-second UI lease released normally.

**Unresolved boundary:** existing data cannot distinguish delayed HID delivery, deferred AppKit/SwiftUI reconciliation, and compositor presentation for the failed trial. No speculative source change was made. Establishing that boundary requires an instrumented event-to-presentation trace that would collect new timing observations. Because the Orchestrator prohibited further resampling, that next step is raised for an explicit scope ruling; no additional run will be started meanwhile. C11-259 remains in progress and draft, not handed off as review-ready or performance-approved.

## Earlier shared-host pair, retained without pooling

The prior shared-host matched pair is still fully included. Control load ranged 10.90–49.87; candidate 12.96–20.18. It failed quiescent scroll p99 **109.254333 vs 69.673958 ms limit** and had one candidate quiescent typing timeout. Control had 567 valid/0 failed, candidate 566 valid/1 timeout. The Orchestrator ruled that shared-host result inconclusive as a product verdict; it is disclosed, not deleted or pooled into the new quantiles.

| Phase | Metric | Control p95 / p99 ms | Candidate p95 / p99 ms | Result |
| --- | --- | ---: | ---: | --- |
| no-churn | typing | 54.702 / 57.596 | 50.986 / 54.316 | PASS |
| no-churn | scroll | 49.321 / 58.255 | 49.125 / 54.336 | PASS |
| no-churn | switch | 121.661 / 128.449 | 116.606 / 122.825 | PASS |
| churn | typing | 62.008 / 66.430 | 64.188 / 70.771 | PASS |
| churn | scroll | 73.561 / 93.179 | 54.243 / 62.219 | PASS |
| churn | switch | 132.801 / 259.088 | 114.020 / 134.856 | PASS |
| quiescence | typing | 57.157 / 82.386 | 54.243 / 63.810 | PASS |
| quiescence | scroll | 52.448 / 54.674 | 52.013 / 109.254 | FAIL |
| quiescence | switch | 121.991 / 126.848 | 112.872 / 119.288 | PASS |

Earlier rejected and unequal-precondition exploratory runs are also retained, with their limitations in PREVIOUS-REPORT.md. That previous report's performance verdict and mergeability wording are historical; this report is the current disposition. Original archive `art_01M3XN948YZ69CQ135GVRM9XE2`, validation `ev_01M3XNDJ6MK2W4XYYJBWYNS0HH`, SHA256 `a7eb91ba8145acd9b268adaa8759f185debb9178b1bf51d98395e50ed2a350cf` remain unchanged.

## Localization, tests and integration state

The localization repair remains complete: 17 CLI diagnostic branches plus empty-list status use `String(localized:defaultValue:)`; command/flag/handle tokens and error-code prefixes stay verbatim. The 18-key manifest for C11-291 is `ev_01M3XGMZMCGN380J1G7N5NQPWY` and localization-key-manifest.md. Six translations remain C11-291's task. No installed skills were edited or synced.

Previously executed at the unchanged final head: build-host Debug build passes; 22 targeted assertions pass (12 hosted snapshot, 4 group, 6 reorder planner); both live group/batch scenarios pass; 37 candidate CLI diagnostic/status checks and 2 real older-app capability checks pass. No-current-window diagnostic was not executed. Build manifests/logs/xcresults remain in the archive. Original restart/focus/event proof is carried forward only for byte-identical relevant source, with provenance in the prior report. W2/W3 and final fleet soak are not claimed.

Exact-head push-triggered Mailbox parity checks (mailbox-unit and python-syntax) passed. Full PR build/compatibility checks have not run at this head. Current main advanced; GitHub's latest mergeability read was unknown, following an earlier conflicting state. No mergeability or complete CI pass is claimed. No source changes, commits or pushes were added for this comparison/diagnosis.

## Independent readback

Both remote and portable raw-evidence comparison return FAIL with zero incomplete reasons and exactly the one churn-scroll p99 failure. A separate read-only agent recomputed the portable result and verified the core script/binary hashes and continuous-load extrema. Reproduce after unpacking:

```sh
python3 runtime/compare.py --control runtime/paired-quiet/control/run --candidate runtime/paired-quiet/candidate/run --evidence-root "$PWD/runtime" --identity runtime/source-provenance.json --out quiet-reproduced.json
```

Expected exit 1. To reproduce the prior pair, replace `paired-quiet` with `paired-fresh`; expected exit 1 for the earlier quiescent-scroll failure. `SHA256SUMS` covers the delivered evidence. Lock/admission/load audit is runtime/paired-quiet/quiet-audit.json; trace is runtime/diagnostic-trace/candidate/run/candidate-stacks.txt.

"""Synthesize bounded dismissal of the exact leased tagged app, after measurement."""
import argparse
import json
import os
import subprocess
import time
from pathlib import Path
from lease import atomic, read
from g60 import RPC
from visual_probe import Target

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--config', required=True)
p.add_argument('--manifest', required=True)
p.add_argument('--out', required=True)
a = p.parse_args()
os.environ['C11_PERF_CLEANUP'] = '1'
c, manifest = read(a.config), read(a.manifest)
subprocess.run(['/usr/bin/osascript', '-e',
                f'tell application "System Events" to tell (first process whose unix id is {c["pid"]}) to set frontmost to true'],
               check=True, timeout=3)
import Foundation
Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.03))
target = Target(c, Path(a.out).parent)
actions = []
# Stop only our two probe children; original parent shells remain for normal quit.
with RPC(manifest['tag'], manifest['socket']) as rpc:
    for label in manifest['probe_labels']:
        wid = manifest['labels'][label]
        tid = manifest['initial']['tabs'][wid][0]['id']
        response = rpc.call('tab.send_key', workspace_id=wid, tab_id=tid, key='ctrl+c')
        actions.append({'kind': 'probe-interrupt', 'workspace_id': wid, 'tab_id': tid, 'response': response})
time.sleep(.5)
target.post({'kind': 'key', 'keycode': 12, 'command': True})
actions.append({'kind': 'Command-Q', 'pid': c['pid'], 'unix': time.time()})
time.sleep(.5)
# The shipped warning defaults to Cancel. Answer only the observed owned quit
# sheet, not arbitrary dialogs or a global Return key.
import ApplicationServices as AX
def attr(node, key):
    error, value = AX.AXUIElementCopyAttributeValue(node, key, None)
    return value if error == 0 else None
def walk(node, seen, depth=0):
    if depth > 18 or len(seen) > 2000 or any(node == old for old in seen):
        return []
    seen.append(node)
    error, pid = AX.AXUIElementGetPid(node, None)
    if error or pid != c['pid']:
        raise RuntimeError('Quit AX traversal left assigned PID')
    nodes = [node]
    for child in list(attr(node, 'AXChildren') or []):
        nodes.extend(walk(child, seen, depth+1))
    return nodes
root = AX.AXUIElementCreateApplication(c['pid'])
AX.AXUIElementSetMessagingTimeout(root, .5)
pressed = False
for window in list(attr(root, 'AXWindows') or []):
    for sheet in list(attr(window, 'AXSheets') or []):
        nodes = walk(sheet, [])
        labels = [str(attr(n, 'AXValue') or attr(n, 'AXTitle') or '') for n in nodes]
        if 'Quit c11?' not in labels or 'This will close all windows and workspaces.' not in labels:
            continue
        target.verify()
        buttons = [n for n in nodes if attr(n, 'AXRole') == 'AXButton' and attr(n, 'AXTitle') == 'Quit']
        if len(buttons) != 1:
            raise RuntimeError('Quit button is ambiguous')
        image, _, timing = target.capture([0, 0, int(c['window_bounds']['Width']), int(c['window_bounds']['Height'])])
        target.save_png(image, Path(a.out).parent / 'quit-sheet.png')
        error = AX.AXUIElementPerformAction(buttons[0], 'AXPress')
        actions.append({'kind': 'AXPress Quit', 'pid': c['pid'], 'labels': labels,
                        'returncode': error, 'capture': timing})
        if error:
            raise RuntimeError('Quit action failed')
        pressed = True
if not pressed:
    # System Events runs under the existing granted accessibility context. Read
    # only this exact PID's owned sheet; never an application name or global key.
    script = (f'tell application "System Events" to tell (first process whose unix id is {c["pid"]})\n'
              'if (count of sheets of window 1) is not 1 then error "Expected one owned quit sheet"\n'
              'set dialogTexts to value of every static text of sheet 1 of window 1\n'
              'set dialogButtons to name of every button of sheet 1 of window 1\n'
              'return {dialogTexts, dialogButtons}\nend tell')
    evidence = subprocess.run(['/usr/bin/osascript', '-e', script],
                              capture_output=True, text=True, timeout=3)
    actions.append({'kind': 'System Events owned-sheet read', 'pid': c['pid'],
                    'stdout': evidence.stdout, 'stderr': evidence.stderr, 'returncode': evidence.returncode})
    if (evidence.returncode or 'Quit c11?' not in evidence.stdout
            or 'This will close all windows and workspaces.' not in evidence.stdout
            or 'Cancel' not in evidence.stdout):
        atomic(a.out, {'pid': c['pid'], 'gone': False, 'synthesized': actions})
        raise RuntimeError('Exact owned quit warning not observed; no guessed confirmation')
    target.verify()
    image, _, timing = target.capture([0, 0, int(c['window_bounds']['Width']), int(c['window_bounds']['Height'])])
    target.save_png(image, Path(a.out).parent / 'quit-sheet.png')
    action = (f'tell application "System Events" to tell (first process whose unix id is {c["pid"]})\n'
              'if (count of buttons of sheet 1 of window 1 whose name is "Quit") is not 1 then error "Ambiguous Quit"\n'
              'click button "Quit" of sheet 1 of window 1\nend tell')
    result = subprocess.run(['/usr/bin/osascript', '-e', action], capture_output=True, text=True, timeout=3)
    actions.append({'kind': 'System Events click exact owned Quit', 'pid': c['pid'],
                    'returncode': result.returncode, 'stderr': result.stderr, 'capture': timing})
    if result.returncode: raise RuntimeError('Owned Quit action failed')
deadline = time.monotonic() + 10
while time.monotonic() < deadline:
    Foundation.NSRunLoop.currentRunLoop().runUntilDate_(Foundation.NSDate.dateWithTimeIntervalSinceNow_(.01))
    apps = list(target.A.NSRunningApplication.runningApplicationsWithBundleIdentifier_(c['bundle_id']))
    if not any(app.processIdentifier() == c['pid'] for app in apps):
        atomic(a.out, {'pid': c['pid'], 'gone': True, 'synthesized': actions, 'unix': time.time()})
        print('DISMISSED', flush=True)
        break
    time.sleep(.1)
else:
    image, _, timing = target.capture([0, 0, int(c['window_bounds']['Width']), int(c['window_bounds']['Height'])])
    target.save_png(image, Path(a.out).parent / 'dismiss-pending.png')
    atomic(a.out, {'pid': c['pid'], 'gone': False, 'synthesized': actions, 'pending_capture': timing})
    raise RuntimeError('Synthesized quit remains pending; inspect its actual dialog, never count a forced exit')

"""Own one display lease and two exact already-built children for interleaving."""
import json, os, signal, subprocess, time
from pathlib import Path
from lease import atomic, read, pair_root, require_pair, verify_seal
root=pair_root(); pair=require_pair(); lock=Path('/tmp/c11-1.0-ui.lock')
if Path('/tmp/c11-1.0-ui.reserved').exists(): raise RuntimeError('Validator reserved UI')
lock.mkdir(); token=pair['token']; atomic(lock/'pair.json',{'token':token,'pid':os.getpid()})
children={}; states={}; stop=False
def request_stop(*_):
    global stop
    stop=True
signal.signal(signal.SIGTERM,request_stop)
signal.signal(signal.SIGINT,request_stop)
try:
    for role in ('control','candidate'):
        identity=verify_seal(role); app=Path(identity['app_path'])
        socket='/tmp/c11-debug-c11-261-'+role+'.sock'
        daemon=str(Path.home()/'Library/Application Support/c11'/('c11d-dev-c11-261-'+role+'.sock'))
        if Path(socket).exists() or Path(daemon).exists(): raise RuntimeError('Owned role socket occupied')
        directory=root/role; directory.mkdir()
        env=dict(os.environ,C11_QA_LAUNCH='fresh',C11_SOCKET_MODE='automation',C11_SOCKET_PATH=socket,C11_ALLOW_SOCKET_OVERRIDE='1',
                 CMUXD_UNIX_PATH=daemon,C11_DEBUG_LOG='/tmp/c11-debug-c11-261-'+role+'.log',CMUX_DEBUG_LOG='/tmp/c11-debug-c11-261-'+role+'.log',
                 C11_HANG_LOG='/tmp/c11-debug-c11-261-'+role+'-hang.log')
        log=(directory/'app-stdout.log').open('x')
        process=subprocess.Popen([str(app/'Contents/MacOS/c11')],env=env,stdout=log,stderr=log,start_new_session=True)
        children[role]=process
        states[role]={'tag':'c11-261','role':role,'bound_pid':process.pid,'app_path':str(app),
            'pair_token':token,'started':time.time(),'deadline_monotonic':time.monotonic()+1200,
            'heartbeat_monotonic':time.monotonic(),'stage':'active','watchdog_ready':True,'released':False,
            'launch_environment':{k:env[k] for k in ('C11_QA_LAUNCH','C11_SOCKET_PATH','C11_ALLOW_SOCKET_OVERRIDE','CMUXD_UNIX_PATH','C11_DEBUG_LOG','CMUX_DEBUG_LOG','C11_HANG_LOG')}}
        atomic(directory/'ui-lease.json',states[role])
    ready_deadline=time.monotonic()+30
    while not all(Path(states[r]['launch_environment']['C11_SOCKET_PATH']).is_socket() for r in states):
        require_pair()
        if time.monotonic()>ready_deadline or any(c.poll() is not None for c in children.values()):
            raise RuntimeError('Tagged role socket bootstrap failed')
        for role in states:
            states[role]['heartbeat_monotonic']=time.monotonic();atomic(root/role/'ui-lease.json',states[role])
        time.sleep(.1)
    atomic(root/'ui-bootstrap-ready.json',{'unix':time.time(),'pids':{r:c.pid for r,c in children.items()}})
    while not stop and not (root/'ui-stop.json').exists():
        require_pair()
        for role,process in children.items():
            if process.poll() is not None:
                if not (root/role/'dismissal.json').exists(): raise RuntimeError(role+' exited unexpectedly')
                states[role].update(released=True,process_gone=True)
            if time.monotonic()>=states[role]['deadline_monotonic']: raise RuntimeError('20-minute pair UI cap')
            states[role]['heartbeat_monotonic']=time.monotonic()
            atomic(root/role/'ui-lease.json',states[role])
        time.sleep(.1)
finally:
    for role,process in children.items():
        forced=process.poll() is None
        if forced:
            process.terminate()
            try: process.wait(timeout=4)
            except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=2)
        states[role].update(released=True,process_gone=True,forced_cleanup=forced,released_monotonic=time.monotonic())
        atomic(root/role/'ui-lease.json',states[role])
    if read(lock/'pair.json')['token']==token:
        (lock/'pair.json').unlink(); lock.rmdir()

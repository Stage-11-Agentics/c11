from pathlib import Path
import subprocess
root=Path('/tmp/c11-pm-359-a-probes')
def original(name):
    return subprocess.check_output(['git','-C',str(root),'show','HEAD:'+name]).decode()
for name in subprocess.check_output(['git','-C',str(root),'diff','--name-only']).decode().splitlines():
    (root/name).write_text(original(name))
p=root/'c11Tests/MarkdownWebRendererTests.swift'
p.write_text(p.read_text()+Path('/tmp/pm-359-a-evidence/snapshot-probe.swift').read_text())
p=root/'Sources/Panels/MarkdownWebRenderer.swift'
s=p.read_text().replace('if ["=", "+", "-", "0"].contains(event.charactersIgnoringModifiers ?? "") {','if [String]().contains(event.charactersIgnoringModifiers ?? "") {')
p.write_text(s)
p=root/'Sources/Panels/MarkdownRendererCache.swift'
s=p.read_text().replace('if current.epoch == epoch, !panel.isRendererVisible,','if !panel.isRendererVisible,')
p.write_text(s)
p=root/'Sources/Workspace.swift'
s=p.read_text().replace('            markdownPanel.applyRestoredPresentation(snapshot.markdown ?? SessionMarkdownPanelSnapshot())\n','')
p.write_text(s)

"""Read-only ABBA audit. No launch, input, sockets, retries or resampling."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from compare import Audit, decode, stats, png, numeric, near, timing, PAIRS
from schedule import assert_complete, pairs, PHASE_DURATIONS, COLLECTION_DURATIONS, schedule
from g60 import next_operation, assert_model, operation_category
from appearance import validate
from prime_gate import evaluate


def audit_run(root, identity_file):
    root = Path(root).resolve()
    helpers = Path(identity_file).resolve().parent
    audit = Audit()
    identity = audit.read(identity_file) or {}
    records, _ = audit.lines(root / 'paired-samples.jsonl')
    rows = [r for r, _ in records]
    manifests = {}
    semantic = {}
    configs = {}
    known = {}
    for role in ('control', 'candidate'):
        try:
            item = identity[role]
            for name, sha in item['script_sha256'].items():
                audit.need(Path(name).name == name and hashlib.sha256((helpers / name).read_bytes()).hexdigest() == sha,
                           role, 'frozen helper mismatch: ' + name)
            audit.need(hashlib.sha256((helpers / 'PROTOCOL.md').read_bytes()).hexdigest() == item['protocol_sha256'], role, 'protocol mismatch')
            directory = root / role
            manifest = audit.read(directory / 'fixture/manifest.json') or {}
            config = audit.read(directory / 'calibration/config.json') or {}
            manifests[role], configs[role], known[role] = manifest, config, {}
            audit.need(manifest['source_sha'] == item['source_sha'] and item['source_tree_dirty'] is False, role, 'source provenance differs')
            audit.need(config['artifact_sha256'] == item['artifact_sha256'], role, 'GUI/dylib/CLI hashes differ')
            spec = (helpers / 'calibration-spec.json').read_bytes()
            audit.need(hashlib.sha256(spec).hexdigest() == item['calibration_spec_sha256'] == config['calibration_spec_sha256'], role, 'calibration spec differs')
            appearance = validate(config, decode(spec), config['appearance_review'],
                                  (directory / 'calibration/setup-config.json').read_bytes(),
                                  (directory / 'calibration/setup.png').read_bytes())
            audit.need(all(config[k] == v for k, v in appearance.items()), role, 'observed settings differ')
            audit.need(config.get('templates_visually_verified') is True, role, 'owner visual review missing')
            # Resolve only original ABBA descendants for relocated offline review.
            def resolve(value):
                original = Path(value).resolve()
                relative = original.relative_to(Path('/tmp/c11-261-dose').resolve())
                candidate = helpers / relative
                if not candidate.resolve().is_relative_to(helpers): raise ValueError('artifact path escape')
                return candidate
            for label, path in config['templates'].items():
                template = audit.read(resolve(path)) or {}
                known[role][label] = template
                pixels = resolve(template['pixels']).read_bytes()
                audit.need(hashlib.sha256(pixels).hexdigest() == template['sha256'], label, 'template hash differs')
                audit.need(len(pixels) == template['roi'][2] * template['roi'][3] * 4, label, 'template byte count differs')
                png(audit, resolve(template['screenshot']), template['roi'])
                reviewed = config['template_review']['templates'][label]
                audit.need(reviewed['sha256'] == template['sha256'] and reviewed.get('semantics_verified') is True, label, 'review differs')
            for one, two in PAIRS.values():
                audit.need(known[role][one]['sha256'] != known[role][two]['sha256'], role, 'negative control equals endpoint')
            readiness = audit.read(directory / 'readiness.json') or {}
            observed = evaluate((directory / 'readiness.log').read_text(), manifest)
            audit.need(readiness.get('complete') is True and observed['complete']
                       and readiness.get('debug_retention_disabled') is True, role, 'native prime gate incomplete')
            expected = copy.deepcopy(manifest['expected'])
            initial = manifest['initial']
            inverse = {v: k for k, v in manifest['labels'].items()}
            groups = {v: k for k, v in manifest['groups'].items()}
            def normalize(value):
                if isinstance(value, str): return inverse.get(value, groups.get(value, value))
                if isinstance(value, list): return [normalize(v) for v in value]
                if isinstance(value, dict): return {normalize(k): normalize(v) for k, v in value.items()}
                return value
            semantic[role] = {'order': normalize(initial['order']), 'pins': normalize(initial['pins']),
                              'membership': normalize(initial['membership']), 'attention': initial['attention'],
                              'tabs': {inverse[ws]: [t['type'] for t in tabs] for ws, tabs in initial['tabs'].items()},
                              'groups': [{k: normalize(g.get(k)) for k in ('name', 'color', 'icon', 'is_pinned', 'is_collapsed', 'member_workspace_ids', 'member_count')}
                                         for g in initial['groups']]}
            selected = manifest['labels']['w01']
            for phase in ('churn', 'quiescence'):
                before = audit.read(directory / (phase + '-before.json')) or {}
                assert_model(before['state'], manifest, expected, selected)
                clock = audit.read(root / (phase + '-clock.json')) or {}
                audit.need(near(clock['deadline'] - clock['start'], PHASE_DURATIONS[phase]), phase, 'phase duration differs')
                if phase == 'churn':
                    operations, _ = audit.lines(directory / 'operations.jsonl')
                    audit.need(len(operations) == 3000, role, 'churn count differs')
                    for n, (operation, where) in enumerate(operations):
                        method, params, predicted = next_operation(manifest, expected, n, count=3000)
                        audit.need(operation['n'] == n and operation['method'] == method and operation['params'] == params
                                   and operation['category'] == operation_category(n) and operation['expected_after'] == predicted,
                                   where, 'mutation oracle mismatch')
                        audit.need(operation['outcome'] == 'ok' and operation['selected_before'] == operation['selected_after'], where, 'mutation failed/focus stolen')
                        audit.need(near(operation['scheduled'], clock['start'] + n / 10)
                                   and clock['start'] <= operation['started'] <= operation['completed'] <= clock['deadline'],
                                   where, 'mutation clock/boundary mismatch')
                        audit.need(operation['started'] <= operation['lock_requested'] <= operation['lock_acquired']
                                   <= operation['lock_released'] <= operation['completed'], where, 'selection-lock timestamps disagree')
                        expected = predicted
                    summary = audit.read(directory / 'churn-summary.json') or {}
                    audit.need(summary.get('count') == 3000 and summary.get('error') is None
                               and summary.get('alive') is False and summary.get('pending') is False, role, 'worker did not quiesce')
                own = [r for r in rows if r['phase'] == phase and r['role'] == role]
                for row in own:
                    if row['metric'] == 'switch' and row.get('selected_observed'):
                        selected = row['selected_observed']
                    elif row['metric'] in ('typing', 'scroll'):
                        selected = manifest['labels']['w01']
                after = audit.read(directory / (phase + '-after.json')) or {}
                assert_model(after['state'], manifest, expected, selected)
            for when in ('before', 'after'):
                resource = audit.read(directory / ('resources-' + when + '.json')) or {}
                audit.need(bool(resource.get('ps')) and resource.get('footprint_returncode') == 0,
                           role, 'resource instrument missing/failed')
            dismissal = audit.read(directory / 'dismissal.json') or {}
            ui = audit.read(directory / 'ui-lease.json') or {}
            audit.need(dismissal.get('gone') is True and dismissal.get('pid') == config['pid']
                       and bool(dismissal.get('synthesized')) and ui.get('process_gone') is True
                       and ui.get('forced_cleanup') is False and ui.get('released') is True, role, 'normal synthesized dismissal unproven')
            audit.need(ui.get('released_monotonic', float('inf')) <= ui['deadline_monotonic'], role, 'UI cap overrun')
        except (OSError, KeyError, ValueError, RuntimeError) as error:
            audit.need(False, role, 'fixture/provenance audit: ' + str(error))
    audit.need(semantic.get('control') == semantic.get('candidate') and len(semantic) == 2, root, 'unmatched semantic fixture')
    for row, where in records:
        try:
            audit.need(row['host_before']['monotonic'] <= row['host_after']['monotonic'] <= row['completed'], where, 'host timestamps disagree')
            audit.need(all(h['uptime'] and len(h['load']) == 3 for h in (row['host_before'], row['host_after'])), where, 'before/after uptime/load missing')
            clock = audit.read(root / (row['phase'] + '-clock.json')) or {}
            audit.need(near(row['due'], clock['start'] + row['trial'] * COLLECTION_DURATIONS[row['phase']] / len(schedule(row['phase'])))
                       and row['host_before']['monotonic'] >= row['due'] and row['completed'] <= clock['deadline'], where, 'trial schedule/boundary mismatch')
            if not row.get('ok'):
                audit.need(bool(row.get('error')), where, 'invalid lacks outcome')
                continue
            before, after = (known[row['role']][row[key]] for key in ('before', 'expected'))
            audit.need({row['before'], row['expected']} == set(PAIRS[row['metric']]), where, 'probe semantics differ')
            action = row['action']
            if row['metric'] == 'typing':
                audit.need(action.get('kind') == 'key' and action.get('text') == row['expected'][-1], where, 'typing input differs')
            elif row['metric'] == 'switch':
                audit.need(action.get('kind') == 'key' and action.get('command') is True
                           and action.get('keycode') == (18 if row['expected'] == 'workspace-1' else 19), where, 'switch input differs')
            else:
                audit.need(action.get('kind') == 'scroll' and action.get('point') == configs[row['role']]['sidebar_point']
                           and action.get('pixels') == -configs[row['role']]['scroll_pixels'], where, 'scroll input differs')
            audit.need(row['pre_capture']['sha256'] == before['sha256'] and row['roi'] == before['roi'] == after['roi'], where, 'negative control/ROI mismatch')
            frames = row['frames']
            audit.need(frames[-1]['sha256'] == after['sha256'] and all(f['sha256'] != after['sha256'] for f in frames[:-1]), where, 'not first expected frame')
            timing(audit, row['pre_capture'], where)
            last = row['input_post_ns']
            audit.need(row['pre_capture']['capture_end_ns'] <= last, where, 'input preceded pre-capture')
            for frame in frames:
                timing(audit, frame, where)
                audit.need(frame['capture_begin_ns'] >= last, where, 'frame timestamps reversed')
                last = frame['capture_end_ns']
            audit.need(near(row['latency_ms'], (last - row['input_post_ns']) / 1e6) and 0 <= row['latency_ms'] <= 1000, where, 'latency/timestamps mismatch')
            if row['metric'] == 'switch': audit.need(row['selected_observed'] == row['selected_expected'], where, 'selected UUID mismatch')
            for suffix in ('before', 'after'): png(audit, root / row['role'] / 'run/crops' / (row['id'] + '-' + suffix + '.png'), after['roi'])
        except (KeyError, ValueError, IndexError) as error:
            audit.need(False, where, 'raw observation audit: ' + str(error))
    budgets = []
    phases = {}
    all_pairs = []
    for phase in ('churn', 'quiescence'):
        own = [r for r in rows if r['phase'] == phase]
        try: all_pairs.extend(assert_complete(rows, phase))
        except ValueError as error:
            audit.need(False, phase, str(error))
            try: all_pairs.extend(pairs(own))
            except ValueError as error: audit.need(False, phase, str(error))
        phases[phase] = {}
        for metric in ('typing', 'switch', 'scroll'):
            roles = {}
            for role in ('control', 'candidate'):
                attempted = [r for r in own if r['metric'] == metric and r['role'] == role]
                valid = [r for r in attempted if r.get('ok')]
                roles[role] = {'attempted': len(attempted), 'valid': len(valid), 'invalid': len(attempted) - len(valid),
                               'latency': stats([r['latency_ms'] for r in valid]),
                               'setup': stats([r['setup_ms'] for r in attempted]),
                               'block_activation': stats([r['activation_ms'] for r in attempted if r['activation_ms'] > 0]),
                               'pre_capture': stats([r['pre_capture']['capture_ms'] for r in attempted if 'pre_capture' in r]),
                               'frames': stats([f['capture_ms'] for r in attempted for f in r.get('frames', [])])}
            delta = [d['candidate_minus_control_ms'] for d in all_pairs if d['phase'] == phase and d['metric'] == metric and d['candidate_minus_control_ms'] is not None]
            contrasts = []
            for cycle in sorted({r['cycle'] for r in own if r['metric'] == metric}):
                blocks = [[r for r in own if r['cycle'] == cycle and r['block'] == b] for b in range(4)]
                if all(len(b) == 10 and all(r.get('ok') for r in b) for b in blocks):
                    means = [sum(r['latency_ms'] for r in b) / 10 for b in blocks]
                    midpoints = [sum((r['host_before']['monotonic'] + r['host_after']['monotonic']) / 2 for r in b) / 10 for b in blocks]
                    contrasts.append({'cycle': cycle, 'candidate_minus_control_ms': (means[1] + means[2] - means[0] - means[3]) / 2,
                                      'actual_mean_time_imbalance_s': (midpoints[1] + midpoints[2] - midpoints[0] - midpoints[3]) / 2})
            phases[phase][metric] = {'roles': roles, 'paired_signed': stats(delta), 'paired_absolute_variation': stats([abs(d) for d in delta]), 'block_contrasts': contrasts}
            for q, mult, additive in ((95, 1.20, 5), (99, 1.25, 15)):
                a, b = (roles[r]['latency'][f'p{q}_ms'] for r in ('control', 'candidate'))
                limit = max(a * mult, a + additive) if a is not None else None
                budgets.append({'phase': phase, 'metric': metric, 'percentile': q, 'control_ms': a, 'candidate_ms': b,
                                'limit_ms': limit, 'pass': b <= limit if b is not None and limit is not None else None})
    complete = audit.read(root / 'samples-complete.json') or {}
    audit.need(complete.get('samples') == len(rows) == 960, root, 'collection incomplete')
    warm = audit.read(root / 'warmup.json') or {}
    audit.need(numeric(warm.get('end')) and numeric(warm.get('start')) and warm['end'] - warm['start'] >= 60, root, 'common warmup incomplete')
    lease = audit.read(root / 'lease.json') or {}
    audit.need(lease.get('ready_load', [99])[0] < 15 and lease.get('external_release_verified') is True and lease.get('released') is True, root, 'quiet admission/release unproven')
    audit.need(bool(list(root.glob('vms-*.json'))) and bool(list(root.glob('processes-*.json'))) and (root / 'load.jsonl').is_file(), root, 'continuous load/VM/process records missing')
    loads = [r[k]['load'][0] for r in rows for k in ('host_before', 'host_after')]
    failed = [b for b in budgets if b['pass'] is False]
    return {'schema': 'c11-261-final-topup-comparison-v1', 'status': 'FAIL' if failed else 'INCOMPLETE' if audit.issues else 'PASS',
            'complete': not audit.issues, 'incomplete_reasons': audit.issues, 'observed_budget_failures': failed,
            'samples': len(rows), 'budgets': budgets, 'phases': phases, 'per_pair_deltas': all_pairs,
            'raw_before_after_loads': [{k: r[k] for k in ('phase', 'index', 'trial', 'role', 'host_before', 'host_after')} for r in rows],
            'load1_min': min(loads) if loads else None, 'load1_max': max(loads) if loads else None,
            'source': {r: identity.get(r, {}).get('source_sha') for r in ('control', 'candidate')},
            'noise_subtracted': False, 'scope': 'targeted performance only; not full ticket acceptance',
            'independent_review': 'pending', 'operator_approval': 'blank', 'hang_instrument': 'report existing role files separately; absence is not zero hangs'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pair', required=True)
    parser.add_argument('--identity', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        report = audit_run(args.pair, args.identity)
    except Exception as error:
        report = {'status': 'INCOMPLETE', 'complete': False, 'samples': None,
                  'load1_min': None, 'load1_max': None, 'budgets': [],
                  'incomplete_reasons': [{'location': 'parser', 'reason': str(error)}]}
    Path(args.out).write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'complete', 'samples', 'load1_min', 'load1_max', 'budgets', 'incomplete_reasons')}, indent=2))
    raise SystemExit({'PASS': 0, 'FAIL': 1, 'INCOMPLETE': 2}[report['status']])

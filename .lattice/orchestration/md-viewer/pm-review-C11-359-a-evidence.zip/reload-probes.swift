
// Post-merge review probes: real file watcher, bundle, cache and non-visible AppKit host.
extension MarkdownWebRendererTests {
    func testPostMergeRetainedReloadKeepsContentWhenLinesAreInsertedAbove() async throws {
        try await postMergeInsertedLines(evict: false)
    }

    func testPostMergeEvictedReloadKeepsContentWhenLinesAreInsertedAbove() async throws {
        try await postMergeInsertedLines(evict: true)
    }

    private func postMergeInsertedLines(evict: Bool) async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("markdown-pm-reload-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let path = folder.appendingPathComponent("reader.md")
        let text = "# Reader\n\n" + (1...80).map { "## Section \($0)\n\nParagraph \($0).\n\n" }.joined()
        try text.write(to: path, atomically: true, encoding: .utf8)
        let panel = MarkdownPanel(workspaceId: UUID(), filePath: path.path)
        panel.applyRestoredPresentation(SessionMarkdownPanelSnapshot(fontScale: 1, theme: "light", typeface: "sans", outlineOpen: false))
        var others: [MarkdownPanel] = []
        defer { panel.close(); others.forEach { $0.close() } }
        let hostID = UUID()
        panel.setRendererVisible(true, hostID: hostID)
        var renderer = panel.ensureRenderer()
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 720, height: 480), styleMask: [.borderless], backing: .buffered, defer: false)
        window.isReleasedWhenClosed = false
        window.contentView = renderer.webView
        defer { window.contentView = nil; window.close() }
        await rendered(renderer, revision: 1)
        _ = try await call(renderer, "scrollToHeading", arguments: ["Section 40"])
        let beforeValue = try await call(renderer, "visible")
        let before = try XCTUnwrap(beforeValue as? [String: Any])
        let headingBefore = try XCTUnwrap((before["heading"] as? [String: Any])?["text"] as? String)
        let yBeforeValue = try await evaluate(renderer, "document.getElementById('c11md-h-section-40').getBoundingClientRect().top")
        let yBefore = try XCTUnwrap(yBeforeValue as? Double)
        XCTAssertEqual(headingBefore, "Section 40")

        if evict {
            let evicted = expectation(description: "postmerge target evicted")
            let token = MarkdownRendererCache.shared.evictions.first(where: { $0 == panel.id }).sink { _ in evicted.fulfill() }
            panel.setRendererVisible(false, hostID: hostID)
            window.contentView = nil
            for _ in 0..<5 {
                let other = MarkdownPanel(workspaceId: UUID(), filePath: path.path)
                others.append(other)
                _ = other.ensureRenderer()
            }
            await fulfillment(of: [evicted], timeout: 30)
            withExtendedLifetime(token) {}
            XCTAssertNil(panel.renderer)
        }

        let inserted = (1...12).map { "## Added \($0)\n\nNew paragraph \($0).\n\n" }.joined()
        let changed = inserted + text
        let reloaded = expectation(description: "postmerge watcher applied inserted text")
        let contentToken = panel.$content.first(where: { $0 == changed }).sink { _ in reloaded.fulfill() }
        try changed.write(to: path, atomically: true, encoding: .utf8)
        await fulfillment(of: [reloaded], timeout: 10)
        withExtendedLifetime(contentToken) {}
        if evict {
            XCTAssertNil(panel.renderer)
            panel.setRendererVisible(true, hostID: hostID)
            renderer = panel.ensureRenderer()
            window.contentView = renderer.webView
            await rendered(renderer, revision: 1)
        } else {
            await rendered(renderer, revision: 2)
        }
        let afterValue = try await call(renderer, "visible")
        let after = try XCTUnwrap(afterValue as? [String: Any])
        let yAfterValue = try await evaluate(renderer, "document.getElementById('c11md-h-section-40').getBoundingClientRect().top")
        let yAfter = try XCTUnwrap(yAfterValue as? Double)
        let headingAfter = (after["heading"] as? [String: Any])?["text"] as? String
        print("POSTMERGE_INSERT evict=\(evict) before=\(headingBefore) after=\(headingAfter ?? "nil") beforeLines=\(String(describing: before["lines"])) afterLines=\(String(describing: after["lines"])) beforeY=\(yBefore) afterY=\(yAfter)")
        XCTAssertEqual(headingAfter, headingBefore, "Inserting earlier sections while evicted must preserve the content being read")
        XCTAssertEqual(yAfter, yBefore, accuracy: 1, "Unchanged Section 40 must stay in the same viewport position")
    }
}

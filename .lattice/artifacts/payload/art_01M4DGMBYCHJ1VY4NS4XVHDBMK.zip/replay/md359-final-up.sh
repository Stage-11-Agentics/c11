#!/usr/bin/env bash
set -euo pipefail
export C11_SANDBOX_HOST=local
/usr/bin/python3 - <<'PY'
import subprocess
p=subprocess.Popen(['/usr/bin/python3','/tmp/md359-final-hardstop.py'],stdin=subprocess.DEVNULL,stdout=open('/tmp/md359-final-timer.stdout','w'),stderr=subprocess.STDOUT,start_new_session=True)
print('hardstop_pid='+str(p.pid),flush=True)
PY
"$HOME/c11-builds/md-359/source/scripts/sandbox-up.sh" md359-final '/Users/atinwoodard/c11-builds/md-359/artifacts/2d8c408343514f9cb436cad16b15a9c5/c11 DEV md-359.app'

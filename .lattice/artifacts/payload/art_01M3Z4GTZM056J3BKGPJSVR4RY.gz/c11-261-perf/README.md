# Prepared C11-261 Atlas harness

No runtime observation was collected during preparation. Only local Python syntax, pure model replay, pure mount-log parsing, evidence-path checks and pure dependency-injected bootstrap/appearance tests were performed. Build-slot/supervised-child/UI behavior still needs independent review and authorized Atlas validation. Bootstrap exception paths and observed-settings admission now have 14 pure executable failure-injection tests in test_preparation.py. No previous evidence was modified/copied. Scripts are stdlib except configure/calibrate/visual capture, which require the already authorized Atlas PyObjC interpreter. Never install tools or run a build while holding the slots.

Read PROTOCOL.md. Before preregistration, the owner must fill/review `calibration-spec.example.json` into a new `calibration-spec.json`, supply exact clean build provenance, clarify normal C11-301 bounded priming fallback acceptance, and register the separate post-phase pointer burst. No review approvals are automatically inherited. Retain all attempts.

## Proposed commands (Atlas only; not executed)

Use your explicit verified Atlas Python path, hostname, display and tagged app PID/path. Environment variables below are task-specific; none replace HOME/PATH.

```sh
export C11_PERF_PAIR=/tmp/c11-261-perf/attempt-001
export C11_PERF_IDENTITY=/tmp/c11-261-perf/identity-001.json
```

Before acquiring slots, build both tags through the existing remote route. Author `identity-input.json` with `control` and `candidate` objects, each containing `source_sha`, `base_sha`, `merge_base_sha`, `source_tree_dirty:false`, `remote_build_invocation`, `build_options` (nonempty object), and exact `app_path`. Seal actual bundle/helper hashes:

```sh
python3 /tmp/c11-261-perf/seal.py --identity-input /tmp/c11-261-perf/identity-input.json --spec /tmp/c11-261-perf/calibration-spec.json --out "$C11_PERF_IDENTITY"
python3 /tmp/c11-261-perf/quiet_window.py hold --pair "$C11_PERF_PAIR" --atlas-host VERIFIED_PLATFORM_NODE --execute
```

The hold command remains in a separate foreground process. Wait for its atomic `lease.json` to show ready, both acquired records, current heartbeat and load <8. Never manually change lease files. Parent death revokes/releases. All authorized setup commands below run through `guarded.py` so exceptions atomically request pair release. The guardian additionally revokes independently on contamination/deadline.

For control first, then candidate exactly once: the assigned tagged app must be stopped, with no existing assigned sockets. `ui_slot.py take` now reserves the UI slot **before launch** and launches the exact sealed bundle executable itself as a supervised child. Do not prelaunch with `open` or the older shell wrapper. It uses the same explicit QA-fresh/automation/tagged-socket/log settings for both roles; the controlled launch environment is recorded in the lease. This direct child launch is deliberate: LaunchServices can detach an app after its launcher fails, preventing reliable PID ownership. The parent sends launch permission only after supervisor readiness; reservation starts the 20-minute cap. Candidate take requires control's successful synthesized dismissal. The app PID returned by take is the one configure must observe. Enumeration/verified-display preparation remains required before launching.

```sh
python3 /tmp/c11-261-perf/ui_slot.py take --role control --app-path '/exact/c11 DEV c11-261.app' --execute
python3 /tmp/c11-261-perf/guarded.py --role control g60.py --execute --tag c11-261 --socket /tmp/c11-debug-c11-261.sock --mode control provision --source-sha EXACT_SHA --mount-log /explicit/tagged/debug.log --out "$C11_PERF_PAIR/control/fixture"
python3 /tmp/c11-261-perf/guarded.py --role control install_probes.py --manifest "$C11_PERF_PAIR/control/fixture/manifest.json"
python3 /tmp/c11-261-perf/guarded.py --role control configure.py --tag c11-261 --display VERIFIED_DISPLAY --started UI_LEASE_STARTED_UNIX --out "$C11_PERF_PAIR/control/calibration"
python3 /tmp/c11-261-perf/guarded.py --role control calibrate.py capture --config "$C11_PERF_PAIR/control/calibration/config.json" --spec /tmp/c11-261-perf/calibration-spec.json --appearance-review /explicit/control-appearance-review.json
```

Before `calibrate.py capture`, independently observe the actual theme/font/scale/sidebar width from the tagged app/settings and setup image. Supply `control-appearance-review.json` with `reviewer`, nonempty `evidence` references, `observed_directly:true`, `observed:{theme,font,scale,sidebar_width}`, `setup_config_sha256` (hash of `calibration/setup-config.json`), `setup_png_sha256` (hash of `calibration/setup.png`), and `identity` containing the exact setup config's `pid,bundle_id,app_path,window_id,window_bounds,display_id,artifact_sha256,run_started_unix`. The four observed settings must match the sealed specification. This explicit external observation record is required by calibration, measurement and comparison; a copy of the spec alone cannot satisfy it. Root's intended baseline is a 200-point sidebar, display 9 at 1920x1080, window 1320x880; these remain intended values until each role's record verifies the actual state.

Review all six captured PNGs against the sealed per-role expected content and their negative controls. Author external `review.json` with `role`, `reviewer`, `evidence` (artifact references), and `templates` mapping all six labels to `{sha256, semantics_verified:true}`. Review identities are assertions for the independent reviewer, not authenticated attestations.

```sh
python3 /tmp/c11-261-perf/guarded.py --role control calibrate.py review --config "$C11_PERF_PAIR/control/calibration/config.json" --review /explicit/control-review.json
python3 /tmp/c11-261-perf/guarded.py --role control prime_gate.py --manifest "$C11_PERF_PAIR/control/fixture/manifest.json" --log /explicit/tagged/debug.log --offset MANIFEST_MOUNT_LOG_OFFSET --debug-retention-disabled --out "$C11_PERF_PAIR/control/readiness.json"
python3 /tmp/c11-261-perf/guarded.py --role control run_phases.py --config "$C11_PERF_PAIR/control/calibration/config.json" --manifest "$C11_PERF_PAIR/control/fixture/manifest.json" --expected "$C11_PERF_PAIR/control/fixture/expected.json" --readiness "$C11_PERF_PAIR/control/readiness.json" --out "$C11_PERF_PAIR/control/run"
```

`run_phases.py` claims its role once before measurement, enforces the fixed warmup, then performs all three phases without discretionary resampling. Invalid/error observations stay on disk. It checks source/artifact/spec against the sealed identity and revalidates lease/quiet condition during each socket/input path. Its fixed source-tail operations leave probe IDs stable.

After the primary phases, run the separately preregistered real pointer burst and retain state/time-series evidence, then capture tagged hang logs/available recomputation evidence and synthesize dismissal in the verified app. Save `dismissal.json` with exact `pid`, `gone:true`, and nonempty `synthesized` action/evidence record. It must come from actual execution, not a preset fixture. No hard-coded C11-259 dialog coordinates were copied.

```sh
python3 /tmp/c11-261-perf/ui_slot.py release --role control --token ACTUAL_UI_TOKEN --dismissal /explicit/control-dismissal.json --execute
```

Repeat the role sequence once with `candidate`, tag `c11-261`, candidate source SHA/socket/app and candidate templates. Then immediately release the pair; or on any manually observed error request release with the explicit failure reason. A successful budget comparison does not authorize a rerun.

```sh
python3 /tmp/c11-261-perf/quiet_window.py release --pair "$C11_PERF_PAIR" --atlas-host VERIFIED_PLATFORM_NODE --execute --reason pair-complete
python3 /tmp/c11-261-perf/compare.py --control "$C11_PERF_PAIR/control/run" --candidate "$C11_PERF_PAIR/candidate/run" --identity "$C11_PERF_IDENTITY" --out "$C11_PERF_PAIR/comparison.json"
```

Verify `lease.json` released both acquired FDs, `release_before_cap:true`, normal UI releases and gone processes. Do not delete real lock files. The independent build-slot guardian releases even while its supervisor is busy taking a process snapshot. UI bootstrap failures preserve a permanent role claim, archive only the owned partial role directory, and remove only an inode/token-matching owned lock after exact-child cleanup is proven. An occupied foreign lock is never touched. Unproven cleanup retains the reservation and fails closed. Forced timeout cleanup is disclosed as failure, never synthesized-dismissal success.

For archived reproduction, unpack this whole small runtime directory plus actual collected evidence, then pass `--evidence-root /unpacked/c11-261-perf` to compare. Only original `/tmp/c11-261-perf` descendants are remapped; parent traversal/symlink escapes are rejected and missing artifacts never fall back to old live files.

## Remaining integration limits

The real pointer burst, synthesized dismissal, hang-log collection and visual review remain owner/CUA steps because their verified geometry and actual artifact identity are not available during this local preparation. No fake coordinates or observations were inserted. Capture resource samples include footprint output/IOSurface details where the tool reports them; missing instruments remain missing evidence. All scripts are frozen before the measured pair. Host contamination requires attribution and an Orchestrator decision; preparation grants no autonomous second attempt.

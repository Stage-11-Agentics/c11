import json,os,subprocess,sys
from pathlib import Path
root=Path('$HOME/c11-builds/c11-259/source');out=Path('/tmp/c11-259-perf');py=sys.executable
cli='$HOME/Library/Developer/Xcode/DerivedData/c11-c11-259/Build/Products/Debug/c11 DEV c11-259.app/Contents/Resources/bin/c11'
def call(argv,log,env=None,cwd=None):
 with (out/log).open('w') as f:
  p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=cwd)
 if p.returncode: raise RuntimeError(f'{log} exited {p.returncode}')
 print(log+' PASS',flush=True)
lease=json.loads(subprocess.check_output([py,str(out/'ui_slot.py'),'take','--tag','c11-259'],text=True));Path('/tmp/c11-259-candidate-lease.json').write_text(json.dumps(lease))
call([str(root/'scripts/launch-tagged-automation.sh'),'c11-259','--qa','fresh'],'candidate-launch.log',cwd=root)
env={k:v for k,v in os.environ.items() if not k.startswith(('C11_','CMUX_'))};env.update(C11_GROUPS_TEST_TAG='c11-259',C11_SOCKET='/tmp/c11-debug-c11-259.sock',C11_SOCKET_PATH='/tmp/c11-debug-c11-259.sock',C11_CLI=cli)
for name in ('test_workspace_groups.py','test_workspace_batch_reorder.py'):
 call([py,str(root/'tests_v2'/name)],'candidate-'+name+'.log',env=env,cwd=root)
call([py,str(out/'check_cli_diagnostics.py'),'--cli',cli,'--socket','/tmp/c11-debug-c11-259.sock','--tag','c11-259','--out-dir',str(out/'candidate-diagnostics')],'candidate-diagnostics.log')
call([py,str(out/'g60.py'),'--execute','--tag','c11-259','--socket','/tmp/c11-debug-c11-259.sock','--mode','candidate','provision','--source-sha','0440a7e939c474db70bed1a9be14c130edbbc062','--out',str(out/'candidate-fixture')],'candidate-provision.log')
call([py,str(out/'install_probes.py'),str(out/'candidate-fixture/manifest.json')],'candidate-probes.log')
call([py,str(out/'configure.py'),'--tag','c11-259','--display','9','--started',str(lease['started']),'--out',str(out/'candidate-calibration')],'candidate-configure.log')
call([py,str(out/'calibrate.py'),str(out/'candidate-calibration/config.json')],'candidate-calibrate.log')

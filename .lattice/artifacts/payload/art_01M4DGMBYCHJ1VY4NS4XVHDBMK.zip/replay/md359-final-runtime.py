#!/usr/bin/env python3
"""Guest-only window-routed scroll and eviction screenshot scenario."""
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import socket
import subprocess
import sys

RUN='md359-final'
APP=Path.home()/'c11-sandbox/apps'/RUN/'c11 DEV md-359.app'
OUT=Path('/Volumes/My Shared Files/out')
SOCKET='/tmp/c11-sandbox-'+RUN+'.sock'
assert APP.is_dir() and OUT.is_dir()
BUNDLE=plistlib.loads((APP/'Contents/Info.plist').read_bytes())['CFBundleIdentifier']
spec=importlib.util.spec_from_file_location('probe','/tmp/md359-final-physical-probe.py')
probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
watch=probe.RendererEvents('/tmp/cmux-debug-'+BUNDLE+'.log')
watch.file.seek(0);watch.read()

def run(*argv):return subprocess.check_output(argv,text=True,timeout=45).strip()
def jxa(source):return run('/usr/bin/osascript','-l','JavaScript','-e',source)
def rpc(method,params=None):
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as client:
  client.settimeout(45);client.connect(SOCKET)
  client.sendall((json.dumps({'id':1,'method':method,'params':params or {}})+'\n').encode())
  data=b''
  while b'\n' not in data:data+=client.recv(65536)
 result=json.loads(data.split(b'\n')[0]);assert result['ok'],result
 return result['result']

report=json.loads((OUT/'final-physical-memory.json').read_text())
A=report['panel_ids'][0];OTHERS=report['panel_ids'][1:6]
PID=report['app_pid'];assert os.kill(PID,0) is None
workspaces=rpc('system.tree')['windows'][0]['workspaces']
WS=workspaces[0]['id']
COMMON={'workspace_id':WS}

def focus(panel):
 mark=watch.mark();rpc('panel.focus',{**COMMON,'panel_id':panel})
 watch.read()
 if panel.lower() not in watch.resident:return watch.wait('ready',panel,mark)
 return None

def window():
 source="ObjC.import('CoreGraphics');var w=ObjC.deepUnwrap(ObjC.castRefToObject($.CGWindowListCopyWindowInfo(0,0)));JSON.stringify(w.filter(w=>w.kCGWindowOwnerPID==="+str(PID)+"&&w.kCGWindowIsOnscreen&&w.kCGWindowLayer===0&&w.kCGWindowName));"
 windows=json.loads(jxa(source));assert len(windows)==1,windows
 return windows[0]

def shot(label):
 w=window();run('/usr/sbin/screencapture','-x','-o','-l'+str(w['kCGWindowNumber']),str(OUT/(label+'.png')))
 (OUT/(label+'.window.json')).write_text(json.dumps({'pid':PID,'window':w},indent=2))
 print(label,flush=True)

def wheel(amount):
 w=window();b=w['kCGWindowBounds'];x=b['X']+b['Width']*.65;y=b['Y']+b['Height']*.5
 # Set exact guest PID frontmost, verify it, then let guest WindowServer route
 # pointer-only events at a point verified inside that PID's CGWindow bounds.
 run('/usr/bin/osascript','-e','tell application "System Events" to tell (first process whose unix id is '+str(PID)+') to set frontmost to true')
 active=int(jxa("ObjC.import('AppKit');Number($.NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier)"));assert active==PID,active
 source='''ObjC.import('CoreGraphics');var p=$.CGPointMake(%f,%f);
var move=$.CGEventCreateMouseEvent(null,5,p,0);$.CGEventPost(0,move);
var ev=$.CGEventCreateScrollWheelEvent(null,0,1,%d);$.CGEventSetLocation(ev,p);$.CGEventPost(0,ev);
JSON.stringify({pid:%d,x:%f,y:%f,pixels:%d,route:'guest HID WindowServer'})'''%(x,y,amount,PID,x,y,amount)
 print(jxa(source),flush=True)

ACTION=sys.argv[1]
if ACTION=='prepare':
 snapshot_path='/tmp/md359-runtime.session.json';rpc('session.save',{'out':snapshot_path})
 snapshot=json.loads(Path(snapshot_path).read_text())
 for win in snapshot['windows']:
  for ws in win.get('tabManager',win.get('workspaceManager',{}))['workspaces']:
   if any(p['id']==A for p in ws['panels']):
    for panel in ws['panels']:
     if panel['id'] not in [A,*OTHERS]:rpc('panel.close',{'workspace_id':ws['id'],'panel_id':panel['id']})
 focus(A)
 (OUT/'final-displays.json').write_text(run('/usr/sbin/system_profiler','SPDisplaysDataType','-json'))
 shot('final-document-top')
elif ACTION=='wheel':
 wheel(int(sys.argv[2]));shot('final-wheel-'+sys.argv[2].replace('-','minus'))
elif ACTION=='quit-menu':
 script='tell application "System Events" to tell (first process whose unix id is '+str(PID)+') to click (first menu item of menu 1 of menu bar item 2 of menu bar 1 whose name starts with "Quit ")'
 print(run('/usr/bin/osascript','-e',script))
 (OUT/'final-quit-request.json').write_text(json.dumps({'pid':PID,'input':'exact-PID AX menu Quit'}))
elif ACTION=='quit-confirm':
 script='tell application "System Events" to tell (first process whose unix id is '+str(PID)+') to click button "Quit" of sheet 1 of window 1'
 print(run('/usr/bin/osascript','-e',script))
 (OUT/'final-quit-confirm.json').write_text(json.dumps({'pid':PID,'input':'exact-PID AX Quit confirmation'}))
elif ACTION=='reload-pair':
 shot('final-before-reload')
 doc=Path('/tmp/c11-359-messaging.md');old=doc.read_text()
 marker='Packaged live reload validation marker.'
 assert marker not in old
 lines=old.splitlines(keepends=True)
 target=next(i for i,line in enumerate(lines) if line.startswith('**Status:**'))
 lines[target]=lines[target].rstrip('\n')+' '+(marker+' ')*45+'\n'
 changed=''.join(lines);assert len(changed.splitlines())==len(old.splitlines())
 mark=watch.mark();doc.write_text(changed)
 ready=watch.wait('ready',A,mark)
 content=rpc('markdown.get_content',{**COMMON,'panel_id':A})
 assert marker in json.dumps(content),content
 shot('final-after-reload')
 result={'pid':PID,'panel':A,'mutated_source_line':target+1,'added_characters':len(changed)-len(old),'same_source_line_count':True,'marker_observed_public_content':True,'ready':ready,'screenshots':['final-before-reload.png','final-after-reload.png']}
 (OUT/'final-live-reload-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
elif ACTION=='eviction-pair':
 shot('final-before-eviction')
 log_start=watch.path.stat().st_size
 mark=watch.mark()
 for other in OTHERS:focus(other)
 evicted=watch.wait('evicted',A,mark)
 ready=focus(A)
 assert ready is not None
 shot('final-after-eviction')
 log=watch.path.read_bytes()[log_start:].decode(errors='replace');(OUT/'final-native-events.log').write_text(log)
 result={'pid':PID,'panel':A,'native_events':[line for line in log.splitlines() if 'markdown.renderer.' in line],'evicted':evicted,'ready':ready,'screenshots':['final-before-eviction.png','final-after-eviction.png']}
 (OUT/'final-reading-position-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
else:raise SystemExit('prepare|wheel <pixels>|eviction-pair')

"""Reserve-before-launch UI lease; exact tagged executable is a supervised child.

No app can exec until its supervisor is ready. Reservation starts the 20-minute
cap, including bootstrap and launch. A closed launch gate makes bootstrap errors
non-launching. The supervisor retains parenthood of the app PID until reaping it,
so cleanup never signals a reused PID. No AppKit/ps/kqueue dependency in deadlines.
"""
import argparse
import json
import os
from pathlib import Path
import plistlib
import select
import shutil
import signal
import subprocess
import sys
import time
import uuid
from lease import TAGS, atomic, pair_root, read, require_pair, request_release, verify_seal

LOCK = Path('/tmp/c11-1.0-ui.lock')


def inode(path):
    stat = Path(path).lstat()
    return [stat.st_dev, stat.st_ino]


def owns(path, identity, token):
    """A failed partial write still belongs to us; replaced/foreign dirs never do."""
    try:
        if Path(path).is_symlink() or inode(path) != identity: return False
        owner = Path(path) / 'lease.json'
        return not owner.exists() or read(owner).get('token') == token
    except (OSError, ValueError):
        return False


def rollback(root, role, state, lock=LOCK, archive=True):
    # Called only before launch, or after the supervisor proved its child gone.
    if owns(lock, state.get('lock_inode'), state['token']): shutil.rmtree(lock)
    directory = Path(root) / role
    if archive and owns(directory, state.get('role_inode'), state['token']):
        # Preserve bootstrap evidence; a permanent role claim forbids a retry here.
        directory.rename(Path(root) / f'failed-{role}-{state["token"]}')


class OwnedChild:
    """Parent-child identity is stronger than a naked PID or ps command match."""
    def __init__(self, pid, waitpid=os.waitpid, kill=os.kill):
        self.pid, self.waitpid, self.kill = pid, waitpid, kill
        self.gone = False

    def poll(self):
        if self.gone: return True
        # ECHILD fails closed; never signal a PID we no longer own.
        found, _ = self.waitpid(self.pid, os.WNOHANG)
        if found == self.pid: self.gone = True
        return self.gone

    def stop(self, clock=time.monotonic, sleep=time.sleep):
        if self.poll(): return True
        try:self.kill(self.pid, signal.SIGKILL)
        except ProcessLookupError:return self.poll()
        deadline = clock() + 1
        while clock() < deadline:
            if self.poll(): return True
            sleep(.01)
        return self.poll()


def launch_environment(state):
    # Same isolation/QA settings for both roles, without LaunchServices detachment.
    env = {k: v for k, v in os.environ.items() if not k.startswith(('C11_', 'CMUX_', 'CMUXD_'))}
    for key in ('GHOSTTY_BIN_DIR','GHOSTTY_RESOURCES_DIR','GHOSTTY_SHELL_FEATURES',
                'GIT_PAGER','GH_PAGER','TERMINFO','XDG_DATA_DIRS'):
        env.pop(key, None)
    env.update(state['launch_environment'])
    return env


def gated_child(state, control_fd):
    read_fd, write_fd = os.pipe()
    try:
        pid = os.fork()
    except BaseException:
        os.close(read_fd); os.close(write_fd); raise
    if pid == 0:
        try:
            os.close(write_fd); os.close(control_fd)
            permission = os.read(read_fd, 1); os.close(read_fd)
            if permission != b'L': os._exit(125)
            executable = str(Path(state['app_path'])/'Contents/MacOS/c11')
            os.execve(executable, [executable], launch_environment(state))
        finally:
            os._exit(126)
    os.close(read_fd)
    return OwnedChild(pid), write_fd


def supervise(root, role, state, control_fd, lock=LOCK):
    """Every initialization step is inside cleanup; parent supervises bootstrap."""
    path = Path(root)/role/'ui-lease.json'
    child = None; gate = None; handed_off = False; reason = 'bootstrap-error'; normal = False
    def interrupted(signum, frame): raise RuntimeError('supervisor signal-'+str(signum))
    signal.signal(signal.SIGTERM, interrupted); signal.signal(signal.SIGINT, interrupted)
    try:
        initial = read(path)
        if initial['token'] != state['token']: raise RuntimeError('UI ownership changed')
        child, gate = gated_child(state, control_fd)
        state.update(bound_pid=child.pid, watchdog_pid=os.getpid(), watchdog_ready=True,
                     stage='ready', heartbeat_monotonic=time.monotonic())
        atomic(path, state)  # Still no executable has started.
        bootstrap_deadline = min(state['deadline_monotonic'], time.monotonic()+15)
        while True:
            now = time.monotonic()
            if now >= state['deadline_monotonic']-.5: reason='20-minute-cap'; break
            if not handed_off and now >= bootstrap_deadline: reason='bootstrap-timeout'; break
            if control_fd is not None and select.select([control_fd], [], [], 0)[0]:
                command=os.read(control_fd,1)
                if command == b'L' and gate is not None:
                    os.write(gate,b'L'); os.close(gate); gate=None
                    state.update(stage='launched', launched_monotonic=time.monotonic())
                    atomic(path,state)
                elif command == b'H' and state['stage']=='launched':
                    handed_off=True;state['stage']='active';atomic(path,state)
                    os.close(control_fd);control_fd=None
                else: reason='bootstrap-aborted';break
            if child.poll():
                # After a successful UI quit, retain supervision until proof is filed.
                if not handed_off: reason='child-exited-during-bootstrap';break
                state['process_gone']=True
            request=Path(root)/role/'ui-release-request.json'
            if request.exists():
                proof=read(request)
                if proof['token']!=state['token'] or proof.get('pid')!=child.pid or not child.poll():
                    raise RuntimeError('Unproven UI release')
                if not proof.get('synthesized') or not proof.get('gone'): raise RuntimeError('Missing synthesized dismissal')
                normal=True;reason='normal-dismissal';break
            pair=read(Path(root)/'lease.json')
            if pair['released'] or (Path(root)/'release-request.json').exists(): reason='quiet-window-revoked';break
            if now-state['heartbeat_monotonic']>=1:
                state['heartbeat_monotonic']=now;atomic(path,state)
            time.sleep(.05)
    except BaseException as error:
        reason='supervisor-error: '+str(error)
    finally:
        # Cleanup precedes all evidence writes, and uses the owned child, not discovery.
        if gate is not None: os.close(gate)
        gone = child is None
        try:
            if child is not None: gone=child.stop()
        except BaseException as error:
            reason+='; child-cleanup-error: '+str(error)
        state.update(released=gone,process_gone=gone,expired=not normal,reason=reason,
                     synthesized_dismissal=normal,released_monotonic=time.monotonic(),stage='released' if gone else 'cleanup-failed')
        try: atomic(path,state)
        finally:
            if gone: rollback(root,role,state,lock,archive=not handed_off)
            if not normal:
                try: request_release(reason)
                except BaseException: pass  # Pair guardian independently observes supervisor/UI deadlines.


class Supervisor:
    def __init__(self, root, role, state):
        self.path=Path(root)/role/'ui-lease.json'; self.state=state
        self.fd=None;self.proc=None
        read_fd,write_fd=os.pipe()
        try:
            with (Path(root)/role/'ui-watchdog.log').open('x') as log:
                self.proc=subprocess.Popen([sys.executable,__file__,'watch','--role',role,'--execute',
                          '--bootstrap',json.dumps(state),'--control-fd',str(read_fd)],
                          pass_fds=(read_fd,),start_new_session=True,stdin=subprocess.DEVNULL,stdout=log,stderr=log)
            self.fd=write_fd
        except BaseException:
            os.close(write_fd);raise
        finally:os.close(read_fd)

    def wait(self, stage):
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            if self.proc.poll() is not None:raise RuntimeError('Supervisor failed before '+stage)
            current=read(self.path)
            if current['token']!=self.state['token']:raise RuntimeError('Supervisor token mismatch')
            if current.get('stage')==stage:return current
            time.sleep(.025)
        raise RuntimeError('Supervisor readiness timed out: '+stage)

    def launch(self):os.write(self.fd,b'L')
    def handoff(self):os.write(self.fd,b'H')
    def close(self):
        if self.fd is not None:os.close(self.fd);self.fd=None
    def abort(self):
        # EOF before handoff makes even an interrupted take fail closed.
        self.close()
        try:self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.terminate()  # Supervisor catches this and stops its owned child.
            self.proc.wait(timeout=2)
        # A blocked filesystem/cleanup failure must leave reservation occupied.
        try:return read(self.path).get('process_gone') is True
        except FileNotFoundError:return (self.path.parent.parent/f'failed-{self.path.parent.name}-{self.state["token"]}').exists()


def bootstrap(root, role, app_path, pair, lock=LOCK, factory=Supervisor, writer=atomic):
    root=Path(root);directory=root/role
    state={'owner':'C11-260','tag':TAGS[role],'token':uuid.uuid4().hex,'pair_token':pair['token'],
           'app_path':str(app_path),'started':time.time(),'started_monotonic':time.monotonic(),
           'deadline_monotonic':time.monotonic()+1200,'released':False,'watchdog_ready':False,
           'heartbeat_monotonic':time.monotonic(),'stage':'reserved','launch_environment':{
               'C11_QA_LAUNCH':'fresh','C11_SOCKET_MODE':'automation',
               'C11_SOCKET_PATH':'/tmp/c11-debug-'+TAGS[role]+'.sock',
               'C11_DEBUG_LOG':'/tmp/c11-debug-'+TAGS[role]+'.log',
               'CMUXD_UNIX_PATH':str(Path.home()/'Library/Application Support/c11'/('c11d-dev-'+TAGS[role]+'.sock'))}}
    supervisor=None;safe_cleanup=True;may_launch=False
    # Claim remains even after rollback, so a failed role cannot be silently retried.
    with (root/f'{role}-ui-attempt.json').open('x') as stream:json.dump({'token':state['token']},stream)
    try:
        lock.mkdir();state['lock_inode']=inode(lock)
        writer(lock/'lease.json',state)
        directory.mkdir();state['role_inode']=inode(directory)
        writer(directory/'lease.json',state)  # immutable ownership marker for safe rollback
        writer(directory/'ui-lease.json',state)
        supervisor=factory(root,role,state)
        supervisor.wait('ready')  # Closed exec gate until every prior step succeeded.
        may_launch=True;safe_cleanup=False;supervisor.launch()
        supervisor.wait('launched');supervisor.handoff()
        active=supervisor.wait('active');supervisor.close()
        return active
    except BaseException:
        if supervisor is not None:
            try:safe_cleanup=supervisor.abort() or not may_launch
            except BaseException:safe_cleanup=not may_launch
        if safe_cleanup:rollback(root,role,state,lock)
        raise


def validate_app(app_path, role, identity):
    path=Path(app_path)
    if path.name!=f'c11 DEV {TAGS[role]}.app' or str(path)!=identity['app_path']:
        raise RuntimeError('Explicit assigned sealed app path required')
    with (path/'Contents/Info.plist').open('rb') as stream:info=plistlib.load(stream)
    if info['CFBundleIdentifier']!='com.stage11.c11.debug.'+TAGS[role].replace('-','.'):
        raise RuntimeError('Tagged bundle identity mismatch')
    import hashlib
    for name,sha in identity['artifact_sha256'].items():
        if hashlib.sha256((path/name).read_bytes()).hexdigest()!=sha:raise RuntimeError('Sealed artifact changed')
    import AppKit
    if AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(info['CFBundleIdentifier']):
        raise RuntimeError('Assigned app must be stopped before reserve-and-launch; never take an already running app')
    for socket in (Path('/tmp')/('c11-debug-'+TAGS[role]+'.sock'),
                   Path.home()/'Library/Application Support/c11'/('c11d-dev-'+TAGS[role]+'.sock')):
        if socket.exists():raise RuntimeError('Tagged socket already exists; do not unlink or adopt it')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['take','watch','release']);p.add_argument('--role',required=True,choices=TAGS)
    p.add_argument('--app-path');p.add_argument('--token');p.add_argument('--dismissal')
    p.add_argument('--bootstrap');p.add_argument('--control-fd',type=int);p.add_argument('--execute',action='store_true')
    a=p.parse_args();root=pair_root()
    if not a.execute or sys.platform!='darwin':raise RuntimeError('Explicit validation-host execution required')
    if a.action=='watch':supervise(root,a.role,json.loads(a.bootstrap),a.control_fd);return
    if a.action=='take':
        try:
            pair=require_pair();identity=verify_seal(a.role);validate_app(a.app_path,a.role,identity)
            if a.role=='candidate':
                control=read(root/'control/ui-lease.json')
                if not control['released'] or not control.get('synthesized_dismissal'):raise RuntimeError('Control dismissal required')
            print(json.dumps(bootstrap(root,a.role,a.app_path,pair)),flush=True)
        except BaseException as error:
            try:request_release('UI bootstrap failed: '+str(error))
            finally:raise
    else:
        state=read(root/a.role/'ui-lease.json');proof=read(a.dismissal)
        if state['token']!=a.token or state['released']:raise RuntimeError('Invalid UI release ownership')
        if proof.get('pid')!=state['bound_pid'] or not proof.get('gone') or not proof.get('synthesized'):
            raise RuntimeError('Exact-PID synthesized-dismissal evidence required')
        atomic(root/a.role/'ui-release-request.json',dict(proof,token=a.token))
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            current=read(root/a.role/'ui-lease.json')
            if current['released']:print(json.dumps(current));return
            time.sleep(.05)
        raise RuntimeError('Supervisor did not confirm release')


if __name__=='__main__':main()

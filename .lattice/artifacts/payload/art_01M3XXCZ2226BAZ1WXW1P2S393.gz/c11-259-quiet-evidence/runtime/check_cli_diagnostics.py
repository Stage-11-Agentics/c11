#!/usr/bin/env python3
"""Exercise C11-259 English CLI diagnostics against explicitly reserved tagged apps.

Example (only after the owner supplies the exact built executable/socket/tag):
  python3 check_cli_diagnostics.py --cli /absolute/candidate/c11 \
    --socket /tmp/c11-debug-RESERVED-TAG.sock --tag RESERVED-TAG \
    --out-dir /tmp/c11-259-perf/diagnostics-RUN

No discovery, launch, build, SSH, source assertions, or installed-skill writes.
By default owns one temporary window and closes only that window. --fixture-window
may name an explicitly reserved pristine window (one ungrouped workspace, no
folders); its window/workspace are retained, and only this script's folders removed.
Optional --control-socket AND --control-tag target an actual old app. They must be
a different reserved socket. No capability response is mocked. Every subprocess's
argv/stdout/stderr and before/after raw+stable model snapshots are retained.

The invariant covers ALL windows' group records, canonical workspace order/pins/
membership/properties, workspace/area/tab identities and selection. As in the group
scenarios, asynchronous shell titles/activity/ports/geometry are excluded; this is
model/selection proof, not native responder, process-continuity, or event proof.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time
import traceback
import uuid


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def validate_socket(raw, tag):
    require(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", tag), "Tag must be an exact reserved lowercase tag")
    path = Path(raw)
    require(path.is_absolute(), "Socket path must be absolute")
    require(not path.is_symlink(), "Refusing a symlinked socket")
    require(path.resolve().parent == Path("/tmp").resolve(), "Socket must be directly under /tmp")
    require(path.name in (f"c11-debug-{tag}.sock", f"c11-sandbox-{tag}.sock"),
            "Socket name must match the exact explicitly reserved tag")
    require(path.is_socket(), f"Tagged socket does not exist: {path}")
    return path


class RPCError(RuntimeError):
    def __init__(self, error):
        self.code = error.get("code", "error")
        super().__init__(f"{self.code}: {error.get('message', 'Unknown error')}")


class RPC:
    def __init__(self, path):
        self.path = str(path)
        self.sequence = 0

    def call(self, method, **params):
        self.sequence += 1
        request = {"id": self.sequence, "method": method, "params": params}
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as channel:
            channel.settimeout(20)
            channel.connect(self.path)
            channel.sendall((json.dumps(request) + "\n").encode())
            with channel.makefile("rb") as stream:
                line = stream.readline(32 * 1024 * 1024)
        response = json.loads(line)
        require(response.get("id") == self.sequence, "Mismatched socket response ID")
        if response.get("ok") is not True:
            raise RPCError(response.get("error") or {})
        return response["result"]


def model_snapshot(rpc, groups_supported):
    tree = rpc.call("system.tree", scope="all")
    raw = {"tree": tree, "workspace_lists": {}, "group_lists": {}}
    stable = {"windows": []}
    for window in tree["windows"]:
        wid = window["id"]
        listed = rpc.call("workspace.list", window_id=wid)
        raw["workspace_lists"][wid] = listed
        groups = []
        if groups_supported:
            group_payload = rpc.call("workspace.group.list", window_id=wid)
            raw["group_lists"][wid] = group_payload
            groups = group_payload["workspace_groups"]
        node = {"id": wid, "selected_workspace_id": window.get("selected_workspace_id"),
                "key": window.get("key"), "current": window.get("current"),
                "active": window.get("active"), "groups": groups, "workspaces": []}
        tree_rows = {row["id"]: row for row in window["workspaces"]}
        require([row["id"] for row in listed["workspaces"]] == list(tree_rows),
                "List/tree workspace order changed between snapshots")
        if groups_supported:
            require(window.get("workspace_groups") == groups, "List/tree group records disagree")
        for row in listed["workspaces"]:
            ws = {key: row.get(key) for key in (
                "id", "index", "selected", "pinned", "group_id", "root_directory", "custom_color")}
            tree_ws = tree_rows[row["id"]]
            if groups_supported:
                require(tree_ws.get("group_id") == row.get("group_id"), "List/tree membership disagrees")
            ws["areas"] = []
            for area in tree_ws.get("areas", tree_ws.get("panes", [])):
                area_node = {key: area.get(key) for key in (
                    "id", "index", "focused", "selected_tab_id", "selected_surface_id")}
                area_node["tabs"] = [{key: tab.get(key) for key in (
                    "id", "index", "type", "focused", "selected", "pinned", "tab_pinned")}
                    for tab in area.get("tabs", area.get("surfaces", []))]
                ws["areas"].append(area_node)
            node["workspaces"].append(ws)
        stable["windows"].append(node)
    return {"raw": raw, "model": stable}


class Fixture:
    def __init__(self, rpc, supplied_window=None, groups_supported=True):
        self.rpc = rpc
        self.window = supplied_window
        self.owned_window = supplied_window is None
        self.groups_supported = groups_supported
        self.owned_groups = []

    def __enter__(self):
        try:
            if self.window:
                uuid.UUID(self.window)
            else:
                self.window = self.rpc.call("window.create")["window_id"]
            rows = self.rpc.call("workspace.list", window_id=self.window)["workspaces"]
            require(len(rows) == 1, "Fixture must have exactly one pristine workspace")
            require(not rows[0].get("pinned") and rows[0].get("group_id") is None,
                    "Fixture workspace must be unpinned and ungrouped")
            self.workspace = rows[0]["id"]
            if self.groups_supported:
                require(not self.rpc.call("workspace.group.list", window_id=self.window)["workspace_groups"],
                        "Fixture must have no pre-existing groups")
            return self
        except BaseException:
            self.__exit__(*sys.exc_info())
            raise

    def make_group(self, name):
        group = self.rpc.call("workspace.group.create", window_id=self.window, name=name)["group"]
        self.owned_groups.append(group["id"])
        return group

    def __exit__(self, exc_type, exc, tb):
        # Explicit-window mode retains the window and its original workspace.
        # Owned-window mode never closes any pre-existing window.
        errors = []
        if self.owned_window and self.window:
            try:
                self.rpc.call("window.close", window_id=self.window)
                ids = [w["id"] for w in self.rpc.call("window.list")["windows"]]
                require(self.window not in ids, "Owned fixture window still exists after close")
            except Exception as error:
                errors.append(str(error))
        else:
            for group in reversed(self.owned_groups):
                try:
                    self.rpc.call("workspace.group.delete", window_id=self.window, group_id=group)
                except Exception as error:
                    errors.append(str(error))
        if errors:
            raise AssertionError("Fixture cleanup failed: " + "; ".join(errors)) from exc


class Runner:
    def __init__(self, cli, outdir):
        self.cli = str(cli)
        self.outdir = outdir
        self.results = []
        self.env = dict(os.environ)
        for key in list(self.env):
            if key.startswith(("C11_", "CMUX_")):
                self.env.pop(key)
        self.env.update({"LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8", "LANGUAGE": "en",
                         "C11_QUIET_DISCOVERY": "1"})

    def case(self, name, fixture, args, expected, success=False):
        directory = self.outdir / name
        directory.mkdir()
        before = model_snapshot(fixture.rpc, fixture.groups_supported)
        write_json(directory / "before.json", before)
        # Global --window preserves the missing-verb branch; these two new
        # command families explicitly bypass the historical window.focus hook.
        argv = [self.cli, "--socket", fixture.rpc.path, "--id-format", "both",
                "--window", fixture.window, *args]
        write_json(directory / "argv.json", argv)
        result = {"name": name, "expected": expected, "status": "FAIL"}
        mutated = False
        try:
            proc = subprocess.run(argv, env=self.env, capture_output=True, text=True, timeout=30)
            (directory / "stdout.txt").write_text(proc.stdout)
            (directory / "stderr.txt").write_text(proc.stderr)
            result["returncode"] = proc.returncode
            after = model_snapshot(fixture.rpc, fixture.groups_supported)
            write_json(directory / "after.json", after)
            mutated = before["model"] != after["model"]
            require(not mutated, f"{name}: full stable group/workspace/selection model mutated")
            result["model_unchanged"] = True
            if success:
                require(proc.returncode == 0 and proc.stdout.strip() == expected and not proc.stderr.strip(),
                        f"{name}: unexpected success output: rc={proc.returncode}, out={proc.stdout!r}, err={proc.stderr!r}")
            else:
                require(proc.returncode != 0, f"{name}: unexpectedly succeeded")
                require(not proc.stdout.strip(), f"{name}: unexpected stdout: {proc.stdout!r}")
                actual = proc.stderr.strip()
                # Only the CLI's outer Error: wrapper may vary. Everything in
                # the diagnostic, including protocol prefixes and tokens, is exact.
                if actual.startswith("Error:"):
                    actual = actual[len("Error:"):].lstrip(" ")
                require(actual == expected, f"{name}: expected {expected!r}, got {actual!r}")
            result["status"] = "PASS"
        except subprocess.TimeoutExpired as error:
            for filename, value in (("stdout.txt", error.stdout), ("stderr.txt", error.stderr)):
                if isinstance(value, bytes):
                    value = value.decode(errors="replace")
                (directory / filename).write_text(value or "")
            result["error"] = "CLI exceeded 30-second timeout"
            # A timeout may leave an in-flight socket request; do not proceed
            # with further mutation probes on this fixture.
            write_json(directory / "result.json", result)
            self.results.append(result)
            raise
        except Exception as error:
            result["error"] = str(error)
            # Stop on the first observed mutation; further cases could obscure it.
            if mutated:
                write_json(directory / "result.json", result)
                self.results.append(result)
                raise
        write_json(directory / "result.json", result)
        self.results.append(result)


def candidate_cases(runner, fixture):
    runner.case("empty_group_list", fixture, ["workspace-group", "list"], "No workspace groups", success=True)
    group = fixture.make_group("CLI diagnostics owned populated group")
    other = fixture.make_group("CLI diagnostics owned empty group")
    gid, other_id, ws = group["id"], other["id"], fixture.workspace
    fixture.rpc.call("workspace.group.add", window_id=fixture.window, group_id=gid, workspace_ids=[ws])
    fixture.rpc.call("workspace.group.collapse", window_id=fixture.window, group_id=gid)
    fixture.rpc.call("workspace.group.pin", window_id=fixture.window, group_id=other_id)
    fixture.rpc.call("workspace.group.set_color", window_id=fixture.window, group_id=gid, color="#123456")
    fixture.rpc.call("workspace.group.set_icon", window_id=fixture.window, group_id=gid, icon="folder.fill")
    # Select a missing ephemeral ref using live refs; never rely on a magic ref being absent.
    refs = {g["ref"] for g in fixture.rpc.call("workspace.group.list", window_id=fixture.window)["workspace_groups"]}
    ordinal = max([int(ref.split(":")[1]) for ref in refs] + [0]) + 1000
    missing = f"workspace_group:{ordinal}"
    cases = [
        ("missing_verb", ["workspace-group"], "workspace-group requires a verb; see --help"),
        ("unknown_verb", ["workspace-group", "invented-verb"], "Unknown workspace-group verb: invented-verb"),
        ("duplicate_value_option", ["workspace-group", "create", "--name", "A", "--name", "B"], "Duplicate option: --name"),
        ("duplicate_flag", ["workspace-group", "list", "--json", "--json"], "Duplicate option: --json"),
        ("missing_option_value", ["workspace-group", "create", "--name"], "--name requires a nonempty value"),
        ("empty_option_value", ["workspace-group", "create", "--name", ""], "--name requires a nonempty value"),
        ("whitespace_option_value", ["workspace-group", "create", "--name", " \t "], "--name requires a nonempty value"),
        ("flag_as_option_value", ["workspace-group", "create", "--name", "--json"], "--name requires a nonempty value"),
        ("unexpected_option", ["workspace-group", "list", "--invented-option"], "Unexpected argument: --invented-option"),
        ("unexpected_positional", ["workspace-group", "list", "stray"], "Unexpected argument: stray"),
        ("missing_group_flag", ["workspace-group", "delete"], "workspace-group delete requires --group"),
        ("missing_name_flag", ["workspace-group", "create"], "workspace-group create requires --name"),
        ("missing_rename_name", ["workspace-group", "rename", "--group", gid], "workspace-group rename requires --name"),
        ("missing_workspaces_flag", ["workspace-group", "add", "--group", gid], "workspace-group add requires --workspaces"),
        ("missing_destination_flag", ["workspace-group", "move", "--workspace", ws], "workspace-group move requires --to-group"),
        ("invalid_group_name", ["workspace-group", "delete", "--group", "Not a selector"], "Invalid group handle: Not a selector (expected UUID or workspace_group:N)"),
        ("invalid_group_zero_ref", ["workspace-group", "delete", "--group", "workspace_group:0"], "Invalid group handle: workspace_group:0 (expected UUID or workspace_group:N)"),
        ("missing_ephemeral_group", ["workspace-group", "delete", "--group", missing], f"group_not_found: {missing} in window {fixture.window}"),
        ("csv_empty_element", ["workspace-group", "add", "--group", gid, "--workspaces", ws + ","], "Workspace lists must be nonempty comma-separated handles"),
        ("csv_all_empty", ["workspace-group", "remove", "--group", gid, "--workspaces", ","], "Workspace lists must be nonempty comma-separated handles"),
        ("color_clear_conflict", ["workspace-group", "set-color", "--group", gid, "--color", "#AABBCC", "--clear"], "Specify exactly one of --color or --clear"),
        ("color_missing_action", ["workspace-group", "set-color", "--group", gid], "Specify exactly one of --color or --clear"),
        ("icon_clear_conflict", ["workspace-group", "set-icon", "--group", gid, "--icon", "folder.fill", "--clear"], "Specify exactly one of --icon or --clear"),
        ("icon_missing_action", ["workspace-group", "set-icon", "--group", gid], "Specify exactly one of --icon or --clear"),
        ("member_move_with_group", ["workspace-group", "move", "--workspace", ws, "--group", gid, "--to-group", "none"], "Member moves do not accept --group or --index"),
        ("member_move_with_index", ["workspace-group", "move", "--workspace", ws, "--to-group", "none", "--index", "0"], "Member moves do not accept --group or --index"),
        ("group_move_without_placement", ["workspace-group", "move", "--group", gid], "Group moves require one of --before, --after or --index and do not accept --to-group"),
        ("group_move_with_destination", ["workspace-group", "move", "--group", gid, "--index", "0", "--to-group", "none"], "Group moves require one of --before, --after or --index and do not accept --to-group"),
        ("group_conflicting_placement", ["workspace-group", "move", "--group", gid, "--before", other_id, "--after", other_id], "Specify only one of --before, --after or --index"),
        ("member_conflicting_placement", ["workspace-group", "move", "--workspace", ws, "--to-group", "none", "--before", ws, "--after", ws], "Specify only one of --before, --after or --index"),
        ("negative_index", ["workspace-group", "move", "--group", gid, "--index", "-1"], "--index requires a nonnegative integer"),
        ("nonnumeric_index", ["workspace-group", "move", "--group", gid, "--index", "first"], "--index requires a nonnegative integer"),
        ("missing_order", ["reorder-workspaces"], "reorder-workspaces requires --order <comma-separated-handles>"),
        ("empty_order_option", ["reorder-workspaces", "--order", ""], "--order requires a nonempty value"),
        ("empty_order_csv", ["reorder-workspaces", "--order", ws + ","], "Workspace lists must be nonempty comma-separated handles"),
        ("duplicate_dry_run", ["reorder-workspaces", "--order", ws, "--dry-run", "--dry-run"], "Duplicate option: --dry-run"),
    ]
    for name, args, expected in cases:
        runner.case(name, fixture, args, expected)


def control_cases(runner, rpc, outdir, supplied_window):
    # Require an actual old-app method_not_found, preserving the real response.
    try:
        rpc.call("workspace.group.list")
    except RPCError as error:
        require(error.code == "method_not_found", f"Control is not an unsupported-method baseline: {error}")
        write_json(outdir / "control-method-probe.json", {"error": str(error), "code": error.code})
    else:
        raise AssertionError("Control supports workspace groups; choose the actual reserved old app")
    with Fixture(rpc, supplied_window, groups_supported=False) as fixture:
        for name, args, method in (
            ("control_unsupported_groups", ["workspace-group", "list"], "workspace.group.list"),
            ("control_unsupported_batch", ["reorder-workspaces", "--order", fixture.workspace, "--dry-run"], "workspace.reorder_batch"),
        ):
            expected = f"{method} is unavailable: this c11 app does not support workspace groups/batch reorder. Update the app."
            runner.case(name, fixture, args, expected)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cli", required=True)
    parser.add_argument("--socket", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--fixture-window", help="Explicit pristine reserved window UUID; retain it after cleanup")
    parser.add_argument("--control-socket")
    parser.add_argument("--control-tag")
    parser.add_argument("--control-fixture-window")
    args = parser.parse_args()
    cli = Path(args.cli)
    require(cli.is_absolute() and cli.is_file() and os.access(cli, os.X_OK), "CLI must be an explicit absolute executable")
    candidate = validate_socket(args.socket, args.tag)
    require(bool(args.control_socket) == bool(args.control_tag), "Supply both --control-socket and --control-tag")
    require(not args.control_fixture_window or args.control_socket, "Control fixture requires a control socket")
    control = validate_socket(args.control_socket, args.control_tag) if args.control_socket else None
    if control:
        require(control.resolve() != candidate.resolve() and args.control_tag != args.tag,
                "Candidate and control must be different reserved tags/sockets")
    outdir = Path(args.out_dir)
    require(outdir.is_absolute(), "Output directory must be absolute")
    outdir.mkdir(parents=True, exist_ok=False)  # Never overwrite an earlier evidence run.
    runner = Runner(cli, outdir)
    summary = {"status": "FAIL", "cli": str(cli), "cli_sha256": hashlib.sha256(cli.read_bytes()).hexdigest(),
               "socket": str(candidate), "tag": args.tag, "control_socket": str(control) if control else None,
               "started_at_unix": time.time(), "cases": runner.results,
               "not_exercised": ["noCurrentWindow: valid reserved fixture always has a current window"],
               "scope": "CLI English output plus full stable group/workspace/area/tab model and selection; no native-focus/event claim"}
    if not control:
        summary["not_exercised"].append("unsupportedMethod: no actual old-app control socket supplied")
    try:
        with Fixture(RPC(candidate), args.fixture_window) as fixture:
            candidate_cases(runner, fixture)
        if control:
            control_cases(runner, RPC(control), outdir, args.control_fixture_window)
        summary["status"] = "PASS" if all(case["status"] == "PASS" for case in runner.results) else "FAIL"
        summary["cleanup"] = "completed"
    except Exception as error:
        summary["error"] = str(error)
        (outdir / "failure.txt").write_text(traceback.format_exc())
    finally:
        summary["finished_at_unix"] = time.time()
        summary["passed"] = sum(case["status"] == "PASS" for case in runner.results)
        summary["failed"] = sum(case["status"] != "PASS" for case in runner.results)
        write_json(outdir / "summary.json", summary)
        print(json.dumps(summary, sort_keys=True))
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, ValueError) as error:
        print(json.dumps({"status": "FAIL", "phase": "preflight", "error": str(error)}))
        raise SystemExit(1)

# C11-302 validation evidence: scrollbar gate pending

This directory contains recorded build/test results, a completed candidate sample, retained earlier failures, an input-route trace excerpt, and six approved neutral screenshots. The completed matched baseline and paired comparison are included. The predeclared preliminary latency threshold passed; ticket acceptance, merge, release, and broader soak are not asserted.

## Build and source identity

The clean remote test invocation `910c5b67ae1f4cb5a79434fe865e0644` tested `5ead7597fe7ac77b54a286a47bae2e9f636654fc`: nine focused tests, zero failures, `TEST SUCCEEDED`. The excerpt includes all nine test names and suite totals. This is the selected coalescer/context slice, not the full suite.

The clean remote Debug app invocation `8f10e91d7afc4308adb44ff2a0d40bf5` built `4fd2a74ae9dfb52ae0f21bf502b7cee83d68b942`: `BUILD SUCCEEDED`, tests not run in that invocation. The engine is `5830d1976eecca0d7dee202aef8fb2338d99ed6d`. Recorded build and retrieved executable hashes differ; both remain in the result record. The candidate run matches the retrieved executable hash.

The clean baseline build result is included from invocation `c79ecf59f3bc43ab812bcbb4c8421378`; its retrieved executable hash exactly matches the baseline runtime record. The baseline source is `b6f239bd077164d2ff2e7aa18d5464d4e885fd35`. At preparation, current head `2f63e9b3c88265aa61879ceca70fc345fc610b7b` adds only fixture/watchdog documentation changes after the built app revision. An unproven pointer-helper addition was reverted; it is absent from the final diff. Product source equivalence is distinct from rebuilding the current full revision. The included owner static pre-review reports no high-confidence findings and records exact production blob identities; it does not replace the formal independent-review gate.

## Completed candidate and retained failures

`candidate/result.json` retains all 100 samples, with zero missed probes and no cleanup errors: 30 streams at 20 Hz, five-second setup warmup, measurement version `shared-raw-return-post-focus-ready-v3`. Return-post to PTY receipt was p50 29.052041 ms, p95 36.868667 ms, p99 37.286667 ms, maximum 37.465792 ms. Full invocation and read-screen timings, raw clocks, loads, readiness observations, counters, and tool/artifact hashes remain in the record. This result is a preliminary scenario sample, not the C11-270 fleet soak or proof of physical keyboard/display latency.

Earlier baseline, repeated baseline, and candidate attempts all failed at their first probe. The 30-stream route diagnostic also failed; the one-stream route diagnostic passed one sample. Those five records are retained in `prior-attempts/`, with a compact summary. The failed records reported readiness before input but no child acknowledgement, and captured terminal login text instead. They are not discarded or counted as successful latency samples.

The selected route trace records text and Return events with `firstResponder=AppKitWindow`; later events record `GhosttyNSView`. This supports an input-routing concern during setup. It does not establish one root cause for every miss. The fixture subsequently added a five-second stream-setup warmup and repeated focus readiness before measurement. The completed candidate uses that correction. No product defect is claimed fixed by this change. A separate settled-baseline attempt failed admission after 10 seconds with appIsActive/windowIsKey false and input_sent=false; that result is also retained, separately from delivered-input misses.

## Visual scope and remaining acceptance

Six owner-inspected neutral images are included with unchanged bytes: `finite-blue-bottom`, `finite-reset-bottom`, `controls-font-before`, `controls-font-increased`, `controls-config-reload`, and `controls-reset` under `ui/`. No other screenshots are included. The owner reports a visible font increase, blue persisting after config reload as expected for an OSC override, and default background restored after OSC reset. Worker records retain the blue/reset commands and 20,000-row final-sentinel emission. Final counters show tick requests/enqueued/drained 41/9/9 and scrollbar 10/6/6, both maxPending=1 and pending=0. These observations do not alone establish complete lifetime or final-sentinel acceptance.

**Scrollbar pointer dragging remains UNPROVEN.** PID-targeted positive/negative scroll and text drag were posted, but no visible change was observed. Event posting is not successful behavior; this package does not declare the candidate fully accepted.

The three dismissal records retain post-hide window enumerations. The owner reports synthesized AXHide, off-screen verification, exact-PID termination, and release of the UI lease. These JSONs themselves describe read-only enumeration and omit kCGWindowIsOnscreen; they do not independently record the hide action or termination. This distinction is retained pending the owner's action log.

`controls/finite-output.py` is the current helper with a 300-second alarm. Worker time_ns values are preserved exactly, but their clock basis is not established by these records and must not be compared across runs or treated as proof that this exact helper revision generated every earlier worker record.

The completed active-baseline run has 100 samples and zero misses: p50 26.043125 ms, p95 36.94925 ms, p99 37.410667 ms, maximum 37.441625 ms. Both sides use the same fixture and driver hashes, 30 streams at 20 Hz, and five-second warmup. The paired record passes the declared candidate p95/p99 ceilings of 44.3391/44.8928004 ms (baseline plus max(5 ms, 20%)). Preserve the earlier failures and distinguish this preliminary threshold check from the separate broader soak. The failed admission run is not used as the comparison baseline.

## Disclosure and provenance

JSON was parsed and sanitized recursively. Home prefixes become `$HOME`; account/host names and emails are removed; run tokens and UUID identities receive stable aliases. Terminal login device identifiers are replaced. Numeric measurements, booleans, Git/object hashes, and build invocation IDs are preserved. Build invocation IDs identify these build records, not provider sessions. Raw originals remain private and unchanged. Selected log excerpts omit unrelated output. No provider session/conversation capture is included.

`manifest.json` lists file hashes and original-source hashes. Hashes identify provenance without publishing private source paths. The manifest excludes itself. Image EXIF/XMP metadata was inspected: resolution, dimensions, and the generic Screenshot comment; no account, host, home path, email, or UUID was found. Images remain byte-identical. Automated textual scans and structural/numeric comparison were applied; such scans cannot rule out every unknown identity, and the six images rely on the owner's prior visual inspection. This package records completed checks and retains the explicitly pending scrollbar gate.

"""Run calibrated paired g60 probes on a pre-launched, verified Atlas tag."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

from lease import selection_lock, require_runtime, atomic
from g60 import RPC, ChurnWorker, assert_model, capture, write_json
from visual_probe import Target, summarize


def read(path):
    return json.loads(Path(path).read_text())


def resource_sample(pid, path):
    # Descriptive snapshots are taken outside timed phases.
    result = {"monotonic": time.monotonic(), "load": os.getloadavg()}
    result["ps"] = subprocess.check_output(
        ["ps", "-p", str(pid), "-o", "pid=,%cpu=,rss=,vsz=,etime="], text=True).strip()
    footprint = subprocess.run(["footprint", "--pid", str(pid)], capture_output=True, text=True, timeout=20)
    result.update(footprint_returncode=footprint.returncode, footprint=footprint.stdout,
                  footprint_stderr=footprint.stderr)
    write_json(path, result)


def run(args):
    config, manifest = read(args.config), read(args.manifest)
    expected = read(args.expected)
    require_runtime(manifest["tag"])
    from lease import verify_seal
    identity = verify_seal(manifest["mode"])
    if identity["artifact_sha256"] != config["artifact_sha256"] or identity["source_sha"] != manifest["source_sha"]:
        raise RuntimeError("Frozen source/artifact identity differs")
    if identity["calibration_spec_sha256"] != config["calibration_spec_sha256"]:
        raise RuntimeError("Calibration geometry/semantics changed after seal")
    from appearance import validate
    setup=Path(args.config).parent
    spec=read(config["calibration_spec_path"])
    observed=validate(config,spec,config.get("appearance_review",{}),(setup/"setup-config.json").read_bytes(),(setup/"setup.png").read_bytes())
    if any(config.get(key)!=value for key,value in observed.items()): raise RuntimeError("Observed appearance changed in config")
    (Path(args.manifest).parent.parent / "measurement-claim").mkdir(exist_ok=False)
    if config["bundle_id"] != "com.stage11.c11.debug." + manifest["tag"].replace("-", "."):
        raise RuntimeError("Config/manifest tagged identity mismatch")
    readiness = read(args.readiness)
    if readiness.get("complete") is not True or readiness.get("window_id") != manifest["initial"]["window_id"]:
        raise RuntimeError("Real priming/mount readiness evidence missing")
    if readiness.get("debug_retention_disabled") is not True:
        raise RuntimeError("Debug retention must be disabled")
    # Matched fixed warm-up follows observed settlement, never hides a priming timeout.
    warmup_start = time.monotonic()
    while time.monotonic() < warmup_start + 60:
        require_runtime(manifest["tag"]); time.sleep(.1)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    atomic(out / "readiness.json", readiness)
    atomic(out / "warmup.json", {"start": warmup_start, "end": time.monotonic(), "requested_s": 60})
    target = Target(config, out / "crops")
    templates = {name: read(path) for name, path in config["templates"].items()}
    for key in ("glyph-a", "glyph-b", "workspace-1", "workspace-2", "scroll-top", "scroll-down"):
        if key not in templates:
            raise RuntimeError(f"Missing reviewed template: {key}")
    if not config.get("templates_visually_verified"):
        raise RuntimeError("Expected-state template review is required")
    selected = manifest["labels"]["w01"]
    key1 = {"kind": "key", "keycode": 18, "command": True}
    key2 = {"kind": "key", "keycode": 19, "command": True}
    top = {"kind": "scroll", "point": config["sidebar_point"], "pixels": 10000}
    down = {"kind": "scroll", "point": config["sidebar_point"], "pixels": -config["scroll_pixels"]}
    setup_delay = config.get("setup_settle_s", 0.08)
    phase_results = []
    result = {"config": config, "manifest": str(args.manifest), "phases": phase_results, "complete": False, "protocol": "g60-w2-v1", "readiness": readiness}

    def choose(one, two):
        _, pixels, _ = target.capture(templates[one]["roi"])
        for name in (one, two):
            if pixels == Path(templates[name]["pixels"]).read_bytes():
                return name
        raise RuntimeError(f"Neither reviewed template is visible: {one}/{two}")

    def select_one_unlocked():
        nonlocal selected
        target.post(key1)
        time.sleep(setup_delay)
        if choose("workspace-1", "workspace-2") != "workspace-1":
            raise RuntimeError("Workspace-one setup did not present its expected marker")
        selected = manifest["labels"]["w01"]
        with RPC(manifest["tag"], manifest["socket"]) as rpc:
            if rpc.call("workspace.current")["workspace_id"] != selected:
                raise RuntimeError("Explicit setup switch selected wrong workspace")

    def select_one():
        with selection_lock(config['role']): select_one_unlocked()

    def sample(metric, ident):
        nonlocal selected
        setup_started = time.perf_counter_ns()
        if metric == "typing":
            select_one()
            target.post({"kind": "click", "point": config["terminal_point"]})
            before = choose("glyph-a", "glyph-b")
            after = "glyph-b" if before == "glyph-a" else "glyph-a"
            action = {"kind": "key", "text": after[-1]}
        elif metric == "switch":
            before = choose("workspace-1", "workspace-2")
            after = "workspace-2" if before == "workspace-1" else "workspace-1"
            action = key2 if after == "workspace-2" else key1
        else:
            select_one()
            target.post(top)
            time.sleep(setup_delay)
            before, after, action = "scroll-top", "scroll-down", down
        setup_ended = time.perf_counter_ns()
        if metric == "switch":
            with selection_lock(config['role']):
                row = target.measure(ident, metric, action, templates[before], templates[after])
                with RPC(manifest["tag"], manifest["socket"]) as rpc:
                    observed = rpc.call("workspace.current")["workspace_id"]
                row["observed_selected_workspace_id"] = observed
                row["intended_selected_workspace_id"] = manifest["labels"]["w02" if after == "workspace-2" else "w01"]
                if row["ok"] and observed != row["intended_selected_workspace_id"]:
                    raise RuntimeError("Visible switch marker and actual selected identity disagree")
        else:
            row = target.measure(ident, metric, action, templates[before], templates[after])
        row["setup_ms"] = (setup_ended - setup_started) / 1e6
        if metric == "switch" and row["ok"]:
            selected = manifest["labels"]["w02" if after == "workspace-2" else "w01"]
        row["selected_workspace_id"] = selected
        return row

    select_one()
    try:
        for phase in ("no-churn", "churn", "quiescence"):
            directory = out / phase
            directory.mkdir()
            with RPC(manifest["tag"], manifest["socket"]) as rpc:
                state = capture(rpc, manifest, directory / "before.json")
                assert_model(state, manifest, expected, selected)
            resource_sample(config["pid"], directory / "resources-before.json")
            started = time.monotonic() + 1
            deadline = started + 60
            worker = ChurnWorker(manifest, expected, started, directory / "operations.jsonl") if phase == "churn" else None
            records = []
            info = {"name": phase, "start": started, "deadline": deadline, "complete": False}
            phase_results.append(info)
            if worker:
                worker.start()
            try:
                # 105 typing, 42 scroll and 42 switch trials at fixed common slots.
                schedule = (["typing"] * 5 + ["switch"] * 2 + ["scroll"] * 2) * 21
                with (directory / "samples.jsonl").open("w") as log:
                    for index, metric in enumerate(schedule):
                        due = started + index * 58 / len(schedule)
                        time.sleep(max(0, due - time.monotonic()))
                        if time.monotonic() >= deadline:
                            raise RuntimeError("Probe schedule overran fixed 60-second phase")
                        try:
                            row = sample(metric, f"{phase}-{index:03d}-{metric}")
                            row["load"] = os.getloadavg()
                            row["load_sampled_monotonic"] = time.monotonic()
                        except BaseException as error:
                            log.write(json.dumps({"id": f"{phase}-{index:03d}-{metric}", "metric": metric,
                                                  "scheduled": due, "completed": time.monotonic(),
                                                  "ok": False, "error": "setup_or_input_exception", "detail": str(error),
                                                  "load": os.getloadavg(), "load_sampled_monotonic": time.monotonic()}) + "\n")
                            log.flush()
                            raise
                        row.update(scheduled=due, completed=time.monotonic())
                        records.append(row)
                        log.write(json.dumps(row) + "\n")
                        log.flush()

                    time.sleep(max(0, deadline - time.monotonic()))
            finally:
                if worker:
                    worker.stop_and_join()
                    expected = worker.expected
                    ops = worker.records
                    info["churn"] = {"completed_count": len(ops), "achieved_hz": len(ops) / 60,
                                     "error": worker.error, "pending": worker.pending,
                                     "alive": worker.is_alive(),
                                     "late": sum(r["started"] >= r["scheduled"] + 0.1 for r in ops),
                                     "overrun": any(r["completed"] > deadline for r in ops),
                                     "method_counts": {m: sum(r["method"] == m for r in ops)
                                                       for m in {r["method"] for r in ops}}}
                info["metrics"] = summarize(records)
                info["last_probe_overrun"] = any(r["completed"] > deadline for r in records)
                info["ended"] = time.monotonic()
                write_json(directory / "summary.json", info)
                write_json(directory / "expected.json", expected)
                write_json(out / "run.json", result)
            with RPC(manifest["tag"], manifest["socket"]) as rpc:
                state = capture(rpc, manifest, directory / "after.json")
                assert_model(state, manifest, expected, selected)
            info["model_verified"] = True
            resource_sample(config["pid"], directory / "resources-after.json")
            info["complete"] = not info["last_probe_overrun"] and all(
                info["metrics"][m]["valid"] >= minimum
                for m, minimum in (("typing", 100), ("scroll", 40), ("switch", 40)))
            if worker:
                churn = info["churn"]
                info["complete"] &= (churn["completed_count"] == 600 and not churn["error"]
                                     and not churn["overrun"])
            write_json(directory / "summary.json", info)
            write_json(out / "run.json", result)
            print(json.dumps({"phase": phase, "complete": info["complete"], "metrics": info["metrics"]}), flush=True)
        result["complete"] = all(p["complete"] for p in phase_results)
    except Exception as error:
        result["error"] = str(error)
        raise
    finally:
        write_json(out / "run.json", result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("config", "manifest", "expected", "out", "readiness"):
        parser.add_argument("--" + key, required=True)
    run(parser.parse_args())

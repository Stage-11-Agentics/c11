import Foundation
func inline(_ t: String) -> String {
  let r = (try? AttributedString(markdown: t, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(t)
  return String(r.characters)
}
let cases: [(String,String)] = [
 ("setext1", "Status\n======"),
 ("setext2", "Status\n------"),
 ("atxclose", "## Status ##"),
 ("wrapped", "- Deploy the change\n  after CI passes"),
 ("ordered", "1. First\n1. Second"),
 ("reflink", "See [plan][p].\n\n[p]: https://example.invalid/plan"),
 ("hardbreak", "First line  \nSecond line"),
 ("typical", "Auditing retry admission; next, verify cancellation.\nLineage: orchestrator → reviewer"),
]
for (name, input) in cases {
  let blocks = titleBarDescriptionBlocks(input)
  let rendered = blocks.map { b -> String in
    switch b {
    case .paragraph(let s): return "P(\(inline(s)))"
    case .heading(let l, let s): return "H\(l)(\(inline(s)))"
    case .listItem(let m, let s, let d): return "LI[\(m),d\(d)](\(inline(s)))"
    case .quote(let s): return "Q(\(inline(s)))"
    case .rule: return "HR"
    }
  }
  print(name.padding(toLength: 10, withPad: " ", startingAt: 0), rendered.joined(separator: " | ").debugDescription)
}
print("---- Foundation .full presentationIntent")
for (name, input) in cases {
  let a = try! AttributedString(markdown: input, options: .init(interpretedSyntax: .full))
  var out: [String] = []
  for run in a.runs {
    let kinds = run.presentationIntent?.components.map { c -> String in
      switch c.kind {
      case .paragraph: return "p"
      case .header(let l): return "h\(l)"
      case .listItem(let o): return "li\(o)"
      case .orderedList: return "ol"
      case .unorderedList: return "ul"
      case .blockQuote: return "bq"
      case .thematicBreak: return "hr"
      default: return "\(c.kind)"
      }
    }.joined(separator: "<") ?? "-"
    out.append("[\(kinds)]\(String(a[run.range].characters).debugDescription)\(run.link != nil ? "(link)" : "")")
  }
  print(name.padding(toLength: 10, withPad: " ", startingAt: 0), out.joined(separator: " "))
}

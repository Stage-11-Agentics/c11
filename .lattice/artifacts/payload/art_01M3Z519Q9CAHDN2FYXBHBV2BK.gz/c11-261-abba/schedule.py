"""Pure, preregistered ABBA schedule and balanced-pair validation."""
from collections import Counter

PHASE_SECONDS = 240
COLLECTION_SECONDS = 232
BLOCK_SIZE = 10
CYCLE_METRICS = ('typing', 'typing', 'switch', 'typing', 'scroll',
                 'typing', 'switch', 'typing', 'scroll', 'typing')
EXPECTED = {'typing': 120, 'switch': 40, 'scroll': 40}
MINIMUM = {'typing': 100, 'switch': 40, 'scroll': 40}


def schedule():
    rows = []
    for cycle, metric in enumerate(CYCLE_METRICS):
        for block, role in enumerate(('control', 'candidate', 'candidate', 'control')):
            for ordinal in range(BLOCK_SIZE):
                rows.append({'cycle': cycle, 'block': block, 'ordinal': ordinal,
                             'role': role, 'metric': metric,
                             'index': cycle * 20 + (block // 2) * 10 + ordinal,
                             'trial': len(rows)})
    return rows


def pairs(rows):
    buckets = {}
    for row in rows:
        key = (row['phase'], row['index'])
        bucket = buckets.setdefault(key, {})
        if row['role'] in bucket:
            raise ValueError('Duplicate role in pair: ' + str(key))
        bucket[row['role']] = row
    result = []
    for (phase, index), bucket in sorted(buckets.items()):
        if set(bucket) != {'control', 'candidate'}:
            raise ValueError('Unbalanced pair: ' + str((phase, index)))
        a, b = bucket['control'], bucket['candidate']
        if (a['metric'], a['cycle'], a['ordinal']) != (b['metric'], b['cycle'], b['ordinal']):
            raise ValueError('Mismatched pair semantics')
        if (a['block'], b['block']) not in ((0, 1), (3, 2)):
            raise ValueError('Non-ABBA pair')
        result.append({'phase': phase, 'index': index, 'metric': a['metric'],
                       'cycle': a['cycle'], 'ordinal': a['ordinal'],
                       'order': 'AB' if a['block'] == 0 else 'BA',
                       'candidate_minus_control_ms': b['latency_ms'] - a['latency_ms']
                       if a.get('ok') and b.get('ok') else None})
    return result


def assert_complete(rows, phase):
    actual = [r for r in rows if r['phase'] == phase]
    planned = schedule()
    if len(actual) != len(planned):
        raise ValueError(f'{phase}: {len(actual)}/400 attempted trials')
    for row, spec in zip(actual, planned):
        if any(row.get(k) != v for k, v in spec.items()):
            raise ValueError('Schedule order/identity mismatch')
    for role in ('control', 'candidate'):
        attempted = Counter(r['metric'] for r in actual if r['role'] == role)
        valid = Counter(r['metric'] for r in actual if r['role'] == role and r.get('ok'))
        if dict(attempted) != EXPECTED or any(valid[k] < v for k, v in MINIMUM.items()):
            raise ValueError(f'{phase}/{role}: attempted={attempted}, valid={valid}')
    return pairs(actual)

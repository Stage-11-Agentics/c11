# C11-259 repair round 1: validation and handoff

Head `0440a7e939c474db70bed1a9be14c130edbbc062`, draft PR #504. **Localization and functional checks pass. P-groups performance gate FAILS; this is not merge-ready evidence.** The requested matched comparison is now executed, including all three phases. One p99 limit failed and one expected-glyph trial timed out. No performance waiver is claimed.

## Repair and executed assertions

- `a770f89acd500a925a1af25dba85e37f0a7c706b` localizes every new CLI diagnostic and the empty-list status with `String(localized:defaultValue:)`. Command/flag/handle tokens remain interpolation arguments; `group_not_found: ` stays outside the localized text. The 18-key/token manifest for C11-291 is in `localization-key-manifest.md` and Lattice `ev_01M3XGMZMCGN380J1G7N5NQPWY`. Six translations remain C11-291's work.
- Merged announced main `86d45e218f220c89b592653de2f1c488d57068f7` in `2863ece9b40997a4fa269bff2b51d83e9cb10f5a`, preserving both additive project-file entries. Final commit `0440a7e939c474db70bed1a9be14c130edbbc062` moves the existing WorkspaceManagerSessionSnapshotTests into the hosted target after the bare logic runner hit the documented NSApp-nil failure. The failed run is preserved; it is not counted as a pass.
- build-host exact-head assertions PASS: 12 hosted WorkspaceManagerSessionSnapshotTests, 4 logic WorkspaceGroupTests and 6 logic WorkspaceReorderPlannerTests, zero failures. Invocation `5bbf60cec5b04a50906707c330e7088e`; log and xcresult under `builds/candidate-tests/`.
- Candidate Debug build PASS, invocation `f2b6af03ffea4b678a7a5bf0c91e5392`. Main control Debug build PASS, `fe99c7d2673e4b109b2530328ff1c40c`. Both clean remote source identities and submodule SHAs are retained.
- Both packaged candidate socket/CLI scenarios PASS: group lifecycle/atomic invalid inputs/selection/CLI parity, and mixed-pin batch reorder/dry-run/atomicity/CLI parity. Logs are under `runtime/candidate-test_*.log`.
- Candidate CLI diagnostic harness: 37/37 cases pass (36 errors plus empty-list status); actual older-main app capability cases: 2/2 pass. Full model snapshots around invalid commands remain unchanged. The no-current-window branch was not executed because the reserved fixture retains a valid window. No localized non-English runtime result is claimed.

## Primary matched comparison

Control: main `86d45e218f220c89b592653de2f1c488d57068f7`. Candidate: `0440a7e939c474db70bed1a9be14c130edbbc062`. Same build-host (Mac14,14; 24 cores; 128 GiB), macOS 26.5.2, display 9, 1920×1080 logical / 3840×2160 physical, 60 Hz reported. Same 1320×880 window, terminal glyph/marker/scroll crop pixels (all six templates match exactly), input points and schedule. Bundles are 0.67.0 (131), with distinct assigned tags. GUI, dylib and CLI hashes are in each calibration config; source/build manifests are attached.

Each process was quit and launched QA-fresh, received only the same g60 provisioning/probe/calibration sequence, then a fixed 60-second idle settling interval. No functional suite ran in either primary benchmark process. Fixture: 60 workspaces / 60 tabs (56 normal terminals, two about:blank browsers, two synthetic markdown tabs), same individual pins. Candidate has six folders including two empty ones; control has the same population ungrouped.

Three fixed 60-second phases: no churn, churn, quiescence. Each schedules 105 typing, 42 scrolling and 42 switching probes over the first 58 seconds. Oracle: first captured frame matching the specific expected glyph, workspace marker or actual scroll endpoint; an arbitrary repaint/ACK cannot pass. Latency is capture-end minus input-post, with no capture overhead subtracted. Nearest-rank percentiles; at 42 samples p99 is the maximum. Raw timestamps, every before/after crop, full PNG integrity, expected template bytes and capture/setup overhead are retained and rechecked by `compare.py`.

| Phase | Metric | Control p95 / p99 ms | Candidate p95 / p99 ms | Budget |
| --- | --- | ---: | ---: | --- |
| no-churn | typing | 54.70 / 57.60 | 50.99 / 54.32 | PASS |
| no-churn | scroll | 49.32 / 58.26 | 49.13 / 54.34 | PASS |
| no-churn | switch | 121.66 / 128.45 | 116.61 / 122.82 | PASS |
| churn | typing | 62.01 / 66.43 | 64.19 / 70.77 | PASS |
| churn | scroll | 73.56 / 93.18 | 54.24 / 62.22 | PASS |
| churn | switch | 132.80 / 259.09 | 114.02 / 134.86 | PASS |
| quiescence | typing | 57.16 / 82.39 | 54.24 / 63.81 | PASS |
| quiescence | scroll | 52.45 / 54.67 | 52.01 / 109.25 | FAIL |
| quiescence | switch | 121.99 / 126.85 | 112.87 / 119.29 | PASS |

**Failed limit:** quiescent scroll p99 = **109.254333 ms**, control = 54.673958 ms, allowed `max(control × 1.25, control + 15)` = **69.673958 ms**. All nine p95 checks and the other eight p99 checks pass. **One candidate quiescent typing trial timed out at 1 second** (`quiescence-182-typing`, glyph b remained visible when a was expected). It is retained, not treated as a successful sample or silently dropped. Candidate still has 104 valid typing observations in that phase; all other cells have 105/42/42 valid. Control has 567 valid / 0 failed, candidate 566 valid / 1 timeout across 567 scheduled trials.

Both churn workers completed all 600 operations at 10/s, with zero failed/late/overrun operations. Control used 600 singular reorders; candidate used 300 reorders plus 300 membership transfers. Workers were joined with no pending work before quiescence. All 60 workspace IDs, 60 tab IDs and 56 original shell PID/start identities survived every phase, with expected order/pins/membership/selection and no anchor PTY. Five post-probe idle observations show the operation log did not grow. The model/identity assertions and invalid-batch tests pass; they do not waive the latency failure.

Primary after-phase physical footprint: control 3362 MB throughout; candidate 3363/3363/3364 MB (no-churn/churn/quiescence). These are descriptive values, not invented memory budgets. Tagged hang log paths were absent (no records available); no stronger hang-monitor conclusion is claimed. At cleanup UserNotificationCenter held foreground focus, so only the verified candidate process was explicitly reactivated for dismissal; no causal attribution to the timed failure is established.

build-host was shared, not quiet. One-minute load samples ranged 10.90–49.87 control and 12.96–20.18 candidate. Per-phase 1/5/15-minute loads and process snapshots are retained. The result is an observed budget failure, not proof of a particular source-level cause. Further isolation/profiling or an explicit acceptance decision remains necessary before landing.

## Earlier attempts and cleanup

All earlier data remain under `runtime/`: a rejected first control pass exceeded its 60-second deadline by 165 ms; a candidate run stopped before quiescence because the recorder imposed extra zero-error/zero-lateness gates. The recorder was corrected to the actual review requirements (valid minima, all raw errors retained, scheduled mutations completed in the fixed phase). Its previous version is preserved.

The first complete exploratory pair (`control-run-r2`, `candidate-run-r2`, root `comparison.json`) failed three p99 limits. Its preconditions differed: candidate functional suites ran before measurement, control had only two diagnostics; after-phase footprints were about 3482 vs 2904 MB. That mismatch prompted the primary fresh pair above. Neither its failures nor the partial run were discarded or pooled into the primary quantiles. There was no source/binary change between these runs, and the primary result remains FAIL.

Every UI lease stayed below 20 minutes. Both tags were dismissed using synthesized Command-Q plus the reviewed visible Quit button; process absence and lock release are recorded. Primary leases: control 381.84 seconds, candidate 476.07 seconds. No production c11 window was driven. `tree --no-layout` shows the selected area at 1120×848, and screenshots/crops are retained. Installed skills were not edited or synced during this repair.

Original real restart/focus/event evidence remains `art_01M3XFPM8P78G2S0GGH5308G7M` / `ev_01M3XFRQFY52DF3MJ0HQHP6NJH`, observed at 3dc6383. The relevant Workspace, WorkspaceManager, SessionPersistence, group/planner, group/workspace handler and TerminalController files are byte-identical to final head (hash comparisons in source-provenance.json); this evidence is explicitly carried forward, not presented as a new restart run. New runtime runs independently rechecked model/process identity and real input paths. W2/W3 sidebar/drag/drop and C11-270 final fleet soak are not claimed.

## Reproduce the evidence check

Unpack the archive anywhere, then run:

```sh
python3 runtime/compare.py --control runtime/paired-fresh/control/run --candidate runtime/paired-fresh/candidate/run --evidence-root "$PWD/runtime" --identity runtime/source-provenance.json --out reproduced.json
```

Expected exit status 1 / `FAIL`, zero incomplete reasons, exactly the quiescent-scroll p99 budget failure above. The copied archive was independently re-evaluated and produced the same result. `SHA256SUMS` covers all delivered files. Exact-head GitHub CI is separate and pending at handoff; no merge is authorized or performed.

import SwiftUI
func show(_ b: TitleBarDescriptionBlock) -> String {
  switch b {
  case .paragraph(let s): return "P(\(String(s.characters)))"
  case .heading(let l, let s): return "H\(l)(\(String(s.characters)))"
  case .listItem(let m, let s, let d): return "LI[\(m),d\(d)](\(String(s.characters)))"
  case .quote(let s): return "Q(\(String(s.characters)))"
  case .rule: return "HR"
  }
}
for c in ["1. Plan\n   1. read\n   2. write\n2. Ship", "- a\n  1. x\n  2. y", "1. a\n   - x\n   - y\n2. b", "- a\n  - b\n    - c"] {
  print(c.debugDescription.padding(toLength: 40, withPad: " ", startingAt: 0), titleBarDescriptionBlocks(c).map(show).joined(separator: " | "))
}
